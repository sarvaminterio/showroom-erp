-- Showroom ERP schema (PostgreSQL 14+)
CREATE TABLE IF NOT EXISTS showrooms (
  id SERIAL PRIMARY KEY,
  code TEXT NOT NULL UNIQUE,             -- bill prefix, e.g. RR
  name TEXT NOT NULL,
  gstin CHAR(15) NOT NULL UNIQUE,
  state TEXT NOT NULL,
  addr TEXT NOT NULL DEFAULT '',
  phone TEXT NOT NULL DEFAULT '',
  scheme TEXT NOT NULL DEFAULT 'Regular' CHECK (scheme IN ('Regular','Composition'))
);

CREATE TABLE IF NOT EXISTS users (
  id SERIAL PRIMARY KEY,
  name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('owner','staff')),
  showroom_id INT REFERENCES showrooms(id)  -- required for staff
);

CREATE TABLE IF NOT EXISTS products (
  id SERIAL PRIMARY KEY,
  name TEXT NOT NULL,
  brand TEXT NOT NULL DEFAULT '',
  cat TEXT NOT NULL CHECK (cat IN ('Tile','Sanitaryware','CP Fitting')),
  size TEXT NOT NULL DEFAULT '',
  finish TEXT NOT NULL DEFAULT '',
  sqft_per_box NUMERIC(10,3),             -- tiles only
  rate NUMERIC(12,2) NOT NULL,            -- per sq ft for tiles, per piece otherwise
  gst_rate NUMERIC(5,2) NOT NULL DEFAULT 18,
  hsn TEXT NOT NULL,
  batch TEXT, shade TEXT,
  color TEXT NOT NULL DEFAULT '#cfcac0',
  CHECK (cat <> 'Tile' OR sqft_per_box > 0)
);

CREATE TABLE IF NOT EXISTS stock (
  product_id INT REFERENCES products(id) ON DELETE CASCADE,
  showroom_id INT REFERENCES showrooms(id) ON DELETE CASCADE,
  qty INT NOT NULL DEFAULT 0 CHECK (qty >= 0),
  PRIMARY KEY (product_id, showroom_id)
);

CREATE TABLE IF NOT EXISTS stock_moves (           -- audit trail of every stock change
  id SERIAL PRIMARY KEY,
  product_id INT NOT NULL REFERENCES products(id),
  from_showroom INT REFERENCES showrooms(id),
  to_showroom INT REFERENCES showrooms(id),
  qty INT NOT NULL,
  reason TEXT NOT NULL,                             -- sale, received, damage, transfer
  ref TEXT,
  user_id INT REFERENCES users(id),
  at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS customers (
  id SERIAL PRIMARY KEY,
  name TEXT NOT NULL,
  type TEXT NOT NULL DEFAULT 'Retail',
  phone TEXT NOT NULL DEFAULT '',
  gstin TEXT NOT NULL DEFAULT '',
  state TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS bill_sequences (
  showroom_id INT REFERENCES showrooms(id),
  type TEXT, fy TEXT, next INT NOT NULL,
  PRIMARY KEY (showroom_id, type, fy)
);

CREATE TABLE IF NOT EXISTS bills (
  id SERIAL PRIMARY KEY,
  no TEXT NOT NULL UNIQUE,
  showroom_id INT NOT NULL REFERENCES showrooms(id),
  type TEXT NOT NULL CHECK (type IN ('GST','BOS','EST')),  -- tax invoice, bill of supply, non-GST estimate
  date DATE NOT NULL DEFAULT CURRENT_DATE,
  customer_id INT NOT NULL REFERENCES customers(id),
  discount_pct NUMERIC(5,2) NOT NULL DEFAULT 0,
  subtotal NUMERIC(14,2) NOT NULL, taxable NUMERIC(14,2) NOT NULL,
  cgst NUMERIC(14,2) NOT NULL DEFAULT 0, sgst NUMERIC(14,2) NOT NULL DEFAULT 0, igst NUMERIC(14,2) NOT NULL DEFAULT 0,
  total NUMERIC(14,2) NOT NULL,
  paid NUMERIC(14,2) NOT NULL DEFAULT 0,
  created_by INT REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS bill_items (
  id SERIAL PRIMARY KEY,
  bill_id INT NOT NULL REFERENCES bills(id) ON DELETE CASCADE,
  product_id INT NOT NULL REFERENCES products(id),
  room TEXT NOT NULL DEFAULT '',
  area NUMERIC(10,2), wastage NUMERIC(5,2),
  qty INT NOT NULL, unit TEXT NOT NULL,
  rate NUMERIC(12,2) NOT NULL, gst_rate NUMERIC(5,2) NOT NULL,
  amount NUMERIC(14,2) NOT NULL
);

CREATE TABLE IF NOT EXISTS payments (
  id SERIAL PRIMARY KEY,
  bill_id INT NOT NULL REFERENCES bills(id) ON DELETE CASCADE,
  amount NUMERIC(14,2) NOT NULL CHECK (amount > 0),
  mode TEXT NOT NULL DEFAULT 'Cash',
  at TIMESTAMPTZ NOT NULL DEFAULT now(),
  user_id INT REFERENCES users(id)
);

-- ===== v0.2: payment follow-ups =====
ALTER TABLE customers ADD COLUMN IF NOT EXISTS credit_days INT NOT NULL DEFAULT 0;
ALTER TABLE bills ADD COLUMN IF NOT EXISTS due_date DATE;
UPDATE bills SET due_date = date WHERE due_date IS NULL;

CREATE TABLE IF NOT EXISTS followups (
  id SERIAL PRIMARY KEY,
  customer_id INT NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  note TEXT NOT NULL,
  promised_date DATE,                      -- "will pay on ..."
  promised_amount NUMERIC(14,2),
  user_id INT REFERENCES users(id),
  at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS digests (       -- one AI payment briefing per day
  day DATE PRIMARY KEY,
  text TEXT NOT NULL,
  total_due NUMERIC(14,2) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ===== v0.3: accounting (double-entry) =====
ALTER TABLE products   ADD COLUMN IF NOT EXISTS avg_cost NUMERIC(12,2) NOT NULL DEFAULT 0;  -- per box / piece, before GST
ALTER TABLE bill_items ADD COLUMN IF NOT EXISTS cost NUMERIC(14,2) NOT NULL DEFAULT 0;      -- cost of goods sold for this line

CREATE TABLE IF NOT EXISTS accounts (
  id SERIAL PRIMARY KEY,
  key TEXT UNIQUE,                         -- set for built-in accounts
  name TEXT NOT NULL,
  type TEXT NOT NULL CHECK (type IN ('asset','liability','equity','income','expense')),
  kind TEXT                                -- 'cash' or 'bank' for money accounts
);
INSERT INTO accounts(key,name,type,kind) VALUES
 ('CASH','Cash in hand','asset','cash'),
 ('BANK','Bank account','asset','bank'),
 ('AR','Customers (sundry debtors)','asset',NULL),
 ('STOCK','Stock in trade','asset',NULL),
 ('GST_IN','GST input credit','asset',NULL),
 ('AP','Suppliers (sundry creditors)','liability',NULL),
 ('GST_OUT','GST payable','liability',NULL),
 ('LOANS','Loans','liability',NULL),
 ('CAPITAL','Owner''s capital','equity',NULL),
 ('DRAWINGS','Owner''s drawings','equity',NULL),
 ('SALES','Sales','income',NULL),
 ('ROUNDOFF','Round off','income',NULL),
 ('COGS','Cost of goods sold','expense',NULL),
 ('EXP_RENT','Rent','expense',NULL),
 ('EXP_SALARY','Salaries & wages','expense',NULL),
 ('EXP_POWER','Electricity','expense',NULL),
 ('EXP_FREIGHT','Freight & transport','expense',NULL),
 ('EXP_COMMISSION','Commission (architects, plumbers)','expense',NULL),
 ('EXP_OFFICE','Office & miscellaneous','expense',NULL)
ON CONFLICT (key) DO NOTHING;

CREATE TABLE IF NOT EXISTS suppliers (
  id SERIAL PRIMARY KEY,
  name TEXT NOT NULL,
  gstin TEXT NOT NULL DEFAULT '',
  state TEXT NOT NULL,
  phone TEXT NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS purchases (
  id SERIAL PRIMARY KEY,
  showroom_id INT NOT NULL REFERENCES showrooms(id),
  supplier_id INT NOT NULL REFERENCES suppliers(id),
  invoice_no TEXT NOT NULL,
  date DATE NOT NULL,
  taxable NUMERIC(14,2) NOT NULL, cgst NUMERIC(14,2) NOT NULL DEFAULT 0, sgst NUMERIC(14,2) NOT NULL DEFAULT 0, igst NUMERIC(14,2) NOT NULL DEFAULT 0,
  total NUMERIC(14,2) NOT NULL,
  created_by INT REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (supplier_id, invoice_no)          -- the same supplier bill can't be entered twice
);
CREATE TABLE IF NOT EXISTS purchase_items (
  id SERIAL PRIMARY KEY,
  purchase_id INT NOT NULL REFERENCES purchases(id) ON DELETE CASCADE,
  product_id INT NOT NULL REFERENCES products(id),
  qty INT NOT NULL CHECK (qty > 0),
  rate NUMERIC(12,2) NOT NULL,               -- per box / piece, before GST
  gst_rate NUMERIC(5,2) NOT NULL,
  amount NUMERIC(14,2) NOT NULL
);

CREATE TABLE IF NOT EXISTS expenses (
  id SERIAL PRIMARY KEY,
  date DATE NOT NULL,
  showroom_id INT REFERENCES showrooms(id),  -- empty = head office / shared
  account_id INT NOT NULL REFERENCES accounts(id),
  amount NUMERIC(14,2) NOT NULL CHECK (amount > 0),
  gst NUMERIC(14,2) NOT NULL DEFAULT 0,
  paid_from INT NOT NULL REFERENCES accounts(id),
  note TEXT NOT NULL DEFAULT '',
  created_by INT REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS journal (
  id SERIAL PRIMARY KEY,
  date DATE NOT NULL,
  showroom_id INT REFERENCES showrooms(id),
  ref_type TEXT NOT NULL,                    -- bill, payment, purchase, supplier_payment, expense, manual, opening_stock
  ref_id INT,
  narration TEXT NOT NULL DEFAULT '',
  created_by INT REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS journal_ref_once ON journal(ref_type, ref_id) WHERE ref_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS journal_date ON journal(date);

CREATE TABLE IF NOT EXISTS journal_lines (
  id SERIAL PRIMARY KEY,
  journal_id INT NOT NULL REFERENCES journal(id) ON DELETE CASCADE,
  account_id INT NOT NULL REFERENCES accounts(id),
  debit NUMERIC(14,2) NOT NULL DEFAULT 0 CHECK (debit >= 0),
  credit NUMERIC(14,2) NOT NULL DEFAULT 0 CHECK (credit >= 0),
  customer_id INT REFERENCES customers(id),
  supplier_id INT REFERENCES suppliers(id)
);
CREATE INDEX IF NOT EXISTS jl_account ON journal_lines(account_id);
CREATE INDEX IF NOT EXISTS jl_customer ON journal_lines(customer_id) WHERE customer_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS jl_supplier ON journal_lines(supplier_id) WHERE supplier_id IS NOT NULL;
