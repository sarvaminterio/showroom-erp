import express from 'express';
import helmet from 'helmet';
import cookieParser from 'cookie-parser';
import path from 'path';
import { fileURLToPath } from 'url';
import api from './routes.js';
import ai from './ai.js';
import accounts from './accounts.js';
import analytics from './analytics.js';
import { startScheduler } from './digest.js';

const app = express();
const here = path.dirname(fileURLToPath(import.meta.url));
app.set('trust proxy', 1);
app.use(helmet({ contentSecurityPolicy: { directives: {
  defaultSrc: ["'self'"], scriptSrc: ["'self'"], styleSrc: ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'],
  fontSrc: ["'self'", 'https://fonts.gstatic.com'], imgSrc: ["'self'", 'data:'], scriptSrcAttr: ["'unsafe-inline'"] } } }));
app.use(express.json({ limit: '200kb' }));
app.use(cookieParser());

app.get('/healthz', (req, res) => res.send('ok'));
app.use('/api/ai', ai);
app.use('/api', api);
app.use('/api', accounts);
app.use('/api', analytics);
app.use(express.static(path.join(here, '../../public')));

// Errors: show user-facing messages, hide internals.
app.use((err, req, res, next) => {
  if (err.code === '23505') return res.status(409).json({ error: 'That record already exists: duplicate GSTIN, email, bill prefix, or this supplier invoice number was already entered.' });
  const status = err.status || (err.message?.startsWith('Enter ') ? 400 : 500);
  if (status >= 500 && !err.status) console.error(err);
  res.status(status).json({ error: status >= 500 && !err.status ? 'Something went wrong on the server.' : err.message });
});

const port = process.env.PORT || 3000;
app.listen(port, () => { console.log(`Showroom ERP running on http://localhost:${port}`); startScheduler(); });
