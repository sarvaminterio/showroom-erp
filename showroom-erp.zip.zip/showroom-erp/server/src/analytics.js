// Business analytics for the owner: trends, breakdowns, top lists, receivables and stock health.
import { Router } from 'express';
import { q } from './db.js';
import { requireAuth, requireOwner } from './auth.js';
import { duesFor } from './digest.js';
import { round2 } from './billing.js';

const r = Router();
r.use(requireAuth, requireOwner);
const wrap = fn => (req, res, next) => fn(req, res).catch(next);
const iso = d => (/^\d{4}-\d{2}-\d{2}$/.test(d || '') ? d : null);

r.get('/analytics', wrap(async (req, res) => {
  const now = new Date(Date.now() + 330 * 60e3).toISOString().slice(0, 10);
  const to = iso(req.query.to) || now;
  const from = iso(req.query.from) || (() => { const d = new Date(to); d.setMonth(d.getMonth() - 11); d.setDate(1); return d.toISOString().slice(0, 10); })();
  const shop = req.query.showroom && req.query.showroom !== 'all' ? +req.query.showroom : null;
  const days = Math.round((new Date(to) - new Date(from)) / 864e5) + 1;
  const grain = days <= 62 ? 'day' : 'month';
  const P = [from, to, shop];
  // revenue per item line, after the bill's discount, before GST
  const ITEM = `SELECT i.*, b.date, b.showroom_id, b.customer_id, i.amount*(1-b.discount_pct/100) AS rev FROM bill_items i JOIN bills b ON b.id=i.bill_id
    WHERE b.date BETWEEN $1 AND $2 AND ($3::int IS NULL OR b.showroom_id=$3)`;

  const [kpi, trend, byShop, byCat, byBrand, topProd, topCust, byType, modes, purch, exp, stockVal, slow, gst, prevKpi] = await Promise.all([
    q(`SELECT COUNT(*)::int AS bills, COALESCE(SUM(taxable),0) AS sales, COALESCE(SUM(total),0) AS billed, COALESCE(SUM(paid),0) AS collected_on_bills,
         COALESCE(SUM((SELECT SUM(cost) FROM bill_items WHERE bill_id=b.id)),0) AS cogs
       FROM bills b WHERE date BETWEEN $1 AND $2 AND ($3::int IS NULL OR showroom_id=$3)`, P),
    q(`WITH s AS (SELECT generate_series(date_trunc('${grain}', $1::date), date_trunc('${grain}', $2::date), interval '1 ${grain}')::date AS p)
       SELECT s.p::text AS period,
         COALESCE((SELECT SUM(taxable) FROM bills b WHERE date_trunc('${grain}', b.date)=s.p AND b.date BETWEEN $1 AND $2 AND ($3::int IS NULL OR b.showroom_id=$3)),0) AS sales,
         COALESCE((SELECT SUM(i.cost) FROM bill_items i JOIN bills b ON b.id=i.bill_id WHERE date_trunc('${grain}', b.date)=s.p AND b.date BETWEEN $1 AND $2 AND ($3::int IS NULL OR b.showroom_id=$3)),0) AS cogs,
         COALESCE((SELECT SUM(amount) FROM expenses e WHERE date_trunc('${grain}', e.date)=s.p AND e.date BETWEEN $1 AND $2 AND ($3::int IS NULL OR e.showroom_id=$3)),0) AS expenses,
         COALESCE((SELECT COUNT(*) FROM bills b WHERE date_trunc('${grain}', b.date)=s.p AND b.date BETWEEN $1 AND $2 AND ($3::int IS NULL OR b.showroom_id=$3)),0)::int AS bills
       FROM s ORDER BY s.p`, P),
    q(`SELECT sh.name, COALESCE(SUM(b.taxable),0) AS sales, COUNT(b.id)::int AS bills FROM showrooms sh
       LEFT JOIN bills b ON b.showroom_id=sh.id AND b.date BETWEEN $1 AND $2 WHERE $3::int IS NULL OR sh.id=$3 GROUP BY sh.id ORDER BY sales DESC`, P),
    q(`SELECT p.cat AS name, SUM(x.rev) AS sales, SUM(x.rev-x.cost) AS profit FROM (${ITEM}) x JOIN products p ON p.id=x.product_id GROUP BY p.cat ORDER BY sales DESC`, P),
    q(`SELECT p.brand AS name, SUM(x.rev) AS sales FROM (${ITEM}) x JOIN products p ON p.id=x.product_id GROUP BY p.brand ORDER BY sales DESC LIMIT 10`, P),
    q(`SELECT p.name || ' (' || p.brand || ')' AS name, SUM(x.rev) AS sales, SUM(x.rev-x.cost) AS profit, SUM(x.qty)::int AS qty, BOOL_OR(x.cost=0) AS no_cost
       FROM (${ITEM}) x JOIN products p ON p.id=x.product_id GROUP BY p.id ORDER BY sales DESC LIMIT 10`, P),
    q(`SELECT c.name, c.type, SUM(b.taxable) AS sales, COUNT(*)::int AS bills, SUM(b.total-b.paid) AS due FROM bills b JOIN customers c ON c.id=b.customer_id
       WHERE b.date BETWEEN $1 AND $2 AND ($3::int IS NULL OR b.showroom_id=$3) GROUP BY c.id ORDER BY sales DESC LIMIT 10`, P),
    q(`SELECT c.type AS name, SUM(b.taxable) AS sales, COUNT(DISTINCT c.id)::int AS customers FROM bills b JOIN customers c ON c.id=b.customer_id
       WHERE b.date BETWEEN $1 AND $2 AND ($3::int IS NULL OR b.showroom_id=$3) GROUP BY c.type ORDER BY sales DESC`, P),
    q(`SELECT p.mode AS name, SUM(p.amount) AS amount, COUNT(*)::int AS n FROM payments p JOIN bills b ON b.id=p.bill_id
       WHERE (p.at AT TIME ZONE 'Asia/Kolkata')::date BETWEEN $1 AND $2 AND ($3::int IS NULL OR b.showroom_id=$3) GROUP BY p.mode ORDER BY amount DESC`, P),
    q(`SELECT COALESCE(SUM(taxable),0) AS v, COUNT(*)::int AS n FROM purchases WHERE date BETWEEN $1 AND $2 AND ($3::int IS NULL OR showroom_id=$3)`, P),
    q(`SELECT COALESCE(SUM(amount),0) AS v FROM expenses WHERE date BETWEEN $1 AND $2 AND ($3::int IS NULL OR showroom_id=$3)`, P),
    q(`SELECT sh.name, COALESCE(SUM(s.qty*p.avg_cost),0) AS value, COALESCE(SUM(s.qty),0)::int AS units FROM showrooms sh
       LEFT JOIN stock s ON s.showroom_id=sh.id LEFT JOIN products p ON p.id=s.product_id WHERE $1::int IS NULL OR sh.id=$1 GROUP BY sh.id ORDER BY value DESC`, [shop]),
    q(`SELECT p.name || ' (' || p.brand || ')' AS name, p.cat, SUM(s.qty)::int AS qty, SUM(s.qty*p.avg_cost) AS value,
         (SELECT MAX(b.date) FROM bill_items i JOIN bills b ON b.id=i.bill_id WHERE i.product_id=p.id AND ($3::int IS NULL OR b.showroom_id=$3))::text AS last_sold
       FROM products p JOIN stock s ON s.product_id=p.id AND ($3::int IS NULL OR s.showroom_id=$3)
       WHERE NOT EXISTS (SELECT 1 FROM bill_items i JOIN bills b ON b.id=i.bill_id WHERE i.product_id=p.id AND b.date BETWEEN $1 AND $2 AND ($3::int IS NULL OR b.showroom_id=$3))
       GROUP BY p.id HAVING SUM(s.qty) > 0 ORDER BY value DESC, qty DESC LIMIT 10`, P),
    q(`SELECT COALESCE((SELECT SUM(cgst+sgst+igst) FROM bills WHERE date BETWEEN $1 AND $2 AND ($3::int IS NULL OR showroom_id=$3)),0) AS output,
         COALESCE((SELECT SUM(cgst+sgst+igst) FROM purchases pu JOIN showrooms sh ON sh.id=pu.showroom_id AND sh.scheme='Regular' WHERE pu.date BETWEEN $1 AND $2 AND ($3::int IS NULL OR pu.showroom_id=$3)),0)
         + COALESCE((SELECT SUM(gst) FROM expenses WHERE date BETWEEN $1 AND $2 AND ($3::int IS NULL OR showroom_id=$3)),0) AS input`, P),
    // same-length period just before, for growth %
    q(`SELECT COALESCE(SUM(taxable),0) AS sales, COUNT(*)::int AS bills FROM bills
       WHERE date BETWEEN ($1::date - ($2::date - $1::date) - 1) AND ($1::date - 1) AND ($3::int IS NULL OR showroom_id=$3)`, P)
  ]);

  const k = kpi.rows[0], sales = k.sales, gross = round2(sales - k.cogs), expenses = exp.rows[0].v;
  const dues = await duesFor(shop);
  const pct = (a, b) => (b ? round2((a - b) / b * 100) : null);
  res.json({
    from, to, grain,
    kpis: { sales, bills: k.bills, avgBill: k.bills ? round2(sales / k.bills) : 0, gross, margin: sales ? round2(gross / sales * 100) : 0,
      expenses, net: round2(gross - expenses), purchases: purch.rows[0].v, outstanding: dues.total, overdue: dues.overdue,
      salesGrowth: pct(sales, prevKpi.rows[0].sales), billsGrowth: pct(k.bills, prevKpi.rows[0].bills),
      unpriced: topProd.rows.some(x => x.no_cost) || (k.cogs === 0 && sales > 0) },
    trend: trend.rows.map(t => ({ ...t, gross: round2(t.sales - t.cogs) })),
    byShowroom: byShop.rows, byCategory: byCat.rows, byBrand: byBrand.rows, topProducts: topProd.rows, topCustomers: topCust.rows,
    byCustomerType: byType.rows, paymentModes: modes.rows, ageing: dues.buckets,
    stockByShowroom: stockVal.rows, slowMovers: slow.rows, gst: gst.rows[0]
  });
}));

export default r;
