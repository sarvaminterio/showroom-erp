import pg from 'pg';
pg.types.setTypeParser(1700, v => parseFloat(v)); // NUMERIC → JS number
pg.types.setTypeParser(1082, v => v);             // DATE → 'YYYY-MM-DD'

export const pool = new pg.Pool({
  connectionString: process.env.DATABASE_URL,
  options: '-c timezone=Asia/Kolkata', // due dates and "today" follow Indian time
  ssl: process.env.DATABASE_SSL === 'true' ? { rejectUnauthorized: false } : undefined
});
export const q = (text, params) => pool.query(text, params);
// rows as arrays, in column order (for reports with repeated column names)
export const qa = (text, params) => pool.query({ text, values: params, rowMode: 'array' });

// Run fn inside a transaction; rolls back on any error.
export async function tx(fn) {
  const c = await pool.connect();
  try { await c.query('BEGIN'); const r = await fn(c); await c.query('COMMIT'); return r; }
  catch (e) { await c.query('ROLLBACK'); throw e; }
  finally { c.release(); }
}
