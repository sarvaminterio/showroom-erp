// Double-entry bookkeeping: every sale, payment, purchase and expense posts a balanced journal entry.
import { Router } from 'express';
import { q, qa, tx } from './db.js';
import { requireAuth, requireOwner, canUse } from './auth.js';
import { round2 } from './billing.js';

const r = Router();
r.use(requireAuth);
const wrap = fn => (req, res, next) => fn(req, res).catch(next);
const fail = (m, s = 400) => { const e = new Error(m); e.status = s; throw e; };
const isoDate = d => (/^\d{4}-\d{2}-\d{2}$/.test(d || '') ? d : null);
const NORMAL_DEBIT = t => t === 'asset' || t === 'expense';

// ---------- posting ----------
let keyCache = null;
async function idOf(c, key) {
  if (!keyCache) keyCache = Object.fromEntries((await c.query('SELECT key,id FROM accounts WHERE key IS NOT NULL')).rows.map(x => [x.key, x.id]));
  if (!keyCache[key]) fail(`Account ${key} is missing.`, 500);
  return keyCache[key];
}

// lines: [{ key | accountId, amount, side: 'dr'|'cr', customerId?, supplierId? }]; negative amounts flip side.
export async function post(c, { date, showroomId = null, refType, refId = null, narration = '', userId = null, lines }) {
  const rows = [];
  for (const l of lines) {
    let a = round2(+l.amount || 0); if (Math.abs(a) < 0.005) continue;
    let side = l.side; if (a < 0) { a = -a; side = side === 'dr' ? 'cr' : 'dr'; }
    rows.push({ account: l.accountId || await idOf(c, l.key), debit: side === 'dr' ? a : 0, credit: side === 'cr' ? a : 0, customer: l.customerId || null, supplier: l.supplierId || null });
  }
  const dr = round2(rows.reduce((s, x) => s + x.debit, 0)), cr = round2(rows.reduce((s, x) => s + x.credit, 0));
  if (Math.abs(dr - cr) > 0.01) fail(`Entry does not balance (debit ${dr}, credit ${cr}).`);
  if (!rows.length) return null;
  const { rows: [j] } = await c.query('INSERT INTO journal(date,showroom_id,ref_type,ref_id,narration,created_by) VALUES($1,$2,$3,$4,$5,$6) RETURNING id',
    [date, showroomId, refType, refId, narration.slice(0, 300), userId]);
  for (const x of rows) await c.query('INSERT INTO journal_lines(journal_id,account_id,debit,credit,customer_id,supplier_id) VALUES($1,$2,$3,$4,$5,$6)',
    [j.id, x.account, x.debit, x.credit, x.customer, x.supplier]);
  return j.id;
}

// Sale: customer owes total; sales + GST + round-off on the other side; cost moves from stock to COGS.
export async function postBill(c, bill, cost, userId) {
  const tax = round2(bill.cgst + bill.sgst + bill.igst);
  return post(c, { date: bill.date, showroomId: bill.showroom_id, refType: 'bill', refId: bill.id, narration: `Sale ${bill.no}`, userId, lines: [
    { key: 'AR', amount: bill.total, side: 'dr', customerId: bill.customer_id },
    { key: 'SALES', amount: bill.taxable, side: 'cr' },
    { key: 'GST_OUT', amount: tax, side: 'cr' },
    { key: 'ROUNDOFF', amount: round2(bill.total - bill.taxable - tax), side: 'cr' },
    { key: 'COGS', amount: cost, side: 'dr' },
    { key: 'STOCK', amount: cost, side: 'cr' }] });
}

const moneyKeyFor = mode => (mode === 'Cash' ? 'CASH' : 'BANK');
export async function postPayment(c, p, bill, userId) {
  const ist = new Date(new Date(p.at).getTime() + 330 * 60e3).toISOString().slice(0, 10); // payment date in Indian time
  return post(c, { date: ist, showroomId: bill.showroom_id, refType: 'payment', refId: p.id,
    narration: `Received against ${bill.no} (${p.mode})`, userId, lines: [
      { key: moneyKeyFor(p.mode), amount: p.amount, side: 'dr' },
      { key: 'AR', amount: p.amount, side: 'cr', customerId: bill.customer_id }] });
}

// Bring older sales and payments into the books (runs on start-up; each is posted only once).
export async function backfill(pool) {
  const c = await pool.connect();
  try {
    const { rows: bills } = await c.query(`SELECT b.*, COALESCE((SELECT SUM(cost) FROM bill_items WHERE bill_id=b.id),0) AS cost FROM bills b
      WHERE NOT EXISTS (SELECT 1 FROM journal WHERE ref_type='bill' AND ref_id=b.id) ORDER BY b.id`);
    for (const b of bills) { await c.query('BEGIN'); await postBill(c, b, b.cost, null); await c.query('COMMIT'); }
    const { rows: pays } = await c.query(`SELECT p.*, b.no, b.showroom_id, b.customer_id FROM payments p JOIN bills b ON b.id=p.bill_id
      WHERE NOT EXISTS (SELECT 1 FROM journal WHERE ref_type='payment' AND ref_id=p.id) ORDER BY p.id`);
    for (const p of pays) { await c.query('BEGIN'); await postPayment(c, p, p, null); await c.query('COMMIT'); }
    if (bills.length || pays.length) console.log(`Books: posted ${bills.length} older bills and ${pays.length} payments.`);
  } catch (e) { await c.query('ROLLBACK').catch(() => {}); throw e; } finally { c.release(); }
}

// ---------- accounts ----------
r.get('/accounts', wrap(async (req, res) => {
  const { rows } = await q(`SELECT a.id,a.key,a.name,a.type,a.kind, COALESCE(SUM(l.debit),0) AS dr, COALESCE(SUM(l.credit),0) AS cr
    FROM accounts a LEFT JOIN journal_lines l ON l.account_id=a.id GROUP BY a.id ORDER BY a.type, a.id`);
  res.json(rows.map(a => ({ ...a, balance: round2(NORMAL_DEBIT(a.type) ? a.dr - a.cr : a.cr - a.dr) })));
}));
r.post('/accounts', requireOwner, wrap(async (req, res) => {
  const name = String(req.body.name || '').trim(), type = req.body.type;
  if (!name || !['asset', 'liability', 'equity', 'income', 'expense'].includes(type)) fail('Enter a name and choose the account type.');
  const kind = type === 'asset' && ['cash', 'bank'].includes(req.body.kind) ? req.body.kind : null;
  const { rows: [a] } = await q('INSERT INTO accounts(name,type,kind) VALUES($1,$2,$3) RETURNING id', [name.slice(0, 80), type, kind]);
  res.json({ id: a.id });
}));

// ---------- suppliers ----------
r.get('/suppliers', wrap(async (req, res) => {
  const { rows } = await q(`SELECT s.*, COALESCE(SUM(l.credit-l.debit),0) AS balance FROM suppliers s
    LEFT JOIN journal_lines l ON l.supplier_id=s.id GROUP BY s.id ORDER BY s.name`);
  res.json(rows);
}));
r.post('/suppliers', wrap(async (req, res) => {
  const b = req.body; if (!String(b.name || '').trim() || !b.state) fail('Enter the supplier name and state.');
  const { rows: [s] } = await q('INSERT INTO suppliers(name,gstin,state,phone) VALUES($1,$2,$3,$4) RETURNING id',
    [b.name.trim().slice(0, 120), String(b.gstin || '').toUpperCase().trim(), b.state, b.phone || '']);
  res.json({ id: s.id });
}));

// ---------- purchases ----------
r.get('/purchases', wrap(async (req, res) => {
  const shop = req.user.role === 'staff' ? req.user.showroom_id : null;
  const { rows } = await q(`SELECT p.id,p.date,p.invoice_no AS "invoiceNo",p.total,p.taxable,p.cgst+p.sgst+p.igst AS gst,p.showroom_id AS shop,s.name AS supplier,
      (SELECT COUNT(*)::int FROM purchase_items WHERE purchase_id=p.id) AS items
    FROM purchases p JOIN suppliers s ON s.id=p.supplier_id WHERE $1::int IS NULL OR p.showroom_id=$1 ORDER BY p.date DESC, p.id DESC LIMIT 300`, [shop]);
  res.json(rows);
}));

r.post('/purchases', wrap(async (req, res) => {
  const b = req.body, date = isoDate(b.date) || new Date().toISOString().slice(0, 10);
  if (!canUse(req.user, b.showroomId)) fail('You can only enter purchases for your own showroom.', 403);
  if (!String(b.invoiceNo || '').trim()) fail("Enter the supplier's invoice number.");
  if (!Array.isArray(b.lines) || !b.lines.length || b.lines.length > 300) fail('Add at least one item.');
  const out = await tx(async c => {
    const { rows: [shop] } = await c.query('SELECT * FROM showrooms WHERE id=$1', [b.showroomId]);
    const { rows: [sup] } = await c.query('SELECT * FROM suppliers WHERE id=$1', [b.supplierId]);
    if (!shop || !sup) fail('Pick the showroom and supplier.');
    const inter = sup.state !== shop.state, claimITC = shop.scheme !== 'Composition';
    const lines = b.lines.map(l => ({ pid: +l.pid, qty: Math.trunc(+l.qty || 0), rate: round2(+l.rate || 0), gst: Math.max(0, +l.gstRate || 0) }));
    if (lines.some(l => l.qty <= 0 || l.rate < 0)) fail('Each item needs a quantity above 0 and a rate.');
    const ids = [...new Set(lines.map(l => l.pid))].sort((x, y) => x - y);
    const { rows: prods } = await c.query('SELECT id,name,avg_cost FROM products WHERE id = ANY($1::int[]) ORDER BY id FOR UPDATE', [ids]);
    if (prods.length !== ids.length) fail('One of the products was not found.');
    const P = Object.fromEntries(prods.map(p => [p.id, p]));
    let taxable = 0, tax = 0, stockValue = 0;
    for (const l of lines) {
      l.amount = round2(l.qty * l.rate); l.tax = round2(l.amount * l.gst / 100);
      l.cost = claimITC ? l.amount : l.amount + l.tax;            // composition dealers can't claim GST back, so it becomes cost
      taxable += l.amount; tax += l.tax; stockValue += l.cost;
    }
    taxable = round2(taxable); tax = round2(tax); stockValue = round2(stockValue);
    const total = Math.round(taxable + tax);
    const cgst = inter ? 0 : round2(tax / 2), sgst = inter ? 0 : round2(tax - cgst), igst = inter ? tax : 0;
    const { rows: [pur] } = await c.query(`INSERT INTO purchases(showroom_id,supplier_id,invoice_no,date,taxable,cgst,sgst,igst,total,created_by)
      VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING id`, [shop.id, sup.id, String(b.invoiceNo).trim().slice(0, 40), date, taxable, cgst, sgst, igst, total, req.user.id]);
    for (const l of lines) {
      // weighted average cost across all showrooms
      const { rows: [{ q: have }] } = await c.query('SELECT COALESCE(SUM(qty),0)::int AS q FROM stock WHERE product_id=$1', [l.pid]);
      const before = Math.max(0, have), unitCost = l.cost / l.qty;
      const avg = round2((before * P[l.pid].avg_cost + l.qty * unitCost) / (before + l.qty));
      P[l.pid].avg_cost = avg;
      await c.query('UPDATE products SET avg_cost=$2 WHERE id=$1', [l.pid, avg]);
      await c.query(`INSERT INTO stock(product_id,showroom_id,qty) VALUES($1,$2,$3) ON CONFLICT(product_id,showroom_id) DO UPDATE SET qty=stock.qty+$3`, [l.pid, shop.id, l.qty]);
      await c.query('INSERT INTO purchase_items(purchase_id,product_id,qty,rate,gst_rate,amount) VALUES($1,$2,$3,$4,$5,$6)', [pur.id, l.pid, l.qty, l.rate, l.gst, l.amount]);
      await c.query(`INSERT INTO stock_moves(product_id,to_showroom,qty,reason,ref,user_id) VALUES($1,$2,$3,'purchase',$4,$5)`, [l.pid, shop.id, l.qty, `${sup.name} ${b.invoiceNo}`, req.user.id]);
    }
    await post(c, { date, showroomId: shop.id, refType: 'purchase', refId: pur.id, narration: `Purchase ${b.invoiceNo} from ${sup.name}`, userId: req.user.id, lines: [
      { key: 'STOCK', amount: stockValue, side: 'dr' },
      { key: 'GST_IN', amount: claimITC ? tax : 0, side: 'dr' },
      { key: 'ROUNDOFF', amount: round2(total - taxable - tax), side: 'dr' },
      { key: 'AP', amount: total, side: 'cr', supplierId: sup.id }] });
    return { id: pur.id, total };
  });
  res.json(out);
}));

r.get('/purchases/:id', wrap(async (req, res) => {
  const { rows: [p] } = await q(`SELECT p.*, s.name AS supplier, s.gstin AS "supplierGstin", sh.name AS showroom FROM purchases p
    JOIN suppliers s ON s.id=p.supplier_id JOIN showrooms sh ON sh.id=p.showroom_id WHERE p.id=$1`, [req.params.id]);
  if (!p || !canUse(req.user, p.showroom_id)) fail('Purchase not found.', 404);
  const { rows: items } = await q(`SELECT i.*, pr.name, pr.brand, pr.size, pr.cat FROM purchase_items i JOIN products pr ON pr.id=i.product_id WHERE purchase_id=$1 ORDER BY i.id`, [p.id]);
  res.json({ ...p, items });
}));

// ---------- money out ----------
async function moneyAccount(c, id) {
  const { rows: [a] } = await c.query("SELECT * FROM accounts WHERE id=$1 AND kind IN ('cash','bank')", [id]);
  if (!a) fail('Choose whether it was paid from cash or bank.'); return a;
}
r.post('/supplier-payments', wrap(async (req, res) => {
  const b = req.body, amount = round2(+b.amount || 0), date = isoDate(b.date) || new Date().toISOString().slice(0, 10);
  if (!(amount > 0)) fail('Enter the amount paid.');
  await tx(async c => {
    const { rows: [s] } = await c.query('SELECT * FROM suppliers WHERE id=$1', [b.supplierId]); if (!s) fail('Supplier not found.');
    const from = await moneyAccount(c, b.paidFrom);
    await post(c, { date, refType: 'supplier_payment', narration: `Paid ${s.name}${b.note ? ' – ' + b.note : ''}`, userId: req.user.id, lines: [
      { key: 'AP', amount, side: 'dr', supplierId: s.id }, { accountId: from.id, amount, side: 'cr' }] });
  });
  res.json({ ok: true });
}));

r.get('/expenses', wrap(async (req, res) => {
  const shop = req.user.role === 'staff' ? req.user.showroom_id : null;
  const { rows } = await q(`SELECT e.id,e.date,e.amount,e.gst,e.note,e.showroom_id AS shop,a.name AS account,m.name AS "paidFrom" FROM expenses e
    JOIN accounts a ON a.id=e.account_id JOIN accounts m ON m.id=e.paid_from WHERE $1::int IS NULL OR e.showroom_id=$1 ORDER BY e.date DESC, e.id DESC LIMIT 300`, [shop]);
  res.json(rows);
}));
r.post('/expenses', wrap(async (req, res) => {
  const b = req.body, amount = round2(+b.amount || 0), gst = round2(+b.gst || 0), date = isoDate(b.date) || new Date().toISOString().slice(0, 10);
  const shop = b.showroomId ? +b.showroomId : null;
  if (req.user.role === 'staff' && shop !== req.user.showroom_id) fail('You can only enter expenses for your own showroom.', 403);
  if (!(amount > 0) || gst < 0) fail('Enter the expense amount.');
  await tx(async c => {
    const { rows: [acc] } = await c.query("SELECT * FROM accounts WHERE id=$1 AND type='expense' AND key IS DISTINCT FROM 'COGS'", [b.accountId]);
    if (!acc) fail('Choose what the expense was for.');
    const from = await moneyAccount(c, b.paidFrom);
    const { rows: [e] } = await c.query('INSERT INTO expenses(date,showroom_id,account_id,amount,gst,paid_from,note,created_by) VALUES($1,$2,$3,$4,$5,$6,$7,$8) RETURNING id',
      [date, shop, acc.id, amount, gst, from.id, String(b.note || '').slice(0, 200), req.user.id]);
    await post(c, { date, showroomId: shop, refType: 'expense', refId: e.id, narration: `${acc.name}${b.note ? ' – ' + b.note : ''}`, userId: req.user.id, lines: [
      { accountId: acc.id, amount, side: 'dr' }, { key: 'GST_IN', amount: gst, side: 'dr' }, { accountId: from.id, amount: round2(amount + gst), side: 'cr' }] });
  });
  res.json({ ok: true });
}));

// ---------- owner-only: manual entries, product cost, opening stock ----------
r.post('/journal', requireOwner, wrap(async (req, res) => {
  const b = req.body, date = isoDate(b.date) || new Date().toISOString().slice(0, 10);
  const lines = (b.lines || []).map(l => ({ accountId: +l.accountId, amount: round2(+l.debit || 0) || round2(+l.credit || 0), side: +l.debit > 0 ? 'dr' : 'cr' })).filter(l => l.accountId && l.amount > 0);
  if (lines.length < 2) fail('An entry needs at least one debit and one credit line.');
  if (!String(b.narration || '').trim()) fail('Write a short description of the entry.');
  await tx(c => post(c, { date, refType: 'manual', narration: b.narration.trim(), userId: req.user.id, lines }));
  res.json({ ok: true });
}));

r.put('/products/:id/cost', requireOwner, wrap(async (req, res) => {
  const cost = round2(+req.body.cost);
  if (!(cost >= 0)) fail('Enter the purchase cost (before GST).');
  await q('UPDATE products SET avg_cost=$2 WHERE id=$1', [req.params.id, cost]);
  res.json({ ok: true });
}));

// One-time: value the stock you already had at its cost, against owner's capital.
r.post('/opening-stock', requireOwner, wrap(async (req, res) => {
  const out = await tx(async c => {
    const { rows: [done] } = await c.query("SELECT 1 FROM journal WHERE ref_type='opening_stock'");
    if (done) fail('Opening stock has already been entered in the books.');
    const { rows: [{ v }] } = await c.query('SELECT COALESCE(SUM(s.qty*p.avg_cost),0) AS v FROM stock s JOIN products p ON p.id=s.product_id');
    if (!(v > 0)) fail('Set the purchase cost of your products first, so the stock has a value.');
    await post(c, { date: isoDate(req.body.date) || new Date().toISOString().slice(0, 10), refType: 'opening_stock', refId: 1, narration: 'Opening stock at cost', userId: req.user.id,
      lines: [{ key: 'STOCK', amount: v, side: 'dr' }, { key: 'CAPITAL', amount: v, side: 'cr' }] });
    return { value: round2(v) };
  });
  res.json(out);
}));

// ---------- reports (owner) ----------
async function sums({ from = null, to, showroom = null }) {
  const { rows } = await q(`SELECT a.id,a.key,a.name,a.type,a.kind, COALESCE(SUM(l.debit),0) AS dr, COALESCE(SUM(l.credit),0) AS cr
    FROM accounts a LEFT JOIN journal_lines l ON l.account_id=a.id
      AND l.journal_id IN (SELECT id FROM journal WHERE date <= $2 AND ($1::date IS NULL OR date >= $1) AND ($3::int IS NULL OR showroom_id=$3))
    GROUP BY a.id ORDER BY a.id`, [from, to, showroom]);
  return rows.map(a => ({ ...a, balance: round2(NORMAL_DEBIT(a.type) ? a.dr - a.cr : a.cr - a.dr) }));
}
const today = () => new Date().toISOString().slice(0, 10);
const fyStart = () => { const d = new Date(); const y = d.getMonth() >= 3 ? d.getFullYear() : d.getFullYear() - 1; return `${y}-04-01`; };

r.get('/reports/pl', requireOwner, wrap(async (req, res) => {
  const from = isoDate(req.query.from) || fyStart(), to = isoDate(req.query.to) || today();
  const showroom = req.query.showroom && req.query.showroom !== 'all' ? +req.query.showroom : null;
  const a = await sums({ from, to, showroom });
  const sales = a.find(x => x.key === 'SALES').balance, cogs = a.find(x => x.key === 'COGS').balance;
  const otherIncome = a.filter(x => x.type === 'income' && x.key !== 'SALES' && x.balance);
  const expenses = a.filter(x => x.type === 'expense' && x.key !== 'COGS' && x.balance);
  const gross = round2(sales - cogs), net = round2(gross + otherIncome.reduce((s, x) => s + x.balance, 0) - expenses.reduce((s, x) => s + x.balance, 0));
  const unpriced = (await q(`SELECT COUNT(*)::int AS n FROM bill_items i JOIN bills b ON b.id=i.bill_id WHERE i.cost=0 AND b.date BETWEEN $1 AND $2 AND ($3::int IS NULL OR b.showroom_id=$3)`, [from, to, showroom])).rows[0].n;
  res.json({ from, to, sales, cogs, gross, otherIncome, expenses, net, unpricedLines: unpriced });
}));

r.get('/reports/bs', requireOwner, wrap(async (req, res) => {
  const asOf = isoDate(req.query.asOf) || today();
  const a = await sums({ to: asOf });
  const pick = t => a.filter(x => x.type === t && x.balance);
  const profit = round2(a.filter(x => x.type === 'income').reduce((s, x) => s + x.balance, 0) - a.filter(x => x.type === 'expense').reduce((s, x) => s + x.balance, 0));
  const assets = pick('asset'), liabilities = pick('liability'), equity = pick('equity');
  const tA = round2(assets.reduce((s, x) => s + x.balance, 0)), tL = round2(liabilities.reduce((s, x) => s + x.balance, 0)), tE = round2(equity.reduce((s, x) => s + x.balance, 0) + profit);
  res.json({ asOf, assets, liabilities, equity, profit, totalAssets: tA, totalLiabilities: tL, totalEquity: tE, balanced: Math.abs(tA - tL - tE) < 0.02 });
}));

r.get('/reports/tb', requireOwner, wrap(async (req, res) => {
  const asOf = isoDate(req.query.asOf) || today();
  const a = (await sums({ to: asOf })).filter(x => x.dr || x.cr).map(x => ({ id: x.id, name: x.name, type: x.type, dr: round2(Math.max(0, x.dr - x.cr)), cr: round2(Math.max(0, x.cr - x.dr)) }));
  res.json({ asOf, rows: a, totalDr: round2(a.reduce((s, x) => s + x.dr, 0)), totalCr: round2(a.reduce((s, x) => s + x.cr, 0)) });
}));

// Ledger for an account, a customer or a supplier, with opening and running balance.
r.get('/ledger', requireOwner, wrap(async (req, res) => {
  const from = isoDate(req.query.from) || fyStart(), to = isoDate(req.query.to) || today();
  let where, param, title, debitNormal;
  if (req.query.customerId) { where = 'l.customer_id=$1'; param = +req.query.customerId; debitNormal = true;
    title = (await q('SELECT name FROM customers WHERE id=$1', [param])).rows[0]?.name; }
  else if (req.query.supplierId) { where = 'l.supplier_id=$1'; param = +req.query.supplierId; debitNormal = false;
    title = (await q('SELECT name FROM suppliers WHERE id=$1', [param])).rows[0]?.name; }
  else { param = +req.query.accountId; const { rows: [a] } = await q('SELECT * FROM accounts WHERE id=$1', [param]);
    if (!a) fail('Pick an account.'); where = 'l.account_id=$1'; title = a.name; debitNormal = NORMAL_DEBIT(a.type); }
  if (!title) fail('Not found.', 404);
  const sign = (d, c) => (debitNormal ? d - c : c - d);
  const { rows: [o] } = await q(`SELECT COALESCE(SUM(l.debit),0) AS d, COALESCE(SUM(l.credit),0) AS c FROM journal_lines l JOIN journal j ON j.id=l.journal_id WHERE ${where} AND j.date < $2`, [param, from]);
  const { rows } = await q(`SELECT j.date,j.narration,j.ref_type AS "refType",j.ref_id AS "refId",l.debit,l.credit FROM journal_lines l JOIN journal j ON j.id=l.journal_id
    WHERE ${where} AND j.date BETWEEN $2 AND $3 ORDER BY j.date, j.id, l.id`, [param, from, to]);
  let bal = round2(sign(o.d, o.c));
  const opening = bal;
  const lines = rows.map(x => { bal = round2(bal + sign(x.debit, x.credit)); return { ...x, balance: bal }; });
  res.json({ title, from, to, debitNormal, opening, closing: bal, lines });
}));

// ---------- registers (owner): one report per book, with totals ----------
r.get('/registers/:kind', requireOwner, wrap(async (req, res) => {
  const from = isoDate(req.query.from) || fyStart(), to = isoDate(req.query.to) || today();
  const shop = req.query.showroom && req.query.showroom !== 'all' ? +req.query.showroom : null;
  const P = [from, to, shop];
  let cols, rows;
  switch (req.params.kind) {
    case 'sales':
      cols = ['Date', 'Bill no.', 'Type', 'Customer', 'Customer GSTIN', 'Showroom', 'Taxable', 'CGST', 'SGST', 'IGST', 'Total', 'Received', 'Balance'];
      rows = (await qa(`SELECT b.date,b.no,b.type,c.name,c.gstin,s.name AS shop,b.taxable,b.cgst,b.sgst,b.igst,b.total,b.paid,b.total-b.paid AS bal
        FROM bills b JOIN customers c ON c.id=b.customer_id JOIN showrooms s ON s.id=b.showroom_id
        WHERE b.date BETWEEN $1 AND $2 AND ($3::int IS NULL OR b.showroom_id=$3) ORDER BY b.date,b.id`, P)).rows; break;
    case 'purchases':
      cols = ['Date', 'Supplier invoice', 'Supplier', 'Supplier GSTIN', 'Showroom', 'Taxable', 'CGST', 'SGST', 'IGST', 'Total'];
      rows = (await qa(`SELECT p.date,p.invoice_no,su.name,su.gstin,s.name,p.taxable,p.cgst,p.sgst,p.igst,p.total
        FROM purchases p JOIN suppliers su ON su.id=p.supplier_id JOIN showrooms s ON s.id=p.showroom_id
        WHERE p.date BETWEEN $1 AND $2 AND ($3::int IS NULL OR p.showroom_id=$3) ORDER BY p.date,p.id`, P)).rows; break;
    case 'receipts':
      cols = ['Date', 'Customer', 'Against bill', 'Showroom', 'Mode', 'Amount'];
      rows = (await qa(`SELECT (p.at AT TIME ZONE 'Asia/Kolkata')::date AS d,c.name,b.no,s.name,p.mode,p.amount
        FROM payments p JOIN bills b ON b.id=p.bill_id JOIN customers c ON c.id=b.customer_id JOIN showrooms s ON s.id=b.showroom_id
        WHERE (p.at AT TIME ZONE 'Asia/Kolkata')::date BETWEEN $1 AND $2 AND ($3::int IS NULL OR b.showroom_id=$3) ORDER BY p.at`, P)).rows; break;
    case 'paid':
      cols = ['Date', 'Paid to', 'Paid from', 'Details', 'Amount'];
      rows = (await qa(`SELECT j.date, COALESCE(su.name, ea.name) AS who, ma.name AS frm, j.narration, ml.credit
        FROM journal j JOIN journal_lines ml ON ml.journal_id=j.id JOIN accounts ma ON ma.id=ml.account_id AND ma.kind IN ('cash','bank') AND ml.credit>0
        LEFT JOIN journal_lines sl ON sl.journal_id=j.id AND sl.supplier_id IS NOT NULL LEFT JOIN suppliers su ON su.id=sl.supplier_id
        LEFT JOIN expenses e ON j.ref_type='expense' AND e.id=j.ref_id LEFT JOIN accounts ea ON ea.id=e.account_id
        WHERE j.ref_type IN ('supplier_payment','expense') AND j.date BETWEEN $1 AND $2 AND ($3::int IS NULL OR j.showroom_id=$3 OR j.showroom_id IS NULL)
        ORDER BY j.date,j.id`, P)).rows; break;
    case 'expenses':
      cols = ['Expense head', 'Entries', 'Amount', 'GST', 'Total'];
      rows = (await qa(`SELECT a.name, COUNT(*)::int, SUM(e.amount), SUM(e.gst), SUM(e.amount+e.gst) FROM expenses e JOIN accounts a ON a.id=e.account_id
        WHERE e.date BETWEEN $1 AND $2 AND ($3::int IS NULL OR e.showroom_id=$3) GROUP BY a.name ORDER BY 5 DESC`, P)).rows; break;
    case 'debtors':
      cols = ['Customer', 'Type', 'Phone', 'Opening', 'Billed', 'Received', 'Balance due'];
      rows = (await qa(`SELECT c.name,c.type,c.phone,
          COALESCE(SUM(l.debit-l.credit) FILTER (WHERE j.date < $1),0),
          COALESCE(SUM(l.debit) FILTER (WHERE j.date BETWEEN $1 AND $2),0),
          COALESCE(SUM(l.credit) FILTER (WHERE j.date BETWEEN $1 AND $2),0),
          COALESCE(SUM(l.debit-l.credit) FILTER (WHERE j.date <= $2),0) AS bal
        FROM customers c JOIN journal_lines l ON l.customer_id=c.id JOIN journal j ON j.id=l.journal_id
        WHERE $3::int IS NULL OR j.showroom_id=$3 GROUP BY c.id HAVING COALESCE(SUM(l.debit-l.credit) FILTER (WHERE j.date <= $2),0) <> 0 ORDER BY bal DESC`, P)).rows; break;
    case 'creditors':
      cols = ['Supplier', 'GSTIN', 'Phone', 'Opening', 'Purchased', 'Paid', 'Balance payable'];
      rows = (await qa(`SELECT su.name,su.gstin,su.phone,
          COALESCE(SUM(l.credit-l.debit) FILTER (WHERE j.date < $1),0),
          COALESCE(SUM(l.credit) FILTER (WHERE j.date BETWEEN $1 AND $2),0),
          COALESCE(SUM(l.debit) FILTER (WHERE j.date BETWEEN $1 AND $2),0),
          COALESCE(SUM(l.credit-l.debit) FILTER (WHERE j.date <= $2),0) AS bal
        FROM suppliers su JOIN journal_lines l ON l.supplier_id=su.id JOIN journal j ON j.id=l.journal_id
        WHERE $3::int IS NULL OR j.showroom_id=$3 OR j.showroom_id IS NULL GROUP BY su.id HAVING COALESCE(SUM(l.credit-l.debit) FILTER (WHERE j.date <= $2),0) <> 0 ORDER BY bal DESC`, P)).rows; break;
    default: fail('Unknown register.', 404);
  }
  // money columns are the numeric ones after the text columns; total them
  const totals = cols.map((_, i) => rows.length && rows.every(r => typeof r[i] === 'number') && !/Entries/.test(cols[i]) ? round2(rows.reduce((s, r) => s + r[i], 0)) : null);
  res.json({ from, to, cols, rows, totals });
}));

export default r;
