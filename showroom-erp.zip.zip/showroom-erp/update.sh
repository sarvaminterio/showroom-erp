#!/usr/bin/env bash
# Update Showroom ERP to the latest version on GitHub. Keeps your settings, data and backups.
# Run:  bash ~/showroom-erp/update.sh
set -euo pipefail
REPO_ZIP="${REPO_ZIP:-$(cat "$HOME/.showroom-erp-source" 2>/dev/null || true)}"
if [ -z "$REPO_ZIP" ]; then
  read -rp "Download link of showroom-erp.zip on GitHub: " REPO_ZIP
  echo "$REPO_ZIP" > "$HOME/.showroom-erp-source"
fi
cd "$HOME"
echo "==> Downloading the latest version"
wget -q -O new.zip "$REPO_ZIP"
unzip -q -o new.zip && rm new.zip
cd showroom-erp
sed -i 's/"3000:3000"/"127.0.0.1:3000:3000"/' docker-compose.yml
echo "==> Rebuilding and restarting (the app is offline for 1-3 minutes)"
sudo docker compose up -d --build
for i in $(seq 1 90); do curl -fs localhost:3000/healthz >/dev/null 2>&1 && break; sleep 2; done
curl -fs localhost:3000/healthz >/dev/null && echo "✔ Updated and running." || { echo "The app did not start. Run: sudo docker compose logs app"; exit 1; }
