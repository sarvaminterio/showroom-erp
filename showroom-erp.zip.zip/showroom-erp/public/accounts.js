// Purchases, expenses and accounting screens (loaded after app.js).
let ACC = { accounts: [], suppliers: [] };
const todayISO = () => new Date(Date.now() + 330 * 60e3).toISOString().slice(0, 10);
const fyStartISO = () => { const d = new Date(); return `${d.getMonth() >= 3 ? d.getFullYear() : d.getFullYear() - 1}-04-01`; };
const money = n => (n < 0 ? '− ' : '') + inr(Math.abs(n));
const acctOpts = (filter, sel) => ACC.accounts.filter(filter).map(a => `<option value="${a.id}" ${a.id == sel ? 'selected' : ''}>${esc(a.name)}</option>`).join('');
const isMoney = a => a.kind === 'cash' || a.kind === 'bank';
const isExpense = a => a.type === 'expense' && a.key !== 'COGS';
async function loadAcc() { [ACC.accounts, ACC.suppliers] = await Promise.all([api('/accounts'), api('/suppliers')]); }

// ---------- Purchases ----------
let pur = { lines: [] };
views.purchases = () => `<div class="row" style="justify-content:space-between"><div><h1>Purchases</h1>
  <p class="lead">Enter supplier bills. Stock goes up, the purchase cost is averaged, and the books are updated automatically.</p></div>
  <div style="flex:0;display:flex;gap:8px"><button class="btn ghost" style="white-space:nowrap" onclick="addSupplier()">Add supplier</button>
  <button class="btn" style="white-space:nowrap" onclick="newPurchase()">New purchase</button></div></div>
  <div id="purBox"><p class="muted">Loading…</p></div>`;
async function loadPurchases() {
  try {
    await loadAcc(); const list = await api('/purchases');
    $('#purBox').innerHTML = `<div class="grid g2">
    <div class="panel"><h2>Recent purchases</h2>${list.length ? `<table><tr><th>Date</th><th>Supplier / invoice</th><th>Showroom</th><th class="num">Total</th><th></th></tr>
      ${list.map(p => `<tr><td>${new Date(p.date).toLocaleDateString('en-IN')}</td><td>${esc(p.supplier)}<div class="muted">${esc(p.invoiceNo)} · ${p.items} item${p.items > 1 ? 's' : ''}</div></td>
      <td>${esc(shop(p.shop)?.name.split(',')[0])}</td><td class="num">${inr(p.total)}</td><td class="num"><button class="btn small ghost" onclick="openPurchase(${p.id})">Open</button></td></tr>`).join('')}</table>`
      : '<p class="muted">No purchases yet. Add a supplier, then click New purchase.</p>'}</div>
    <div class="panel"><h2>Suppliers</h2>${ACC.suppliers.length ? `<table><tr><th>Supplier</th><th class="num">You owe</th><th></th></tr>
      ${ACC.suppliers.map(s => `<tr><td>${esc(s.name)}<div class="muted">${esc(s.state)}${s.gstin ? ' · ' + esc(s.gstin) : ''}</div></td><td class="num">${s.balance ? inr(s.balance) : 'Nil'}</td>
      <td class="num" style="white-space:nowrap">${s.balance > 0 ? `<button class="btn small ghost" onclick="paySupplier(${s.id})">Pay</button>` : ''}
      ${isOwner() ? `<button class="btn small ghost" onclick="showLedger('supplierId',${s.id})">Ledger</button>` : ''}</td></tr>`).join('')}</table>`
      : '<p class="muted">No suppliers yet.</p>'}</div></div>`;
  } catch (e) { toast(e.message); }
}
function newPurchase() {
  if (!ACC.suppliers.length) return addSupplier();
  pur = { lines: [] };
  openModal(`<h2>New purchase</h2>
  <div class="row"><div><label for="ps">Supplier</label><select id="ps">${ACC.suppliers.map(s => `<option value="${s.id}">${esc(s.name)}</option>`).join('')}</select></div>
  <div><label for="pn">Supplier invoice no.</label><input id="pn"></div><div style="flex:0 0 150px"><label for="pd">Date</label><input id="pd" type="date" value="${todayISO()}"></div></div>
  <div style="margin-top:10px"><label for="psh">Goods received at</label><select id="psh">${shopOptions(true, curShop === 'all' ? S.showrooms[0]?.id : curShop)}</select></div>
  <h2 style="margin-top:16px">Items</h2>
  <div class="row"><div><label for="pp">Product</label><select id="pp" onchange="purRateHint()">${S.products.map(p => `<option value="${p.id}">${esc(p.name)} (${esc(p.brand)}, ${esc(p.size)})</option>`).join('')}</select></div>
  <div style="flex:0 0 90px"><label for="pq2" id="pqLabel">Qty</label><input id="pq2" type="number" min="1" value="1"></div>
  <div style="flex:0 0 120px"><label for="pr" id="prLabel">Rate</label><input id="pr" type="number" min="0" step="0.01"></div>
  <div style="flex:0 0 80px"><label for="pg">GST %</label><input id="pg" type="number" value="18"></div>
  <div style="flex:0"><button class="btn ghost" onclick="purAdd()">Add</button></div></div>
  <div id="purLines" style="margin-top:12px"></div>
  ${formButtons('savePurchase', 'Save purchase')}`);
  purRateHint(); purDraw();
}
function purRateHint() { const p = prod($('#pp').value); $('#pqLabel').textContent = p.cat === 'Tile' ? 'Boxes' : 'Pieces'; $('#prLabel').textContent = `Rate per ${unit(p)} (before GST)`; $('#pg').value = p.gstRate || 18; }
function purAdd() {
  const l = { pid: +$('#pp').value, qty: Math.trunc(+$('#pq2').value || 0), rate: +$('#pr').value || 0, gstRate: +$('#pg').value || 0 };
  if (l.qty <= 0 || !(l.rate > 0)) return toast('Enter the quantity and the rate per box or piece.');
  pur.lines.push(l); $('#pr').value = ''; $('#pq2').value = 1; purDraw();
}
function purDraw() {
  const t = pur.lines.reduce((a, l) => { const amt = l.qty * l.rate; a.taxable += amt; a.gst += amt * l.gstRate / 100; return a; }, { taxable: 0, gst: 0 });
  $('#purLines').innerHTML = pur.lines.length ? `<table><tr><th>Item</th><th class="num">Qty</th><th class="num">Rate</th><th class="num">Amount</th><th></th></tr>
    ${pur.lines.map((l, i) => { const p = prod(l.pid); return `<tr><td>${esc(p.name)}<div class="muted">${esc(p.brand)} · GST ${l.gstRate}%</div></td><td class="num">${l.qty} ${unit(p)}</td><td class="num">${inr(l.rate)}</td><td class="num">${inr(l.qty * l.rate)}</td>
    <td class="num"><button class="btn small ghost" onclick="pur.lines.splice(${i},1);purDraw()">Remove</button></td></tr>`; }).join('')}</table>
    <p style="text-align:right">Taxable ${inr(t.taxable)} + GST ${inr(t.gst)} = <b>${inr(Math.round(t.taxable + t.gst))}</b></p>
    <p class="muted" style="text-align:right">Check this total matches the supplier's bill before saving.</p>` : '<p class="muted">No items added yet.</p>';
}
function savePurchase(btn) {
  if (!pur.lines.length) return toast('Add at least one item.');
  act(async () => {
    const r = await api('/purchases', { supplierId: +$('#ps').value, invoiceNo: $('#pn').value, date: $('#pd').value, showroomId: +$('#psh').value, lines: pur.lines });
    closeModal(); await reload(); location.hash = '#purchases'; render(); toast(`Purchase saved: ${inr(r.total)}. Stock updated.`);
  }, btn);
}
async function openPurchase(id) {
  try {
    const p = await api('/purchases/' + id);
    openModal(`<h2>Purchase ${esc(p.invoice_no)}</h2><p class="muted">${esc(p.supplier)}${p.supplierGstin ? ' · GSTIN ' + esc(p.supplierGstin) : ''} · ${new Date(p.date).toLocaleDateString('en-IN')} · received at ${esc(p.showroom)}</p>
    <table><tr><th>Item</th><th class="num">Qty</th><th class="num">Rate</th><th class="num">Amount</th></tr>
    ${p.items.map(i => `<tr><td>${esc(i.name)}<div class="muted">${esc(i.brand)} ${esc(i.size)} · GST ${i.gst_rate}%</div></td><td class="num">${i.qty} ${i.cat === 'Tile' ? 'box' : 'pc'}</td><td class="num">${inr(i.rate)}</td><td class="num">${inr(i.amount)}</td></tr>`).join('')}</table>
    <table class="totals" style="max-width:300px;margin:12px 0 0 auto"><tr><td>Taxable</td><td class="num">${inr(p.taxable)}</td></tr>
    ${p.igst ? `<tr><td>IGST</td><td class="num">${inr(p.igst)}</td></tr>` : `<tr><td>CGST</td><td class="num">${inr(p.cgst)}</td></tr><tr><td>SGST</td><td class="num">${inr(p.sgst)}</td></tr>`}
    <tr><td>Total</td><td class="num">${inr(p.total)}</td></tr></table>
    <div class="row" style="justify-content:flex-end;margin-top:14px"><button class="btn" style="flex:0" onclick="closeModal()">Close</button></div>`);
  } catch (e) { toast(e.message); }
}
function addSupplier() {
  openModal(`<h2>Add supplier</h2>
  <div class="row"><div><label for="sn2">Name</label><input id="sn2"></div><div><label for="sp2">Phone</label><input id="sp2"></div></div>
  <div class="row" style="margin-top:10px"><div><label for="sg2">GSTIN</label><input id="sg2" maxlength="15"></div><div><label for="ss2">State</label><input id="ss2" value="${esc(billShop()?.state || '')}"></div></div>
  <p class="muted">The state decides whether purchases carry IGST or CGST + SGST.</p>${formButtons('saveSupplier', 'Save supplier')}`);
}
function saveSupplier(btn) { act(async () => { await api('/suppliers', { name: $('#sn2').value, phone: $('#sp2').value, gstin: $('#sg2').value, state: $('#ss2').value }); closeModal(); render(); toast('Supplier saved'); }, btn); }
function paySupplier(id) {
  const s = ACC.suppliers.find(x => x.id === id);
  openModal(`<h2>Pay ${esc(s.name)}</h2><p class="muted">You owe ${inr(s.balance)}</p>
  <div class="row"><div><label for="spa">Amount</label><input id="spa" type="number" value="${s.balance}"></div>
  <div><label for="spf">Paid from</label><select id="spf">${acctOpts(isMoney)}</select></div><div style="flex:0 0 150px"><label for="spd">Date</label><input id="spd" type="date" value="${todayISO()}"></div></div>
  <label for="spn" style="margin-top:10px">Note (optional)</label><input id="spn" placeholder="e.g. NEFT ref 1234">${formButtons(`saveSupPay.bind(null,${id})`, 'Record payment')}`);
}
function saveSupPay(id, btn) { act(async () => { await api('/supplier-payments', { supplierId: id, amount: +$('#spa').value, paidFrom: +$('#spf').value, date: $('#spd').value, note: $('#spn').value }); closeModal(); render(); toast('Payment recorded'); }, btn); }

// ---------- Expenses ----------
views.expenses = () => `<div class="row" style="justify-content:space-between"><div><h1>Expenses</h1>
  <p class="lead">Rent, salaries, electricity, freight and other running costs. They reduce profit in the P&amp;L.</p></div>
  <div style="flex:0"><button class="btn" style="white-space:nowrap" onclick="addExpense()">Add expense</button></div></div><div id="expBox"><p class="muted">Loading…</p></div>`;
async function loadExpenses() {
  try {
    await loadAcc(); const list = await api('/expenses');
    $('#expBox').innerHTML = `<div class="panel">${list.length ? `<table><tr><th>Date</th><th>For</th><th>Showroom</th><th>Paid from</th><th class="num">Amount</th></tr>
    ${list.map(e => `<tr><td>${new Date(e.date).toLocaleDateString('en-IN')}</td><td>${esc(e.account)}${e.note ? `<div class="muted">${esc(e.note)}</div>` : ''}</td>
    <td>${e.shop ? esc(shop(e.shop)?.name.split(',')[0]) : 'Shared'}</td><td>${esc(e.paidFrom)}</td><td class="num">${inr(e.amount + e.gst)}${e.gst ? `<div class="muted">incl. GST ${inr(e.gst)}</div>` : ''}</td></tr>`).join('')}</table>`
      : '<p class="muted">No expenses yet.</p>'}</div>`;
  } catch (e) { toast(e.message); }
}
function addExpense() {
  openModal(`<h2>Add expense</h2>
  <div class="row"><div><label for="ea">What for</label><select id="ea">${acctOpts(isExpense)}</select></div>
  <div style="flex:0 0 150px"><label for="ed">Date</label><input id="ed" type="date" value="${todayISO()}"></div></div>
  <div class="row" style="margin-top:10px"><div><label for="eam">Amount (before GST)</label><input id="eam" type="number" min="0"></div>
  <div><label for="eg">GST on the bill, if any</label><input id="eg" type="number" min="0" value="0"></div></div>
  <div class="row" style="margin-top:10px"><div><label for="ef">Paid from</label><select id="ef">${acctOpts(isMoney)}</select></div>
  <div><label for="es">Showroom</label><select id="es">${isOwner() ? '<option value="">Shared / head office</option>' : ''}${shopOptions(true, curShop)}</select></div></div>
  <label for="en" style="margin-top:10px">Note (optional)</label><input id="en" placeholder="e.g. November rent, Ring Road">
  ${isOwner() ? '<p class="muted">Need a category that isn\'t listed? Add it under Accounts → Chart of accounts.</p>' : ''}${formButtons('saveExpense', 'Save expense')}`);
}
function saveExpense(btn) { act(async () => { await api('/expenses', { accountId: +$('#ea').value, date: $('#ed').value, amount: +$('#eam').value, gst: +$('#eg').value, paidFrom: +$('#ef').value, showroomId: $('#es').value ? +$('#es').value : null, note: $('#en').value }); closeModal(); render(); toast('Expense saved'); }, btn); }

// ---------- Accounts & reports (owner) ----------
let rep = { tab: 'pl', from: fyStartISO(), to: todayISO(), showroom: 'all' };
views.reports = () => !isOwner() ? '<h1>Accounts</h1><p class="lead">Only the owner can see the accounts.</p>' : `<h1>Accounts</h1>
  <p class="lead">Books are kept automatically from bills, payments, purchases and expenses. Use these for running the business; your CA prepares the official statements.</p>
  <div class="seg" style="margin-bottom:14px;flex-wrap:wrap">${[['pl', 'Profit & Loss'], ['bs', 'Balance Sheet'], ['reg', 'Registers'], ['ledger', 'Ledgers'], ['tb', 'Trial balance'], ['coa', 'Chart of accounts'], ['setup', 'Opening balances']]
    .map(([k, n]) => `<button class="${rep.tab === k ? 'on' : ''}" onclick="rep.tab='${k}';render()">${n}</button>`).join('')}</div>
  <div id="repBox"><p class="muted">Loading…</p></div>`;
const dateBar = (withFrom, withShop) => `<div class="row" style="margin-bottom:14px">${withFrom ? `<div style="flex:0 0 170px"><label for="rf">From</label><input id="rf" type="date" value="${rep.from}" onchange="rep.from=this.value;loadReports()"></div>` : ''}
  <div style="flex:0 0 170px"><label for="rt">${withFrom ? 'To' : 'As on'}</label><input id="rt" type="date" value="${rep.to}" onchange="rep.to=this.value;loadReports()"></div>
  ${withShop ? `<div style="flex:0 0 240px"><label for="rsh">Showroom</label><select id="rsh" onchange="rep.showroom=this.value;loadReports()"><option value="all">All showrooms</option>${shopOptions(false, rep.showroom)}</select></div>` : ''}
  <div style="flex:0;align-self:end"><button class="btn ghost no-print" onclick="window.print()">Print</button></div></div>`;
const rowL = (name, amt, opts = '') => `<tr ${opts}><td>${esc(name)}</td><td class="num">${money(amt)}</td></tr>`;

async function loadReports() {
  const box = $('#repBox'); if (!box) return;
  try {
    await loadAcc();
    if (rep.tab === 'pl') {
      const d = await api(`/reports/pl?from=${rep.from}&to=${rep.to}&showroom=${rep.showroom}`);
      box.innerHTML = dateBar(true, true) + `<div class="panel" style="max-width:640px"><h2>Profit &amp; Loss, ${new Date(d.from).toLocaleDateString('en-IN')} to ${new Date(d.to).toLocaleDateString('en-IN')}</h2>
      <table>${rowL('Sales (excluding GST)', d.sales)}${rowL('Less: cost of goods sold', -d.cogs)}
      <tr style="font-weight:700"><td>Gross profit${d.sales ? ` <span class="muted">(${(d.gross / d.sales * 100).toFixed(1)}% margin)</span>` : ''}</td><td class="num">${money(d.gross)}</td></tr>
      ${d.otherIncome.filter(x => Math.abs(x.balance) >= 1).map(x => rowL('Add: ' + x.name, x.balance)).join('')}
      ${d.expenses.map(x => rowL('Less: ' + x.name, -x.balance)).join('')}
      <tr style="font-weight:700;font-size:17px;border-top:2px solid var(--ink)"><td>Net ${d.net >= 0 ? 'profit' : 'loss'}</td><td class="num" style="color:${d.net >= 0 ? 'var(--ok)' : 'var(--alert)'}">${money(d.net)}</td></tr></table>
      ${rep.showroom !== 'all' ? '<p class="muted">Shared / head-office expenses appear only in the all-showrooms view.</p>' : ''}
      ${d.unpricedLines ? `<p class="note">${d.unpricedLines} sold item line${d.unpricedLines > 1 ? 's have' : ' has'} no purchase cost, so gross profit is overstated. Set product costs under Products, and future sales will be correct.</p>` : ''}</div>`;
    } else if (rep.tab === 'bs') {
      const d = await api(`/reports/bs?asOf=${rep.to}`);
      const side = (title, rows, extra = '') => `<div class="panel"><h2>${title}</h2><table>${rows.map(x => `<tr><td><a href="#reports" onclick="showLedger('accountId',${x.id})">${esc(x.name)}</a></td><td class="num">${money(x.balance)}</td></tr>`).join('')}${extra}</table></div>`;
      box.innerHTML = dateBar(false, false) + `<div class="grid g2" style="grid-template-columns:1fr 1fr">
        ${side('Assets (what the business owns)', d.assets, `<tr style="font-weight:700;border-top:2px solid var(--ink)"><td>Total assets</td><td class="num">${money(d.totalAssets)}</td></tr>`)}
        <div>${side('Liabilities (what it owes)', d.liabilities, `<tr style="font-weight:700"><td>Total liabilities</td><td class="num">${money(d.totalLiabilities)}</td></tr>`)}
        <div style="height:16px"></div>${side("Owner's equity", d.equity, `${rowL('Profit to date', d.profit)}<tr style="font-weight:700"><td>Total equity</td><td class="num">${money(d.totalEquity)}</td></tr>`)}</div></div>
        <p class="muted" style="margin-top:12px">${d.balanced ? '✔ Balanced: assets equal liabilities plus equity.' : '⚠ The sheet does not balance. Please report this.'} Click any account to open its ledger.</p>
        ${d.assets.some(x => x.balance < 0) ? '<p class="note">A negative cash or bank balance usually means opening balances haven\'t been entered yet. See the Opening balances tab.</p>' : ''}`;
    } else if (rep.tab === 'reg') {
      await loadRegister(box);
    } else if (rep.tab === 'tb') {
      const d = await api(`/reports/tb?asOf=${rep.to}`);
      box.innerHTML = dateBar(false, false) + `<div class="panel" style="max-width:720px"><table><tr><th>Account</th><th class="num">Debit</th><th class="num">Credit</th></tr>
      ${d.rows.map(x => `<tr><td><a href="#reports" onclick="showLedger('accountId',${x.id})">${esc(x.name)}</a></td><td class="num">${x.dr ? inr(x.dr) : ''}</td><td class="num">${x.cr ? inr(x.cr) : ''}</td></tr>`).join('')}
      <tr style="font-weight:700;border-top:2px solid var(--ink)"><td>Total</td><td class="num">${inr(d.totalDr)}</td><td class="num">${inr(d.totalCr)}</td></tr></table></div>`;
    } else if (rep.tab === 'ledger') {
      box.innerHTML = `<div class="row" style="margin-bottom:14px"><div><label for="lk">Ledger</label><select id="lk" onchange="rep.ledger=this.value;loadReports()">
        <optgroup label="Customers">${S.customers.map(c => `<option value="customerId:${c.id}">${esc(c.name)}</option>`).join('')}</optgroup>
        <optgroup label="Suppliers">${ACC.suppliers.map(s => `<option value="supplierId:${s.id}">${esc(s.name)}</option>`).join('')}</optgroup>
        <optgroup label="Accounts">${ACC.accounts.map(a => `<option value="accountId:${a.id}">${esc(a.name)}</option>`).join('')}</optgroup></select></div>
        <div style="flex:0 0 170px"><label for="lf">From</label><input id="lf" type="date" value="${rep.from}" onchange="rep.from=this.value;loadReports()"></div>
        <div style="flex:0 0 170px"><label for="lt">To</label><input id="lt" type="date" value="${rep.to}" onchange="rep.to=this.value;loadReports()"></div>
        <div style="flex:0;align-self:end"><button class="btn ghost no-print" onclick="window.print()">Print</button></div></div><div id="ledgerBox"></div>`;
      rep.ledger = rep.ledger || (S.customers[0] ? `customerId:${S.customers[0].id}` : `accountId:${ACC.accounts[0]?.id}`);
      $('#lk').value = rep.ledger;
      const [k, id] = rep.ledger.split(':'), d = await api(`/ledger?${k}=${id}&from=${rep.from}&to=${rep.to}`);
      const label = b => b === 0 ? 'Nil' : (k === 'customerId' ? (b > 0 ? `${inr(b)} receivable` : `${inr(-b)} advance`) : k === 'supplierId' ? (b > 0 ? `${inr(b)} payable` : `${inr(-b)} advance`) : money(b));
      $('#ledgerBox').innerHTML = `<div class="panel"><h2>${esc(d.title)}</h2><table><tr><th>Date</th><th>Particulars</th><th class="num">Debit</th><th class="num">Credit</th><th class="num">Balance</th></tr>
        <tr class="muted"><td>${new Date(d.from).toLocaleDateString('en-IN')}</td><td>Opening balance</td><td></td><td></td><td class="num">${label(d.opening)}</td></tr>
        ${d.lines.map(l => `<tr><td>${new Date(l.date).toLocaleDateString('en-IN')}</td><td>${esc(l.narration)}</td><td class="num">${l.debit ? inr(l.debit) : ''}</td><td class="num">${l.credit ? inr(l.credit) : ''}</td><td class="num">${label(l.balance)}</td></tr>`).join('')}
        <tr style="font-weight:700;border-top:2px solid var(--ink)"><td></td><td>Closing balance</td><td></td><td></td><td class="num">${label(d.closing)}</td></tr></table></div>`;
    } else if (rep.tab === 'coa') {
      const groups = [['asset', 'Assets'], ['liability', 'Liabilities'], ['equity', 'Equity'], ['income', 'Income'], ['expense', 'Expenses']];
      box.innerHTML = `<div class="row" style="justify-content:flex-end;margin-bottom:12px"><div style="flex:0;display:flex;gap:8px">
        <button class="btn ghost" style="white-space:nowrap" onclick="addAccount()">Add account</button><button class="btn" style="white-space:nowrap" onclick="journalEntry()">Journal entry</button></div></div>
        <div class="grid g2" style="grid-template-columns:1fr 1fr">${groups.map(([t, n]) => `<div class="panel"><h2>${n}</h2><table>${ACC.accounts.filter(a => a.type === t).map(a => `<tr><td><a href="#reports" onclick="showLedger('accountId',${a.id})">${esc(a.name)}</a>${a.kind ? ` <span class="pill">${a.kind}</span>` : ''}</td><td class="num">${money(a.balance)}</td></tr>`).join('')}</table></div>`).join('')}</div>`;
    } else if (rep.tab === 'setup') {
      const noCost = S.products.filter(p => !p.cost).length;
      box.innerHTML = `<div class="panel" style="max-width:760px"><h2>Getting your books started</h2>
        <p><b>1. Set the purchase cost of each product.</b> ${noCost ? `<span class="pill low">${noCost} product${noCost > 1 ? 's' : ''} without a cost</span>` : '<span class="pill ok">All products have a cost</span>'}<br>
        <span class="muted">Go to Products and click the cost next to each item (per box or piece, before GST). Purchases you enter later keep it updated automatically.</span><br><a class="btn small ghost" href="#products" style="display:inline-block;margin-top:6px">Open Products</a></p>
        <p style="margin-top:16px"><b>2. Put your existing stock into the books.</b><br><span class="muted">Values all stock you already hold at its cost, as owner's capital. Do this once, after step 1.</span><br>
        <button class="btn small ghost" style="margin-top:6px" onclick="openingStock(this)">Post opening stock value</button></p>
        <p style="margin-top:16px"><b>3. Enter opening cash, bank, loans and supplier dues.</b><br><span class="muted">Use a Journal entry. Example: cash in hand ₹50,000 → Debit "Cash in hand" 50,000, Credit "Owner's capital" 50,000. Supplier dues: Debit "Owner's capital", Credit "Suppliers". Ask your CA for the figures as on your start date.</span><br>
        <button class="btn small ghost" style="margin-top:6px" onclick="journalEntry()">New journal entry</button></p></div>`;
    }
  } catch (e) { box.innerHTML = `<p class="muted">${esc(e.message)}</p>`; }
}
function showLedger(kind, id) { rep.tab = 'ledger'; rep.ledger = `${kind}:${id}`; closeModal(); if (location.hash !== '#reports') location.hash = '#reports'; else render(); }
function openingStock(btn) { if (!confirm('Post the value of all current stock into the books? This can only be done once.')) return; act(async () => { const r = await api('/opening-stock', { date: rep.from }); toast(`Opening stock of ${inr(r.value)} entered in the books.`); loadReports(); }, btn); }
function addAccount() {
  openModal(`<h2>Add account</h2><div class="row"><div><label for="an">Name</label><input id="an" placeholder="e.g. Packing material, HDFC Bank"></div>
  <div><label for="at">Type</label><select id="at" onchange="$('#akw').style.display=this.value==='asset'?'':'none'"><option value="expense">Expense</option><option value="income">Income</option><option value="asset">Asset (incl. bank account)</option><option value="liability">Liability</option><option value="equity">Equity</option></select></div></div>
  <div id="akw" style="display:none;margin-top:10px"><label for="ak">Is it a money account?</label><select id="ak"><option value="">No</option><option value="bank">Yes, a bank account</option><option value="cash">Yes, a cash box</option></select></div>
  ${formButtons('saveAccount', 'Save account')}`);
}
function saveAccount(btn) { act(async () => { await api('/accounts', { name: $('#an').value, type: $('#at').value, kind: $('#ak').value }); closeModal(); loadReports(); toast('Account added'); }, btn); }
let jl = [];
function journalEntry() {
  jl = [{ accountId: '', debit: '', credit: '' }, { accountId: '', debit: '', credit: '' }];
  openModal(`<h2>Journal entry</h2><p class="muted">For opening balances, capital, loans, drawings and corrections. Total debits must equal total credits.</p>
  <div class="row"><div><label for="jn">Description</label><input id="jn" placeholder="e.g. Opening cash in hand"></div><div style="flex:0 0 160px"><label for="jd">Date</label><input id="jd" type="date" value="${todayISO()}"></div></div>
  <div id="jlBox" style="margin-top:12px"></div><button class="btn small ghost" onclick="jl.push({accountId:'',debit:'',credit:''});jDraw()">Add line</button>${formButtons('saveJournal', 'Save entry')}`);
  jDraw();
}
function jDraw() {
  const dr = jl.reduce((s, l) => s + (+l.debit || 0), 0), cr = jl.reduce((s, l) => s + (+l.credit || 0), 0);
  $('#jlBox').innerHTML = `<table><tr><th>Account</th><th class="num">Debit</th><th class="num">Credit</th></tr>
  ${jl.map((l, i) => `<tr><td><select onchange="jl[${i}].accountId=this.value" aria-label="Account"><option value="">Choose…</option>${acctOpts(() => true, l.accountId)}</select></td>
  <td><input type="number" min="0" value="${l.debit}" aria-label="Debit" onchange="jl[${i}].debit=this.value;jl[${i}].credit='';jDraw()"></td>
  <td><input type="number" min="0" value="${l.credit}" aria-label="Credit" onchange="jl[${i}].credit=this.value;jl[${i}].debit='';jDraw()"></td></tr>`).join('')}
  <tr style="font-weight:700"><td>Total ${Math.abs(dr - cr) < 0.01 && dr ? '<span class="pill ok">Balanced</span>' : dr || cr ? `<span class="pill low">Difference ${inr(Math.abs(dr - cr))}</span>` : ''}</td><td class="num">${inr(dr)}</td><td class="num">${inr(cr)}</td></tr></table>`;
}
function saveJournal(btn) { act(async () => { await api('/journal', { narration: $('#jn').value, date: $('#jd').value, lines: jl }); closeModal(); loadReports(); toast('Entry saved'); }, btn); }


// ---------- registers ----------
const REGS = [['sales', 'Sales'], ['purchases', 'Purchases'], ['receipts', 'Payments received'], ['paid', 'Payments made'], ['expenses', 'Expenses by head'], ['debtors', 'Debtors (customers)'], ['creditors', 'Creditors (suppliers)']];
let regData = null;
async function loadRegister(box) {
  rep.reg = rep.reg || 'sales';
  const d = regData = await api(`/registers/${rep.reg}?from=${rep.from}&to=${rep.to}&showroom=${rep.showroom}`);
  const typeNames = { GST: 'Tax invoice', BOS: 'Bill of supply', EST: 'Estimate' };
  const cell = (v, i) => v == null ? '' : typeof v === 'number' ? (/Entries/.test(d.cols[i]) ? v : inr(v)) : /^\d{4}-\d{2}-\d{2}$/.test(v) ? new Date(v).toLocaleDateString('en-IN') : esc(typeNames[v] || v);
  const numCol = i => d.rows.length && typeof d.rows[0][i] === 'number';
  box.innerHTML = `<div class="row" style="margin-bottom:14px">
    <div style="flex:0 0 220px"><label for="rk">Register</label><select id="rk" onchange="rep.reg=this.value;loadReports()">${REGS.map(([k, n]) => `<option value="${k}" ${rep.reg === k ? 'selected' : ''}>${n}</option>`).join('')}</select></div>
    <div style="flex:0 0 160px"><label for="rgf">From</label><input id="rgf" type="date" value="${rep.from}" onchange="rep.from=this.value;loadReports()"></div>
    <div style="flex:0 0 160px"><label for="rgt">To</label><input id="rgt" type="date" value="${rep.to}" onchange="rep.to=this.value;loadReports()"></div>
    <div style="flex:0 0 200px"><label for="rgs">Showroom</label><select id="rgs" onchange="rep.showroom=this.value;loadReports()"><option value="all">All showrooms</option>${shopOptions(false, rep.showroom)}</select></div>
    <div style="flex:0;align-self:end;display:flex;gap:8px" class="no-print"><button class="btn ghost" style="white-space:nowrap" onclick="downloadRegister()">Download for Excel</button><button class="btn ghost" onclick="window.print()">Print</button></div></div>
    <div class="panel" style="overflow:auto"><h2>${REGS.find(x => x[0] === rep.reg)[1]} · ${new Date(d.from).toLocaleDateString('en-IN')} to ${new Date(d.to).toLocaleDateString('en-IN')}</h2>
    ${d.rows.length ? `<table><tr>${d.cols.map((c, i) => `<th class="${numCol(i) ? 'num' : ''}">${c}</th>`).join('')}</tr>
    ${d.rows.map(r => `<tr>${r.map((v, i) => `<td class="${typeof v === 'number' ? 'num' : ''}" style="white-space:nowrap">${cell(v, i)}</td>`).join('')}</tr>`).join('')}
    <tr style="font-weight:700;border-top:2px solid var(--ink)">${d.totals.map((t, i) => `<td class="num">${i === 0 ? `Total (${d.rows.length})` : t == null ? '' : inr(t)}</td>`).join('')}</tr></table>`
    : '<p class="muted">Nothing in this period.</p>'}
    ${['debtors', 'creditors'].includes(rep.reg) ? '<p class="muted">Balances are as on the "To" date. Click Ledgers to see each party\'s full statement.</p>' : ''}</div>`;
}
function downloadRegister() {
  const d = regData; if (!d) return;
  const q = v => v == null ? '' : `"${String(v).replace(/"/g, '""')}"`;
  const csv = [d.cols.map(q).join(','), ...d.rows.map(r => r.map(q).join(',')), d.totals.map((t, i) => q(i === 0 ? 'Total' : t)).join(',')].join('\r\n');
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8' }));
  a.download = `${rep.reg}-register-${d.from}-to-${d.to}.csv`; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 1000);
}

// ---------- product cost (owner) ----------
function editCost(id) {
  const p = prod(id);
  openModal(`<h2>Purchase cost: ${esc(p.name)}</h2><p class="muted">What one ${unit(p)} costs you from the supplier, before GST. Used to work out profit. Purchases you enter update it automatically.</p>
  <label for="pc2">Cost per ${unit(p)} (₹)</label><input id="pc2" type="number" min="0" step="0.01" value="${p.cost || ''}">${formButtons(`saveCost.bind(null,${id})`, 'Save cost')}`);
}
function saveCost(id, btn) { act(async () => { const r = await fetch('/api/products/' + id + '/cost', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ cost: +$('#pc2').value }) }); if (!r.ok) throw new Error((await r.json()).error); closeModal(); await reload(); toast('Cost saved'); }, btn); }

// ---------- hook into the router ----------
window.onView = v => { if (v === 'purchases') loadPurchases(); if (v === 'expenses') loadExpenses(); if (v === 'reports') loadReports(); };
