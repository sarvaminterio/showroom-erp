// Showroom ERP – browser app. All data comes from and is saved to the server.
let S = { showrooms: [], products: [], customers: [], bills: [], me: null, aiEnabled: false, business: '' };
let curShop = 'all', quote = { cust: null, lines: [], discount: 0, type: 'GST' }, chat = [], billFilter = '';

// ---------- helpers ----------
const $ = s => document.querySelector(s);
const inr = n => '₹' + Math.round(n).toLocaleString('en-IN');
const prod = id => S.products.find(p => p.id == id);
const cust = id => S.customers.find(c => c.id == id);
const shop = id => S.showrooms.find(s => s.id == id);
const unit = p => (p.cat === 'Tile' ? 'box' : 'pc');
const stk = (p, sid = curShop) => (sid === 'all' ? Object.values(p.stock).reduce((a, b) => a + b, 0) : p.stock[sid] || 0);
const lowAt = p => (p.cat === 'Tile' ? 30 : 6);
const typeName = { GST: 'Tax invoice', EST: 'Estimate (non-GST)', BOS: 'Bill of supply' };
const isOwner = () => S.me?.role === 'owner';
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
function toast(m) { const t = $('#toast'); t.textContent = m; t.style.display = 'block'; clearTimeout(t._t); t._t = setTimeout(() => (t.style.display = 'none'), 3200); }
const swatch = p => `<div class="swatch" style="background-color:${esc(p.color)}" aria-hidden="true"></div>`;
function openModal(h) { $('#modalBody').innerHTML = h; $('#modal').classList.add('open'); }
function closeModal() { $('#modal').classList.remove('open'); }
$('#modal').addEventListener('click', e => { if (e.target.id === 'modal') closeModal(); });
const billShop = () => (curShop === 'all' ? S.showrooms[0] : shop(curShop));
const effectiveType = (s, t) => (s.scheme === 'Composition' && t === 'GST' ? 'BOS' : t);
function busy(btn, label) { if (btn) { btn.disabled = !!label; if (label) { btn._t = btn.textContent; btn.textContent = label; } else if (btn._t) btn.textContent = btn._t; } }

async function api(path, body) {
  const r = await fetch('/api' + path, body === undefined ? {} : { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
  const d = await r.json().catch(() => ({}));
  if (r.status === 401 && path !== '/auth/login') { showLogin(); throw new Error('Please sign in.'); }
  if (!r.ok) throw new Error(d.error || 'Something went wrong.');
  return d;
}
// Run an action; show its error in a toast instead of failing silently.
async function act(fn, btn, label = 'Saving…') { busy(btn, label); try { await fn(); } catch (e) { toast(e.message); } finally { busy(btn); } }

// Preview maths only; the server recalculates everything when saving.
function lineCalc(l) {
  const p = prod(l.pid);
  if (p.cat === 'Tile') { const qty = Math.ceil((l.area * (1 + l.wastage / 100)) / p.sqftPerBox); return { qty, unit: 'box', sqft: qty * p.sqftPerBox, amount: qty * p.sqftPerBox * p.rate }; }
  return { qty: l.qty, unit: 'pc', amount: l.qty * p.rate };
}
function totals(qt, s) {
  const d = qt.discount / 100, sub = qt.lines.reduce((a, l) => a + lineCalc(l).amount, 0), taxable = sub * (1 - d);
  const taxed = qt.type === 'GST', gst = taxed ? qt.lines.reduce((a, l) => a + lineCalc(l).amount * (1 - d) * prod(l.pid).gstRate / 100, 0) : 0;
  return { sub, disc: sub - taxable, taxable, gst, taxed, inter: cust(qt.cust)?.state !== s.state, total: Math.round(taxable + gst) };
}

// ---------- auth & loading ----------
function showLogin() { $('#appView').style.display = 'none'; $('#loginView').style.display = 'block'; $('#lemail').focus(); }
$('#loginBtn').onclick = () => act(async () => {
  $('#lerr').textContent = '';
  try { await api('/auth/login', { email: $('#lemail').value, password: $('#lpass').value }); await load(); }
  catch (e) { $('#lerr').textContent = e.message; }
}, $('#loginBtn'), 'Signing in…');
$('#lpass').addEventListener('keydown', e => { if (e.key === 'Enter') $('#loginBtn').click(); });
async function logout() { await api('/auth/logout', {}); location.hash = ''; showLogin(); }

async function load() {
  S = await api('/bootstrap');
  $('#loginView').style.display = 'none'; $('#appView').style.display = '';
  $('#bizName').textContent = S.business;
  $('#meBox').innerHTML = `${esc(S.me.name)} (${S.me.role})<br><button onclick="logout()">Sign out</button>`;
  document.querySelectorAll('nav a[href="#reports"], nav a[href="#analytics"]').forEach(a => a.style.display = isOwner() ? '' : 'none');
  if (!isOwner()) curShop = String(S.me.showroom_id);
  else if (curShop !== 'all' && !shop(curShop)) curShop = 'all';
  const sel = $('#shopSel');
  sel.innerHTML = (isOwner() ? '<option value="all">All showrooms</option>' : '') + S.showrooms.filter(s => isOwner() || s.id === S.me.showroom_id).map(s => `<option value="${s.id}">${esc(s.name)}</option>`).join('');
  sel.value = curShop; sel.onchange = () => { curShop = sel.value; render(); };
  if (!quote.cust && S.customers[0]) quote.cust = S.customers[0].id;
  render();
}
const reload = async () => { const keep = curShop; await load(); curShop = keep; render(); };

// ---------- views ----------
const views = {
  dashboard() {
    const list = S.bills.filter(i => curShop === 'all' || i.shop == curShop);
    const gst = list.filter(i => i.type !== 'EST').reduce((s, i) => s + i.total, 0), est = list.filter(i => i.type === 'EST').reduce((s, i) => s + i.total, 0);
    const due = list.reduce((s, i) => s + i.total - i.paid, 0);
    const lows = S.products.filter(p => stk(p) < lowAt(p) * (curShop === 'all' ? S.showrooms.length : 1));
    if (!S.showrooms.length) return `<h1>Welcome</h1><p class="lead">Start by adding your first showroom with its GSTIN.</p><a class="btn" href="#showrooms">Add a showroom</a>`;
    return `<h1>Overview</h1><p class="lead">${curShop === 'all' ? 'All showrooms' : esc(shop(curShop).name)}, last 500 bills.</p>
    ${isOwner() ? '<div class="panel" id="digestBox" style="margin-bottom:16px"><h2>Today\'s payment briefing</h2><p class="muted">Loading…</p></div>' : ''}
    <div class="grid g4">
      <div class="panel stat"><b>${inr(gst)}</b><span>Tax invoices & bills of supply</span></div>
      <div class="panel stat"><b>${inr(est)}</b><span>Non-GST estimates</span></div>
      <div class="panel stat"><b>${inr(due)}</b><span>Unpaid on bills</span></div>
      <div class="panel stat"><b>${lows.length}</b><span>Items running low</span></div>
    </div>
    ${curShop === 'all' ? `<div class="panel" style="margin-top:16px"><h2>By showroom</h2><table><tr><th>Showroom</th><th>GSTIN</th><th>Scheme</th><th class="num">Billed</th><th class="num">Unpaid</th></tr>
     ${S.showrooms.map(s => { const l = S.bills.filter(i => i.shop == s.id); return `<tr><td>${esc(s.name)}</td><td class="muted">${s.gstin}</td><td>${s.scheme}</td><td class="num">${inr(l.reduce((a, i) => a + i.total, 0))}</td><td class="num">${inr(l.reduce((a, i) => a + i.total - i.paid, 0))}</td></tr>`; }).join('')}</table></div>` : ''}
    <div class="grid g2" style="margin-top:16px">
      <div class="panel"><h2>Recent bills</h2>${invoiceTable(list.slice(-5).reverse())}</div>
      <div class="panel"><h2>Reorder soon</h2><table>${lows.map(p => `<tr><td><div class="prod-cell">${swatch(p)}<div>${esc(p.name)}<div class="muted">${esc(p.brand)}</div></div></div></td><td class="num"><span class="pill low">${stk(p)} ${unit(p)}</span></td></tr>`).join('') || '<tr><td>All stock is healthy.</td></tr>'}</table></div>
    </div>`;
  },
  products() {
    return `<div class="row" style="justify-content:space-between"><div><h1>Products</h1><p class="lead">One catalogue shared by every showroom. Tiles are priced per sq ft and sold by the box.</p></div>
    ${isOwner() ? '<div style="flex:0"><button class="btn" onclick="addProduct()">Add product</button></div>' : ''}</div>
    <div class="panel"><div class="row" style="margin-bottom:12px"><div><input id="pq" placeholder="Search by name, brand or size" oninput="filterProducts()" aria-label="Search products"></div>
    <div style="flex:0 0 180px"><select id="pc" onchange="filterProducts()" aria-label="Category"><option value="">All categories</option><option>Tile</option><option>Sanitaryware</option><option>CP Fitting</option></select></div></div>
    <div id="ptable">${productTable(S.products)}</div></div>`;
  },
  inventory() {
    const shops = S.showrooms;
    return `<div class="row" style="justify-content:space-between"><div><h1>Inventory</h1><p class="lead">Stock in every showroom, by batch and shade. Every change is recorded with who made it.</p></div>
    <div style="flex:0"><button class="btn" onclick="transfer()">Transfer stock</button></div></div>
    <div class="panel" style="overflow:auto"><table class="stockgrid"><tr><th>Item</th><th>Batch / shade</th>${shops.map(s => `<th class="num">${esc(s.name.split(',')[0])}</th>`).join('')}<th class="num">Total</th><th></th></tr>
    ${S.products.map(p => `<tr><td><div class="prod-cell">${swatch(p)}<div>${esc(p.name)}<div class="muted">${esc(p.brand)} · ${esc(p.size)}</div></div></div></td>
    <td>${p.batch ? `${esc(p.batch)}<div class="muted">Shade ${esc(p.shade)}</div>` : '–'}</td>
    ${shops.map(s => { const n = p.stock[s.id] || 0; return `<td class="num">${n < lowAt(p) ? `<span class="pill low">${n}</span>` : n}</td>`; }).join('')}
    <td class="num"><b>${stk(p, 'all')}</b> ${unit(p)}</td><td class="num"><button class="btn small ghost" onclick="adjustStock(${p.id})">Adjust</button></td></tr>`).join('')}</table></div>`;
  },
  quotation() {
    const s = billShop();
    if (!s || !S.products.length || !S.customers.length) return `<h1>New bill</h1><p class="lead">Add at least one showroom, product and customer first.</p>`;
    const type = effectiveType(s, quote.type), t = totals({ ...quote, type }, s);
    return `<h1>New bill</h1><p class="lead">Billing from <b>${esc(s.name)}</b>, GSTIN ${s.gstin}${s.scheme === 'Composition' ? ' (composition scheme)' : ''}.</p>
    ${curShop === 'all' ? `<div class="panel" style="margin-bottom:16px">Pick a showroom from the menu to bill from it. Until then bills go to <b>${esc(s.name)}</b>.</div>` : ''}
    <div class="grid g2">
     <div class="panel"><h2>Add an item</h2>
      <label for="qp">Product</label><select id="qp" onchange="qpChange()">${S.products.map(p => `<option value="${p.id}">${esc(p.name)} (${esc(p.brand)})</option>`).join('')}</select>
      <div id="qfields" style="margin-top:10px"></div><div class="calc-out" id="qpreview"></div>
      <button class="btn" style="margin-top:12px" onclick="addLine()">Add to bill</button>
      ${S.aiEnabled ? `<h2 style="margin-top:22px">Or describe the job to AI</h2>
      <textarea id="aiJob" rows="3" placeholder="e.g. 2BHK: 900 sq ft living and bedrooms in light marble look, 2 bathrooms with wall-hung WC, basin and mixer"></textarea>
      <button class="btn ghost" style="margin-top:8px" onclick="aiSuggest(this)">Suggest items with AI</button>` : ''}
     </div>
     <div class="panel"><h2>Bill type</h2>
      <div class="seg"><button class="${quote.type === 'GST' ? 'on' : ''}" onclick="quote.type='GST';render()">${s.scheme === 'Composition' ? 'Bill of supply' : 'GST tax invoice'}</button><button class="${quote.type === 'EST' ? 'on' : ''}" onclick="quote.type='EST';render()">Non-GST estimate</button></div>
      ${s.scheme === 'Composition' ? '<p class="muted">This showroom is under the composition scheme, so it issues a bill of supply and cannot charge GST.</p>' : ''}
      ${quote.type === 'EST' ? '<p class="note">Non-GST estimates use a separate number series. Use them only where the law allows, and check with your CA.</p>' : ''}
      <h2 style="margin-top:18px">Customer</h2>
      <div class="row"><div><select onchange="quote.cust=+this.value;render()" aria-label="Customer">${S.customers.map(c => `<option value="${c.id}" ${c.id == quote.cust ? 'selected' : ''}>${esc(c.name)} (${esc(c.type)})</option>`).join('')}</select></div>
      <div style="flex:0"><button class="btn small ghost" onclick="addCustomer()">New</button></div></div>
      ${t.taxed ? `<p class="muted">${t.inter ? 'Customer is in another state: IGST applies.' : 'Customer is in the same state: CGST + SGST applies.'}</p>` : ''}
      <label for="disc" style="margin-top:10px">Discount %</label><input id="disc" type="number" min="0" max="50" value="${quote.discount}" onchange="quote.discount=Math.min(100,Math.max(0,+this.value||0));render()">
     </div>
    </div>
    <div class="panel" style="margin-top:16px"><h2>Items</h2>
     ${quote.lines.length ? `<table><tr><th>Item</th><th>Room</th><th class="num">Qty</th><th class="num">In this showroom</th><th class="num">Amount</th><th></th></tr>
     ${quote.lines.map((l, i) => { const p = prod(l.pid), c = lineCalc(l), have = p.stock[s.id] || 0; return `<tr><td><div class="prod-cell">${swatch(p)}<div>${esc(p.name)}<div class="muted">${esc(p.brand)} · ${esc(p.size)}</div></div></div></td>
     <td>${esc(l.room || '–')}${p.cat === 'Tile' ? `<div class="muted">${l.area} sq ft + ${l.wastage}%</div>` : ''}</td>
     <td class="num">${c.qty} ${c.unit}${c.sqft ? `<div class="muted">${c.sqft.toFixed(1)} sq ft</div>` : ''}</td>
     <td class="num">${have < c.qty ? `<span class="pill low">${have}</span>` : have}</td><td class="num">${inr(c.amount)}</td>
     <td class="num"><button class="btn small ghost" onclick="quote.lines.splice(${i},1);render()">Remove</button></td></tr>`; }).join('')}</table>
     <table class="totals" style="max-width:360px;margin:14px 0 0 auto">
      <tr><td>Subtotal</td><td class="num">${inr(t.sub)}</td></tr><tr><td>Discount</td><td class="num">− ${inr(t.disc)}</td></tr>
      ${t.taxed ? (t.inter ? `<tr><td>IGST</td><td class="num">${inr(t.gst)}</td></tr>` : `<tr><td>CGST</td><td class="num">${inr(t.gst / 2)}</td></tr><tr><td>SGST</td><td class="num">${inr(t.gst / 2)}</td></tr>`) : ''}
      <tr><td>Total</td><td class="num">${inr(t.total)}</td></tr></table>
     <div class="row" style="justify-content:flex-end;margin-top:14px">
      <button class="btn ghost" style="flex:0;white-space:nowrap" onclick="sendWhatsApp()">Send on WhatsApp</button>
      <button class="btn" style="flex:0;white-space:nowrap" onclick="createBill(this)">Create ${typeName[type].toLowerCase()}</button></div>`
      : `<p class="muted">No items yet. Add a product above${S.aiEnabled ? ', or describe the job and let AI suggest items' : ''}.</p>`}
    </div>`;
  },
  invoices() {
    const list = S.bills.filter(i => curShop === 'all' || i.shop == curShop);
    return `<h1>Bills</h1><p class="lead">Each showroom has its own GSTIN and its own numbering for every bill type, reset each financial year.</p>
    <div class="panel"><div class="seg" style="margin-bottom:12px">${[['', 'All'], ['GST', 'Tax invoices'], ['BOS', 'Bills of supply'], ['EST', 'Non-GST estimates']].map(([k, n]) => `<button class="${billFilter === k ? 'on' : ''}" onclick="billFilter='${k}';render()">${n}</button>`).join('')}</div>
    ${invoiceTable(list.filter(i => !billFilter || i.type === billFilter).reverse())}</div>`;
  },
  customers() {
    return `<div class="row" style="justify-content:space-between"><div><h1>Customers</h1><p class="lead">Shared across all showrooms.${S.aiEnabled ? ' AI can draft a payment reminder in English, Hindi or Gujarati.' : ''}</p></div>
    <div style="flex:0"><button class="btn" onclick="addCustomer()">Add customer</button></div></div>
    <div class="panel"><table><tr><th>Name</th><th>Type</th><th>Phone</th><th>GSTIN</th><th>Credit</th><th class="num">Outstanding</th><th></th></tr>
    ${S.customers.map(c => `<tr><td>${esc(c.name)}</td><td><span class="pill">${esc(c.type)}</span></td><td>${esc(c.phone)}</td><td class="muted">${esc(c.gstin) || 'Unregistered'}</td><td><button class="btn small ghost" onclick="editCredit(${c.id})">${c.creditDays ? c.creditDays + ' days' : 'Cash'}</button></td>
    <td class="num">${c.outstanding ? inr(c.outstanding) : 'Nil'}</td>
    <td class="num">${c.outstanding > 0 && S.aiEnabled ? `<button class="btn small ghost" onclick="aiReminder(${c.id})">Write reminder</button>` : ''}</td></tr>`).join('')}</table></div>`;
  },
  ai() {
    if (!S.aiEnabled) return `<h1>AI assistant</h1><p class="lead">AI is switched off. Add an ANTHROPIC_API_KEY to the server settings and restart to turn it on.</p>`;
    return `<h1>AI assistant</h1><p class="lead">Ask about stock, sales, dues or products. It reads your live data${isOwner() ? ' across all showrooms' : ' for your showroom'}.</p>
    <div class="panel"><div class="chat" id="chatBox">${chat.length ? chat.map(m => `<div class="msg ${m.role === 'user' ? 'me' : 'ai'}">${esc(m.content)}</div>`).join('') : '<p class="muted">Try one of these, or type your own question.</p>'}</div>
    <div class="chips">${['Which items should I reorder, showroom by showroom?', 'Who owes us the most money?', 'Which showroom can send stock to cover low items elsewhere?', 'Suggest a bathroom combo under ₹30,000'].map(x => `<button onclick="askAI(this.textContent)">${x}</button>`).join('')}</div>
    <div class="row"><div><textarea id="aiQ" rows="2" placeholder="Ask anything about your showrooms" onkeydown="if(event.key==='Enter'&&!event.shiftKey){event.preventDefault();askAI()}"></textarea></div>
    <div style="flex:0"><button class="btn" id="aiBtn" onclick="askAI()">Ask</button></div></div></div>`;
  },
  showrooms() {
    return `<div class="row" style="justify-content:space-between"><div><h1>Showrooms & team</h1><p class="lead">Each showroom is a separate GST registration with its own bill numbering.</p></div>
    ${isOwner() ? '<div style="flex:0;display:flex;gap:8px"><button class="btn ghost" style="white-space:nowrap" onclick="addUser()">Add team member</button><button class="btn" style="white-space:nowrap" onclick="addShowroom()">Add showroom</button></div>' : ''}</div>
    <div class="grid g3">${S.showrooms.map(s => `<div class="panel"><h2>${esc(s.name)}</h2><div>GSTIN ${s.gstin}</div><div class="muted">${esc(s.addr)}<br>${esc(s.state)} · ${s.scheme} scheme<br>Bill prefix ${s.code}</div></div>`).join('')}</div>
    <div id="team" style="margin-top:16px"></div>`;
  }
};

views.dues = () => `<h1>Pending payments</h1><p class="lead">Every bill not yet paid in full, oldest first. Log each call or visit so the daily briefing knows who promised what.</p>
  <div id="duesBox"><p class="muted">Loading…</p></div>`;

// ---------- partials ----------
function productTable(list) {
  return `<table><tr><th>Product</th><th>Category</th><th>Size / finish</th><th class="num">Rate</th><th>HSN / GST</th>${isOwner() ? '<th class="num">Cost</th>' : ''}<th class="num">Stock ${curShop === 'all' ? '(all)' : 'here'}</th></tr>
  ${list.map(p => `<tr><td><div class="prod-cell">${swatch(p)}<div>${esc(p.name)}<div class="muted">${esc(p.brand)}</div></div></div></td><td>${p.cat}</td>
  <td>${esc(p.size)}<div class="muted">${esc(p.finish)}${p.sqftPerBox ? ` · ${p.sqftPerBox} sq ft/box` : ''}</div></td>
  <td class="num">${inr(p.rate)}${p.cat === 'Tile' ? '/sq ft' : '/pc'}</td><td>${esc(p.hsn)}<div class="muted">${p.gstRate}%</div></td>${isOwner() ? `<td class="num"><button class="btn small ghost" onclick="editCost(${p.id})">${p.cost ? inr(p.cost) + '/' + unit(p) : 'Set cost'}</button></td>` : ''}<td class="num">${stk(p)} ${unit(p)}</td></tr>`).join('')}</table>`;
}
function filterProducts() { const t = $('#pq').value.toLowerCase(), c = $('#pc').value; $('#ptable').innerHTML = productTable(S.products.filter(p => (!c || p.cat === c) && (p.name + p.brand + p.size).toLowerCase().includes(t))); }
function invoiceTable(list) {
  if (!list.length) return '<p class="muted">No bills here yet. Create one from New bill.</p>';
  return `<table><tr><th>Bill no.</th><th>Type</th><th>Showroom</th><th>Customer</th><th class="num">Total</th><th>Payment</th><th></th></tr>
  ${list.map(i => { const due = i.total - i.paid; return `<tr><td style="white-space:nowrap">${esc(i.no)}<div class="muted">${new Date(i.date).toLocaleDateString('en-IN')}</div></td>
  <td><span class="pill ${i.type === 'EST' ? 'low' : ''}">${typeName[i.type]}</span></td><td>${esc(shop(i.shop)?.name.split(',')[0])}</td><td>${esc(cust(i.cust)?.name)}</td>
  <td class="num">${inr(i.total)}</td><td>${due <= 0 ? '<span class="pill ok">Paid</span>' : i.paid ? '<span class="pill">Part paid</span>' : '<span class="pill low">Unpaid</span>'}</td>
  <td class="num"><button class="btn small ghost" onclick="openInvoice(${i.id})">Open</button></td></tr>`; }).join('')}</table>`;
}

// ---------- billing ----------
function qpChange() {
  const p = prod($('#qp').value);
  $('#qfields').innerHTML = p.cat === 'Tile'
    ? `<div class="row"><div><label for="qroom">Room</label><input id="qroom" placeholder="e.g. Living room"></div>
       <div><label for="qarea">Area (sq ft)</label><input id="qarea" type="number" value="250" oninput="qPreview()"></div>
       <div><label for="qw">Wastage %</label><input id="qw" type="number" value="8" oninput="qPreview()"></div></div>`
    : `<div class="row"><div><label for="qroom">Room</label><input id="qroom" placeholder="e.g. Master bath"></div>
       <div><label for="qqty">Quantity</label><input id="qqty" type="number" value="1" min="1" oninput="qPreview()"></div></div>`;
  qPreview();
}
function readLine() { const p = prod($('#qp').value); return p.cat === 'Tile' ? { pid: p.id, room: $('#qroom').value, area: +$('#qarea').value || 0, wastage: +$('#qw').value || 0 } : { pid: p.id, room: $('#qroom').value, qty: Math.max(1, +$('#qqty').value || 1) }; }
function qPreview() {
  const l = readLine(), p = prod(l.pid), c = lineCalc(l), s = billShop(), have = p.stock[s.id] || 0;
  const others = S.showrooms.filter(x => x.id !== s.id && (p.stock[x.id] || 0) > 0).map(x => `${esc(x.name.split(',')[0])} ${p.stock[x.id]}`).join(', ');
  $('#qpreview').innerHTML = (p.cat === 'Tile' ? `You need <b>${c.qty} boxes</b> (${c.sqft.toFixed(1)} sq ft) at ${inr(p.rate)}/sq ft = <b>${inr(c.amount)}</b>.` : `${c.qty} × ${inr(p.rate)} = <b>${inr(c.amount)}</b>.`)
    + `<br><span class="muted">${have} ${unit(p)} in this showroom${others ? `; also at ${others}` : ''}.</span>`;
}
function addLine() { const l = readLine(); if (prod(l.pid).cat === 'Tile' && !l.area) return toast('Enter the area in sq ft.'); quote.lines.push(l); render(); toast('Added to bill'); }
function createBill(btn) {
  act(async () => {
    const s = billShop();
    const r = await api('/bills', { showroomId: s.id, customerId: quote.cust, type: quote.type, discount: quote.discount, lines: quote.lines });
    quote = { cust: quote.cust, lines: [], discount: 0, type: 'GST' };
    await reload(); location.hash = '#invoices'; toast(`Bill ${r.no} created`); openInvoice(r.id);
  }, btn, 'Creating…');
}
async function openInvoice(id) {
  try {
    const b = await api('/bills/' + id), s = b.showroom, c = b.customer, due = b.total - b.paid;
    const heading = { GST: 'Tax invoice', BOS: 'Bill of supply', EST: 'Estimate' }[b.type];
    openModal(`<div class="invoice"><div class="row" style="justify-content:space-between;align-items:start">
      <div><h3>${esc(S.business)}</h3><div class="muted">${esc(s.addr)}<br>${[b.type === 'EST' ? '' : 'GSTIN ' + s.gstin, esc(s.phone)].filter(Boolean).join(' · ')}</div></div>
      <div style="text-align:right;flex:0 0 auto"><b>${heading}</b><div>${esc(b.no)}</div><div class="muted">${new Date(b.date).toLocaleDateString('en-IN')}</div></div></div>
      ${b.type === 'BOS' ? '<p class="muted">Composition taxable person, not eligible to collect tax on supplies.</p>' : ''}
      ${b.type === 'EST' ? '<p class="muted">This is an estimate and not a tax invoice.</p>' : ''}
      <p><b>Bill to:</b> ${esc(c.name)}<br><span class="muted">${c.gstin ? 'GSTIN ' + esc(c.gstin) : 'Unregistered'} · ${esc(c.state)}</span></p>
      <table><tr><th>Item</th><th>HSN</th><th class="num">Qty</th><th class="num">Rate</th><th class="num">Amount</th></tr>
      ${b.items.map(i => `<tr><td>${esc(i.name)} – ${esc(i.brand)} ${esc(i.size)}${i.room ? ` <span class="muted">(${esc(i.room)})</span>` : ''}${i.batch ? `<div class="muted">Batch ${esc(i.batch)}, shade ${esc(i.shade)}</div>` : ''}</td>
      <td>${esc(i.hsn)}</td><td class="num">${i.qty} ${i.unit}</td><td class="num">${inr(i.rate)}${i.unit === 'box' ? '/sq ft' : ''}</td><td class="num">${inr(i.amount)}</td></tr>`).join('')}</table>
      <table class="totals" style="max-width:320px;margin:12px 0 0 auto">
      <tr><td>Subtotal</td><td class="num">${inr(b.subtotal)}</td></tr>
      ${b.discount_pct ? `<tr><td>Discount ${b.discount_pct}%</td><td class="num">− ${inr(b.subtotal - b.taxable)}</td></tr>` : ''}
      ${b.cgst ? `<tr><td>CGST</td><td class="num">${inr(b.cgst)}</td></tr><tr><td>SGST</td><td class="num">${inr(b.sgst)}</td></tr>` : ''}
      ${b.igst ? `<tr><td>IGST</td><td class="num">${inr(b.igst)}</td></tr>` : ''}
      <tr><td>Total</td><td class="num">${inr(b.total)}</td></tr></table>
      <p class="muted">Paid ${inr(b.paid)}${due > 0 ? `, due ${inr(due)}` : ''}.</p>
      ${due > 0 ? `<div class="row no-print"><div><label for="payAmt">Payment received</label><input id="payAmt" type="number" value="${due}"></div>
        <div><label for="payMode">Mode</label><select id="payMode"><option>Cash</option><option>UPI</option><option>Card</option><option>Bank transfer</option><option>Cheque</option></select></div>
        <div style="flex:0 0 auto"><button class="btn ghost" style="white-space:nowrap" onclick="recordPayment(${b.id},this)">Record payment</button></div></div>` : ''}
      <div class="row no-print" style="justify-content:flex-end;margin-top:16px">
       <button class="btn ghost" style="flex:0" onclick="closeModal()">Close</button>
       <button class="btn" style="flex:0" onclick="window.print()">Print</button></div></div>`);
  } catch (e) { toast(e.message); }
}
function recordPayment(id, btn) { act(async () => { await api(`/bills/${id}/payments`, { amount: +$('#payAmt').value, mode: $('#payMode').value }); await reload(); toast('Payment recorded'); openInvoice(id); }, btn); }
function sendWhatsApp() {
  const c = cust(quote.cust), s = billShop(), t = totals({ ...quote, type: effectiveType(s, quote.type) }, s);
  const lines = quote.lines.map(l => { const p = prod(l.pid), x = lineCalc(l); return `• ${p.name} (${p.brand}) – ${x.qty} ${x.unit} – ${inr(x.amount)}`; }).join('\n');
  window.open(`https://wa.me/91${c.phone.replace(/\D/g, '').slice(-10)}?text=${encodeURIComponent(`Namaste ${c.name},\nYour quotation from ${S.business}, ${s.name}:\n${lines}\nTotal: ${inr(t.total)}${t.taxed ? ' incl. GST' : ''}\nThank you!`)}`, '_blank');
}

// ---------- AI ----------
async function askAI(text) {
  text = (text || $('#aiQ').value).trim(); if (!text) return;
  chat.push({ role: 'user', content: text }); render(); busy($('#aiBtn'), 'Thinking…');
  try { chat.push({ role: 'assistant', content: (await api('/ai/chat', { messages: chat })).reply }); }
  catch (e) { chat.push({ role: 'assistant', content: e.message }); }
  render(); const b = $('#chatBox'); if (b) b.scrollTop = b.scrollHeight;
}
function aiSuggest(btn) {
  const job = $('#aiJob').value.trim(); if (!job) return toast('Describe the job first.');
  act(async () => {
    const d = await api('/ai/suggest', { job, showroomId: billShop().id });
    const good = (d.lines || []).filter(l => prod(l.pid)).map(l => prod(l.pid).cat === 'Tile'
      ? { pid: l.pid, room: l.room || '', area: Math.max(1, +l.area || 0), wastage: +l.wastage || 8 } : { pid: l.pid, room: l.room || '', qty: Math.max(1, +l.qty || 1) });
    quote.lines.push(...good); render(); toast(d.note || `Added ${good.length} suggested items. Review them before billing.`);
  }, btn, 'Working it out…');
}
function aiReminder(id) {
  const c = cust(id);
  openModal(`<h2>Payment reminder for ${esc(c.name)}</h2><p class="muted">Outstanding ${inr(c.outstanding)}</p>
  <div class="row"><div><label for="lang">Language</label><select id="lang"><option>English</option><option>Hindi</option><option>Gujarati</option></select></div>
  <div style="flex:0"><button class="btn" onclick="genReminder(${id},this)">Write with AI</button></div></div>
  <label for="remText" style="margin-top:12px">Message</label><textarea id="remText" rows="6"></textarea>
  <div class="row" style="justify-content:flex-end;margin-top:12px"><button class="btn ghost" style="flex:0" onclick="closeModal()">Close</button>
  <button class="btn" style="flex:0;white-space:nowrap" onclick="window.open('https://wa.me/91${esc(c.phone).replace(/\D/g, '').slice(-10)}?text='+encodeURIComponent($('#remText').value),'_blank')">Send on WhatsApp</button></div>`);
}
function genReminder(id, btn) { act(async () => { $('#remText').value = (await api('/ai/reminder', { customerId: id, lang: $('#lang').value })).text; }, btn, 'Writing…'); }

// ---------- forms ----------
const shopOptions = (filterOwn, sel) => S.showrooms.filter(s => !filterOwn || isOwner() || s.id === S.me.showroom_id).map(s => `<option value="${s.id}" ${s.id == sel ? 'selected' : ''}>${esc(s.name)}</option>`).join('');
const formButtons = (save, label) => `<div class="row" style="justify-content:flex-end;margin-top:14px"><button class="btn ghost" style="flex:0" onclick="closeModal()">Cancel</button><button class="btn" style="flex:0;white-space:nowrap" onclick="${save}(this)">${label}</button></div>`;

function transfer() {
  const other = S.showrooms.find(s => s.id != (curShop === 'all' ? S.showrooms[0]?.id : curShop));
  openModal(`<h2>Transfer stock</h2><p class="muted">Moves stock between showrooms and records it in the stock history.</p>
  <label for="tp">Product</label><select id="tp">${S.products.map(p => `<option value="${p.id}">${esc(p.name)} (${esc(p.brand)})</option>`).join('')}</select>
  <div class="row" style="margin-top:10px"><div><label for="tf">From</label><select id="tf">${shopOptions(true, curShop)}</select></div>
  <div><label for="tt">To</label><select id="tt">${shopOptions(false, other?.id)}</select></div>
  <div style="flex:0 0 110px"><label for="tq">Quantity</label><input id="tq" type="number" value="10" min="1"></div></div>${formButtons('doTransfer', 'Transfer')}`);
}
function doTransfer(btn) { act(async () => { await api('/stock/transfer', { productId: +$('#tp').value, from: +$('#tf').value, to: +$('#tt').value, qty: +$('#tq').value }); closeModal(); await reload(); toast('Stock transferred'); }, btn); }
function adjustStock(id) {
  const p = prod(id);
  openModal(`<h2>Adjust stock: ${esc(p.name)}</h2>
  <div class="row"><div><label for="adjS">Showroom</label><select id="adjS">${shopOptions(true, curShop)}</select></div>
  <div><label for="adjType">Reason</label><select id="adjType"><option value="1">Stock received</option><option value="-1">Breakage / damage</option></select></div>
  <div style="flex:0 0 100px"><label for="adjQty">Quantity</label><input id="adjQty" type="number" value="1" min="1"></div></div>${formButtons(`saveAdjust.bind(null,${id})`, 'Save')}`);
}
function saveAdjust(id, btn) { act(async () => { await api('/stock/adjust', { productId: id, showroomId: +$('#adjS').value, delta: +$('#adjType').value * (+$('#adjQty').value || 0) }); closeModal(); await reload(); toast('Stock updated'); }, btn); }
function addProduct() {
  openModal(`<h2>Add product</h2>
  <div class="row"><div><label for="np">Name</label><input id="np"></div><div><label for="nb">Brand</label><input id="nb"></div></div>
  <div class="row" style="margin-top:10px"><div><label for="nc">Category</label><select id="nc"><option>Tile</option><option>Sanitaryware</option><option>CP Fitting</option></select></div>
  <div><label for="ns">Size</label><input id="ns" placeholder="600×1200 mm"></div><div><label for="nf">Finish</label><input id="nf" placeholder="Glossy"></div></div>
  <div class="row" style="margin-top:10px"><div><label for="nr">Rate (₹)</label><input id="nr" type="number"></div><div><label for="nx">Sq ft per box (tiles)</label><input id="nx" type="number"></div>
  <div><label for="ng">GST %</label><input id="ng" type="number" value="18"></div><div><label for="ncost">Purchase cost (before GST)</label><input id="ncost" type="number" min="0"></div></div>
  <div class="row" style="margin-top:10px"><div><label for="nbt">Batch</label><input id="nbt"></div><div><label for="nsh">Shade</label><input id="nsh"></div>
  <div><label for="ncol">Swatch colour</label><input id="ncol" type="color" value="#cfcac0" style="height:40px"></div></div>
  <p class="muted">Enter opening stock for each showroom from Inventory.</p>${formButtons('saveProduct', 'Save product')}`);
}
function saveProduct(btn) {
  act(async () => {
    await api('/products', { name: $('#np').value, brand: $('#nb').value, cat: $('#nc').value, size: $('#ns').value, finish: $('#nf').value, rate: +$('#nr').value,
      sqftPerBox: +$('#nx').value, gstRate: +$('#ng').value, cost: +$('#ncost').value || 0, batch: $('#nbt').value, shade: $('#nsh').value, color: $('#ncol').value });
    closeModal(); await reload(); toast('Product saved');
  }, btn);
}
function addCustomer() {
  openModal(`<h2>Add customer</h2>
  <div class="row"><div><label for="cn">Name</label><input id="cn"></div><div><label for="ct">Type</label><select id="ct"><option>Retail</option><option>Contractor</option><option>Builder</option><option>Architect</option><option>Dealer</option></select></div></div>
  <div class="row" style="margin-top:10px"><div><label for="cp">Mobile</label><input id="cp" inputmode="tel"></div><div><label for="cs">State</label><input id="cs" value="${esc(billShop()?.state || '')}"></div></div>
  <div class="row" style="margin-top:10px"><div><label for="cg">GSTIN (if registered)</label><input id="cg" maxlength="15"></div>
  <div style="flex:0 0 150px"><label for="ccd">Credit days</label><input id="ccd" type="number" min="0" value="0"></div></div>${formButtons('saveCustomer', 'Save customer')}`);
}
function saveCustomer(btn) {
  act(async () => {
    const r = await api('/customers', { name: $('#cn').value, type: $('#ct').value, phone: $('#cp').value, state: $('#cs').value, gstin: $('#cg').value.trim(), creditDays: +$('#ccd').value || 0 });
    quote.cust = r.id; closeModal(); await reload(); toast('Customer saved');
  }, btn);
}
function addShowroom() {
  openModal(`<h2>Add showroom</h2>
  <div class="row"><div><label for="sn">Name</label><input id="sn" placeholder="e.g. Vesu, Surat"></div><div style="flex:0 0 110px"><label for="sc">Bill prefix</label><input id="sc" maxlength="4" placeholder="VS"></div></div>
  <div class="row" style="margin-top:10px"><div><label for="sg">GSTIN</label><input id="sg" maxlength="15"></div><div><label for="ss">State</label><input id="ss"></div>
  <div><label for="ssch">GST scheme</label><select id="ssch"><option>Regular</option><option>Composition</option></select></div></div>
  <div class="row" style="margin-top:10px"><div><label for="sa">Address</label><input id="sa"></div><div style="flex:0 0 160px"><label for="sp">Phone</label><input id="sp"></div></div>${formButtons('saveShowroom', 'Save showroom')}`);
}
function saveShowroom(btn) {
  act(async () => {
    await api('/showrooms', { name: $('#sn').value, code: $('#sc').value, gstin: $('#sg').value, state: $('#ss').value, scheme: $('#ssch').value, addr: $('#sa').value, phone: $('#sp').value });
    closeModal(); await reload(); toast('Showroom added');
  }, btn);
}
function addUser() {
  openModal(`<h2>Add team member</h2>
  <div class="row"><div><label for="un">Name</label><input id="un"></div><div><label for="ue">Email</label><input id="ue" type="email"></div></div>
  <div class="row" style="margin-top:10px"><div><label for="ur">Role</label><select id="ur"><option value="staff">Staff (one showroom)</option><option value="owner">Owner (all showrooms)</option></select></div>
  <div><label for="us">Showroom</label><select id="us">${shopOptions(false)}</select></div></div>
  <label for="up" style="margin-top:10px">Starting password (8+ characters)</label><input id="up" type="password" autocomplete="new-password">${formButtons('saveUser', 'Add member')}`);
}
function saveUser(btn) {
  act(async () => {
    await api('/users', { name: $('#un').value, email: $('#ue').value, role: $('#ur').value, showroomId: +$('#us').value, password: $('#up').value });
    closeModal(); render(); toast('Team member added');
  }, btn);
}
async function loadTeam() {
  if (!isOwner() || !$('#team')) return;
  try {
    const users = await api('/users');
    $('#team').innerHTML = `<div class="panel"><h2>Team</h2><table><tr><th>Name</th><th>Email</th><th>Role</th><th>Showroom</th></tr>
    ${users.map(u => `<tr><td>${esc(u.name)}</td><td>${esc(u.email)}</td><td>${u.role}</td><td>${u.showroom_id ? esc(shop(u.showroom_id)?.name) : 'All'}</td></tr>`).join('')}</table></div>`;
  } catch (e) { toast(e.message); }
}

// ---------- pending payments ----------
let DUES = null;
const fmtDate = d => d ? new Date(d).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' }) : '';
async function loadDues() {
  try { DUES = await api('/dues?showroom=' + curShop); } catch (e) { return toast(e.message); }
  const d = DUES, box = $('#duesBox'); if (!box) return;
  if (!d.bills.length) { box.innerHTML = '<div class="panel">Nothing pending. Every bill is fully paid.</div>'; return; }
  const B = d.buckets;
  box.innerHTML = `<div class="grid g4" style="grid-template-columns:repeat(5,1fr)">
    ${[['Not yet due', B.notDue], ['1–30 days late', B.d0_30], ['31–60 days late', B.d31_60], ['61–90 days late', B.d61_90], ['90+ days late', B.d90]]
      .map(([n, v], i) => `<div class="panel stat bucket"><b style="${i >= 3 && v ? 'color:var(--alert)' : ''}">${inr(v)}</b><span>${n}</span></div>`).join('')}</div>
  <div class="panel" style="margin-top:16px"><h2>${inr(d.total)} pending, ${inr(d.overdue)} overdue</h2>
  <table><tr><th>Customer</th><th class="num">Overdue</th><th class="num">Total due</th><th>Oldest</th><th>Last follow-up</th><th></th></tr>
  ${d.customers.map(c => { const f = c.lastFollowup; return `<tr><td>${esc(c.name)}<div class="muted">${c.bills} bill${c.bills > 1 ? 's' : ''} · ${c.creditDays ? c.creditDays + '-day credit' : 'cash terms'}</div></td>
    <td class="num">${c.overdue ? `<b>${inr(c.overdue)}</b>` : '–'}</td><td class="num">${inr(c.due)}</td>
    <td>${c.oldestDays > 0 ? `${c.oldestDays} day${c.oldestDays === 1 ? '' : 's'} late` : c.oldestDays === 0 ? 'due today' : `due in ${-c.oldestDays} day${c.oldestDays === -1 ? '' : 's'}`}</td>
    <td>${f ? `${esc(f.note)}<div class="muted">${fmtDate(f.at)}${f.promisedDate ? ` · promised ${f.promisedAmount ? inr(f.promisedAmount) + ' ' : ''}by ${fmtDate(f.promisedDate)}` : ''}</div>` : '<span class="muted">None yet</span>'}
      ${c.promiseBroken ? '<span class="flag bad">Promise missed</span>' : c.promiseUpcoming ? '<span class="flag soon">Promise pending</span>' : ''}</td>
    <td class="num" style="white-space:nowrap"><button class="btn small ghost" onclick="logFollowup(${c.id})">Log follow-up</button>
      ${S.aiEnabled ? `<button class="btn small ghost" onclick="aiReminder(${c.id})">Remind</button>` : ''}</td></tr>`; }).join('')}</table></div>
  <div class="panel" style="margin-top:16px"><h2>Unpaid bills</h2><table><tr><th>Bill</th><th>Customer</th><th>Showroom</th><th>Due date</th><th class="num">Balance</th><th></th></tr>
  ${d.bills.map(b => `<tr><td style="white-space:nowrap">${esc(b.no)}</td><td>${esc(cust(b.cust)?.name)}</td><td>${esc(b.showroom.split(',')[0])}</td>
    <td>${fmtDate(b.dueDate)}${b.daysOverdue > 0 ? ` <span class="flag ${b.daysOverdue > 60 ? 'bad' : 'soon'}">${b.daysOverdue}d late</span>` : ''}</td>
    <td class="num">${inr(b.due)}</td><td class="num"><button class="btn small ghost" onclick="openInvoice(${b.id})">Open</button></td></tr>`).join('')}</table></div>`;
}
function logFollowup(id) {
  const c = cust(id);
  openModal(`<h2>Follow-up: ${esc(c.name)}</h2><p class="muted">Outstanding ${inr(c.outstanding)}</p>
  <label for="fn">What happened?</label><textarea id="fn" rows="3" placeholder="e.g. Called Mr Patel, said site payment is stuck, will pay half next week"></textarea>
  <div class="row" style="margin-top:10px"><div><label for="fd">Promised to pay by (optional)</label><input id="fd" type="date"></div>
  <div><label for="fa">Promised amount (optional)</label><input id="fa" type="number" min="0"></div></div>${formButtons('saveFollowup.bind(null,' + id + ')', 'Save follow-up')}`);
}
function saveFollowup(id, btn) {
  act(async () => { await api('/followups', { customerId: id, note: $('#fn').value, promisedDate: $('#fd').value, promisedAmount: +$('#fa').value });
    closeModal(); toast('Follow-up saved'); loadDues(); }, btn);
}
function editCredit(id) {
  const c = cust(id);
  openModal(`<h2>Credit terms: ${esc(c.name)}</h2><p class="muted">Days allowed to pay after a bill. 0 means payment on delivery. Applies to new bills.</p>
  <label for="cdays">Credit days</label><input id="cdays" type="number" min="0" max="365" value="${c.creditDays || 0}">${formButtons('saveCredit.bind(null,' + id + ')', 'Save')}`);
}
function saveCredit(id, btn) {
  act(async () => { const r = await fetch('/api/customers/' + id + '/credit', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ creditDays: +$('#cdays').value }) });
    if (!r.ok) throw new Error((await r.json()).error); closeModal(); await reload(); toast('Credit terms saved'); }, btn);
}
async function loadDigest(force) {
  const box = $('#digestBox'); if (!box) return;
  try {
    const d = force ? await api('/digest/run', {}) : await api('/digest');
    box.innerHTML = `<div class="row" style="justify-content:space-between;align-items:start"><h2>Today's payment briefing</h2>
      <div style="flex:0;display:flex;gap:8px"><a class="btn small ghost" href="#dues" style="white-space:nowrap">See all dues</a>
      <button class="btn small ghost" style="white-space:nowrap" onclick="this.disabled=true;this.textContent='Preparing…';loadDigest(true)">${d ? 'Refresh' : 'Prepare now'}</button></div></div>
      ${d ? `<div class="brief">${esc(d.text)}</div><p class="muted">Prepared ${new Date(d.created_at).toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' })}</p>`
          : '<p class="muted">Your first briefing will be prepared at the set time each morning, or tap Prepare now.</p>'}`;
  } catch (e) { box.innerHTML = `<h2>Today's payment briefing</h2><p class="muted">${esc(e.message)}</p>`; }
}

// ---------- router ----------
function render() {
  const v = (location.hash || '#dashboard').slice(1);
  $('#view').innerHTML = (views[v] || views.dashboard)();
  document.querySelectorAll('nav a').forEach(a => a.classList.toggle('active', a.getAttribute('href') === '#' + v));
  if (v === 'quotation' && $('#qp')) qpChange();
  if (v === 'showrooms') loadTeam();
  if (v === 'dues') loadDues();
  if (window.onView) window.onView(v);
  if ((v === 'dashboard' || !views[v]) && isOwner()) loadDigest();
}
window.addEventListener('hashchange', () => S.me && render());
load().catch(() => showLogin());
