// Analytics page: lightweight SVG/CSS charts that follow light and dark mode (loaded after accounts.js).
let an = { from: '', to: '', showroom: 'all', preset: '12m' };
const shortInr = n => { const a = Math.abs(n), s = n < 0 ? '−' : ''; return a >= 1e7 ? `${s}₹${(a / 1e7).toFixed(1)}Cr` : a >= 1e5 ? `${s}₹${(a / 1e5).toFixed(1)}L` : a >= 1e3 ? `${s}₹${(a / 1e3).toFixed(0)}K` : `${s}₹${Math.round(a)}`; };
const C = { a: 'var(--glaze)', b: 'var(--ochre)', c: 'var(--alert)', d: 'var(--ok)' };

// Horizontal bars (HTML): items [{label, value, sub?}]
function hbars(items, { color = C.a, fmt = inr, empty = 'No data in this period.' } = {}) {
  if (!items.length) return `<p class="muted">${empty}</p>`;
  const max = Math.max(...items.map(i => Math.abs(i.value)), 1);
  return `<div class="hb">${items.map(i => `<div class="hb-row" title="${esc(i.label)}: ${fmt(i.value)}">
    <div class="hb-top"><span class="hb-l">${esc(i.label)}</span><span class="hb-v">${fmt(i.value)}</span></div>
    <div class="hb-track"><div class="hb-bar" style="width:${Math.max(1.5, Math.abs(i.value) / max * 100)}%;background:${i.color || color}"></div></div>
    ${i.sub ? `<div class="muted" style="font-size:12px">${i.sub}</div>` : ''}</div>`).join('')}</div>`;
}

// Line chart (SVG): series [{name, color, values[]}], labels[]
function lineChart(series, labels, { h = 260 } = {}) {
  const W = 820, H = h, L = 62, R = 34, T = 14, B = 34, n = labels.length;
  const all = series.flatMap(s => s.values), max = Math.max(...all, 1), min = Math.min(0, ...all);
  const x = i => L + (n === 1 ? (W - L - R) / 2 : i * (W - L - R) / (n - 1)), y = v => T + (max - v) / (max - min || 1) * (H - T - B);
  const ticks = 4, step = labels.length > 14 ? Math.ceil(labels.length / 12) : 1;
  let g = '';
  for (let t = 0; t <= ticks; t++) { const v = min + (max - min) * t / ticks;
    g += `<line x1="${L}" x2="${W - R}" y1="${y(v)}" y2="${y(v)}" style="stroke:var(--grout)" stroke-width="1"/><text x="${L - 8}" y="${y(v) + 4}" text-anchor="end" class="ax">${shortInr(v)}</text>`; }
  labels.forEach((l, i) => { if (i % step === 0 || i === n - 1) g += `<text x="${x(i)}" y="${H - 10}" text-anchor="middle" class="ax">${l}</text>`; });
  const lines = series.map(s => `<polyline fill="none" style="stroke:${s.color}" stroke-width="2.5" stroke-linejoin="round" points="${s.values.map((v, i) => `${x(i)},${y(v)}`).join(' ')}"/>
    ${s.values.map((v, i) => `<circle cx="${x(i)}" cy="${y(v)}" r="${n > 40 ? 2 : 3.5}" style="fill:${s.color}"><title>${s.name}, ${labels[i]}: ${inr(v)}</title></circle>`).join('')}`).join('');
  return `<svg viewBox="0 0 ${W} ${H}" width="100%" role="img" aria-label="${series.map(s => s.name).join(', ')} over time">${g}${lines}</svg>
    <div class="legend">${series.map(s => `<span><i style="background:${s.color}"></i>${s.name}</span>`).join('')}</div>`;
}

// Vertical bars (SVG): items [{label, value, color}]
function vbars(items, { h = 200 } = {}) {
  const W = 330, H = h, T = 22, B = 40, n = items.length, max = Math.max(...items.map(i => i.value), 1), bw = (W - 20) / n;
  return `<svg viewBox="0 0 ${W} ${H}" width="100%" role="img" aria-label="Bar chart">${items.map((it, i) => {
    const bh = it.value / max * (H - T - B), x0 = 10 + i * bw + bw * 0.18, w = bw * 0.64;
    return `<rect x="${x0}" y="${H - B - bh}" width="${w}" height="${Math.max(bh, 1)}" rx="3" style="fill:${it.color || C.a}"><title>${it.label}: ${inr(it.value)}</title></rect>
      <text x="${x0 + w / 2}" y="${H - B - bh - 6}" text-anchor="middle" class="ax">${shortInr(it.value)}</text>
      <text x="${x0 + w / 2}" y="${H - 16}" text-anchor="middle" class="ax">${it.label}</text>`; }).join('')}</svg>`;
}

function anRange(preset) {
  const t = new Date(Date.now() + 330 * 60e3), iso = d => d.toISOString().slice(0, 10), d = new Date(t);
  if (preset === '30d') d.setDate(d.getDate() - 29);
  else if (preset === 'month') d.setDate(1);
  else if (preset === 'fy') { d.setMonth(3, 1); if (t.getMonth() < 3) d.setFullYear(d.getFullYear() - 1); }
  else { d.setMonth(d.getMonth() - 11, 1); }
  return [iso(d), iso(t)];
}

views.analytics = () => { if (!an.from) [an.from, an.to] = anRange(an.preset || '12m'); return anView(); };
const anView = () => !isOwner() ? '<h1>Analytics</h1><p class="lead">Only the owner can see analytics.</p>' : `
  <h1>Analytics</h1><p class="lead">How the business is doing: sales, profit, customers, collections and stock.</p>
  <div class="row no-print" style="margin-bottom:16px">
    <div style="flex:0 0 auto"><label>Period</label><div class="seg">${[['30d', 'Last 30 days'], ['month', 'This month'], ['fy', 'This FY'], ['12m', '12 months']]
      .map(([k, n]) => `<button class="${an.preset === k ? 'on' : ''}" onclick="an.preset='${k}';[an.from,an.to]=anRange('${k}');render()">${n}</button>`).join('')}</div></div>
    <div style="flex:0 0 150px"><label for="anf">From</label><input id="anf" type="date" value="${an.from}" onchange="an.from=this.value;an.preset='';loadAnalytics()"></div>
    <div style="flex:0 0 150px"><label for="ant">To</label><input id="ant" type="date" value="${an.to}" onchange="an.to=this.value;an.preset='';loadAnalytics()"></div>
    <div style="flex:0 0 210px"><label for="ans">Showroom</label><select id="ans" onchange="an.showroom=this.value;loadAnalytics()"><option value="all">All showrooms</option>${shopOptions(false, an.showroom)}</select></div>
    <div style="flex:0;align-self:end"><button class="btn ghost" onclick="window.print()">Print</button></div></div>
  <div id="anBox"><p class="muted">Loading…</p></div>`;

async function loadAnalytics() {
  const box = $('#anBox'); if (!box) return;
  if (!an.from) [an.from, an.to] = anRange(an.preset || '12m');
  try {
    const d = await api(`/analytics?from=${an.from}&to=${an.to}&showroom=${an.showroom}`), k = d.kpis;
    const growth = g => g == null ? '' : `<span class="${g >= 0 ? 'up' : 'down'}">${g >= 0 ? '▲' : '▼'} ${Math.abs(g).toFixed(1)}%</span> vs previous period`;
    const lbl = p => d.grain === 'day' ? new Date(p).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' }) : new Date(p).toLocaleDateString('en-IN', { month: 'short', year: '2-digit' });
    const labels = d.trend.map(t => lbl(t.period));
    const tot = d.byCategory.reduce((s, x) => s + x.sales, 0);
    box.innerHTML = `
    ${k.unpriced ? '<div class="panel note" style="margin-bottom:16px">Some products sold have no purchase cost set, so profit figures are too high. Set costs under Products.</div>' : ''}
    <div class="grid g4">
      <div class="panel stat"><b>${inr(k.sales)}</b><span>Sales, before GST</span><div class="kpi-sub">${growth(k.salesGrowth)}</div></div>
      <div class="panel stat"><b>${inr(k.gross)}</b><span>Gross profit</span><div class="kpi-sub">${k.margin}% margin</div></div>
      <div class="panel stat"><b style="color:${k.net >= 0 ? 'var(--ok)' : 'var(--alert)'}">${inr(k.net)}</b><span>Net profit (after expenses)</span><div class="kpi-sub">Expenses ${inr(k.expenses)}</div></div>
      <div class="panel stat"><b>${inr(k.outstanding)}</b><span>Customers owe you</span><div class="kpi-sub">${inr(k.overdue)} overdue</div></div>
    </div>
    <div class="grid g4" style="margin-top:16px">
      <div class="panel stat"><b>${k.bills}</b><span>Bills</span><div class="kpi-sub">${growth(k.billsGrowth)}</div></div>
      <div class="panel stat"><b>${inr(k.avgBill)}</b><span>Average bill value</span></div>
      <div class="panel stat"><b>${inr(k.purchases)}</b><span>Purchases, before GST</span></div>
      <div class="panel stat"><b>${inr(Math.max(0, d.gst.output - d.gst.input))}</b><span>GST payable (output − input)</span><div class="kpi-sub">Output ${shortInr(d.gst.output)} · Input ${shortInr(d.gst.input)}</div></div>
    </div>
    <div class="panel" style="margin-top:16px"><h2>Sales, gross profit and expenses ${d.grain === 'day' ? 'by day' : 'by month'}</h2>
      ${lineChart([{ name: 'Sales', color: C.a, values: d.trend.map(t => t.sales) }, { name: 'Gross profit', color: C.d, values: d.trend.map(t => t.gross) }, { name: 'Expenses', color: C.b, values: d.trend.map(t => t.expenses) }], labels)}</div>
    <div class="grid g3" style="margin-top:16px">
      <div class="panel"><h2>Sales by showroom</h2>${hbars(d.byShowroom.map(s => ({ label: s.name, value: s.sales, sub: `${s.bills} bills` })))}</div>
      <div class="panel"><h2>Sales by category</h2>${hbars(d.byCategory.map((c, i) => ({ label: c.name, value: c.sales, color: [C.a, C.b, C.d][i % 3], sub: `${tot ? (c.sales / tot * 100).toFixed(0) : 0}% of sales · profit ${shortInr(c.profit)}` })))}</div>
      <div class="panel"><h2>Top brands</h2>${hbars(d.byBrand.map(b => ({ label: b.name, value: b.sales })), { color: C.b })}</div>
    </div>
    <div class="grid g2" style="margin-top:16px">
      <div class="panel"><h2>Top products</h2>${d.topProducts.length ? `<table><tr><th>Product</th><th class="num">Qty</th><th class="num">Sales</th><th class="num">Profit</th></tr>
        ${d.topProducts.map(p => `<tr><td>${esc(p.name)}</td><td class="num">${p.qty}</td><td class="num">${inr(p.sales)}</td><td class="num">${p.no_cost ? '<span class="muted">cost not set</span>' : inr(p.profit)}</td></tr>`).join('')}</table>` : '<p class="muted">No sales in this period.</p>'}</div>
      <div class="panel"><h2>Top customers</h2>${hbars(d.topCustomers.map(c => ({ label: c.name, value: c.sales, sub: `${esc(c.type)} · ${c.bills} bills${c.due > 0 ? ` · <span style="color:var(--alert)">${inr(c.due)} due</span>` : ''}` })))}</div>
    </div>
    <div class="grid g3" style="margin-top:16px">
      <div class="panel"><h2>Who buys: customer type</h2>${hbars(d.byCustomerType.map(t => ({ label: t.name, value: t.sales, sub: `${t.customers} customer${t.customers > 1 ? 's' : ''}` })), { color: C.d })}</div>
      <div class="panel"><h2>How customers pay</h2>${hbars(d.paymentModes.map(m => ({ label: m.name, value: m.amount, sub: `${m.n} payment${m.n > 1 ? 's' : ''}` })), { empty: 'No payments in this period.' })}</div>
      <div class="panel"><h2>Money owed, by how late</h2>${vbars([['Not due', d.ageing.notDue, C.d], ['1–30d', d.ageing.d0_30, C.a], ['31–60d', d.ageing.d31_60, C.b], ['61–90d', d.ageing.d61_90, C.c], ['90d+', d.ageing.d90, C.c]].map(([label, value, color]) => ({ label, value, color })))}
        <a class="btn small ghost" href="#dues">See pending payments</a></div>
    </div>
    <div class="grid g2" style="margin-top:16px">
      <div class="panel"><h2>Stock value by showroom (at cost)</h2>${hbars(d.stockByShowroom.map(s => ({ label: s.name, value: s.value, sub: `${s.units} boxes/pieces` })), { color: C.b })}</div>
      <div class="panel"><h2>Slow-moving stock</h2><p class="muted">In stock but not sold in this period, highest value first.</p>
        ${d.slowMovers.length ? `<table><tr><th>Product</th><th class="num">In stock</th><th class="num">Value</th><th>Last sold</th></tr>
        ${d.slowMovers.map(s => `<tr><td>${esc(s.name)}</td><td class="num">${s.qty}</td><td class="num">${s.value ? inr(s.value) : '–'}</td><td>${s.last_sold ? new Date(s.last_sold).toLocaleDateString('en-IN') : 'Never'}</td></tr>`).join('')}</table>`
        : '<p>Everything in stock sold at least once in this period. 👍</p>'}</div>
    </div>`;
  } catch (e) { box.innerHTML = `<p class="muted">${esc(e.message)}</p>`; }
}

const _prevOnView = window.onView;
window.onView = v => { if (_prevOnView) _prevOnView(v); if (v === 'analytics') loadAnalytics(); };
