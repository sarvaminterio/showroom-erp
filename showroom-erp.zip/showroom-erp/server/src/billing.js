// Billing rules live on the server so totals can't be altered in the browser.
export const round2 = n => Math.round(n * 100) / 100;

// Indian financial year label, e.g. 26-27 for Apr 2026–Mar 2027
export function fy(d = new Date()) {
  const y = d.getFullYear() % 100, start = d.getMonth() >= 3 ? y : (y + 99) % 100;
  return `${String(start).padStart(2, '0')}-${String((start + 1) % 100).padStart(2, '0')}`;
}

// Composition-scheme showrooms cannot issue tax invoices: they issue a bill of supply.
export const effectiveType = (scheme, type) => (scheme === 'Composition' && type === 'GST' ? 'BOS' : type);

// Tiles are sold in whole boxes: area + wastage, rounded up to boxes.
export function lineCalc(p, l) {
  if (p.cat === 'Tile') {
    const area = Math.max(0, +l.area || 0), wastage = Math.min(50, Math.max(0, +l.wastage || 0));
    if (!area) throw new Error(`Enter the area for ${p.name}.`);
    const qty = Math.ceil((area * (1 + wastage / 100)) / p.sqft_per_box);
    return { qty, unit: 'box', area, wastage, amount: round2(qty * p.sqft_per_box * p.rate) };
  }
  const qty = Math.max(1, Math.floor(+l.qty || 1));
  return { qty, unit: 'pc', area: null, wastage: null, amount: round2(qty * p.rate) };
}

// lines: [{amount, gst_rate}]; returns money totals for the bill.
export function billTotals(lines, discountPct, type, interstate) {
  const d = Math.min(100, Math.max(0, +discountPct || 0)) / 100;
  const subtotal = round2(lines.reduce((a, l) => a + l.amount, 0));
  const taxable = round2(subtotal * (1 - d));
  const tax = type === 'GST' ? round2(lines.reduce((a, l) => a + l.amount * (1 - d) * l.gst_rate / 100, 0)) : 0;
  const igst = interstate ? tax : 0;
  const cgst = interstate ? 0 : round2(tax / 2);
  const sgst = interstate ? 0 : round2(tax - cgst);
  return { subtotal, taxable, cgst, sgst, igst, total: Math.round(taxable + tax) }; // rounded to the rupee
}

export function billNumber(code, type, fyLabel, n) {
  const num = String(n).padStart(4, '0');
  return type === 'GST' ? `${code}/${fyLabel}/${num}` : `${code}/${type}/${fyLabel}/${num}`;
}

export const GSTIN_RE = /^\d{2}[A-Z]{5}\d{4}[A-Z][1-9A-Z]Z[0-9A-Z]$/;
