// Creates the owner account and, optionally, sample data. Safe to run once on an empty database.
import bcrypt from 'bcryptjs';
import { pool, tx } from './db.js';

const email = process.env.OWNER_EMAIL, password = process.env.OWNER_PASSWORD;
if (!email || !password || password.length < 8) { console.error('Set OWNER_EMAIL and OWNER_PASSWORD (8+ characters).'); process.exit(1); }

await tx(async c => {
  const { rows } = await c.query('SELECT 1 FROM users LIMIT 1');
  if (rows.length) { console.log('Users already exist; nothing to seed.'); return; }
  await c.query(`INSERT INTO users(name,email,password_hash,role) VALUES('Owner',$1,$2,'owner')`, [email.toLowerCase(), await bcrypt.hash(password, 10)]);
  console.log(`Owner account created: ${email}`);
  if (process.env.SEED_SAMPLE_DATA !== 'true') return;

  const shops = [
    ['RR', 'Ring Road, Ahmedabad', '24ABCDE1234F1Z5', 'Gujarat', 'Ring Road, Ahmedabad 380015', 'Regular'],
    ['ST', 'Adajan, Surat', '24FGHIJ5678K1Z3', 'Gujarat', 'Adajan, Surat 395009', 'Regular'],
    ['UD', 'Hiran Magri, Udaipur', '08KLMNO9012P1Z7', 'Rajasthan', 'Hiran Magri, Udaipur 313002', 'Composition']];
  for (const s of shops) await c.query('INSERT INTO showrooms(code,name,gstin,state,addr,scheme) VALUES($1,$2,$3,$4,$5,$6)', s);

  const prods = [
    ['Statuario Glossy', 'Kajaria', 'Tile', '800×1600 mm', 'Glossy', 27.56, 92, '6907', 'B-2411', 'S12', '#EDEBE6', [140, 60, 20]],
    ['Rustic Wood Plank', 'Somany', 'Tile', '200×1200 mm', 'Matt', 15.5, 68, '6907', 'B-2398', 'W04', '#A97C55', [22, 85, 40]],
    ['Carrara Satin', 'Johnson', 'Tile', '600×600 mm', 'Satin', 15.5, 54, '6907', 'B-2420', 'C02', '#D8D9D6', [310, 120, 75]],
    ['Charcoal Anti-skid', 'Kajaria', 'Tile', '300×300 mm', 'Anti-skid', 10.76, 42, '6907', 'B-2302', 'G09', '#4A4F52', [8, 45, 12]],
    ['Wall-hung WC Neo', 'Hindware', 'Sanitaryware', '520 mm', 'White', null, 11800, '6910', null, null, '#FFFFFF', [12, 4, 6]],
    ['Table-top Basin Oval', 'Cera', 'Sanitaryware', '560 mm', 'White', null, 4200, '6910', null, null, '#F4F4F2', [3, 9, 2]],
    ['Single-lever Basin Mixer', 'Jaquar', 'CP Fitting', 'Standard', 'Chrome', null, 6450, '8481', null, null, '#B9C0C4', [18, 10, 7]],
    ['Overhead Rain Shower 250', 'Jaquar', 'CP Fitting', '250 mm', 'Chrome', null, 8900, '8481', null, null, '#C7CDD1', [5, 3, 4]]];
  for (const p of prods) {
    const { rows: [x] } = await c.query(`INSERT INTO products(name,brand,cat,size,finish,sqft_per_box,rate,hsn,batch,shade,color)
      VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) RETURNING id`, p.slice(0, 11));
    for (let i = 0; i < 3; i++) await c.query('INSERT INTO stock VALUES($1,$2,$3)', [x.id, i + 1, p[11][i]]);
  }
  for (const cu of [['Rahul Mehta', 'Retail', '9825011111', '', 'Gujarat'], ['Patel Constructions', 'Contractor', '9825022222', '24AAACP1234Q1Z2', 'Gujarat'],
    ['Ar. Nisha Shah', 'Architect', '9825033333', '', 'Gujarat'], ['Udaipur Homes', 'Builder', '9414044444', '08AAFCU5678K1Z9', 'Rajasthan']])
    await c.query('INSERT INTO customers(name,type,phone,gstin,state) VALUES($1,$2,$3,$4,$5)', cu);
  console.log('Sample showrooms, products and customers added.');
});
await pool.end();
