import jwt from 'jsonwebtoken';
const SECRET = process.env.JWT_SECRET;
if (!SECRET || SECRET.length < 32) throw new Error('Set JWT_SECRET to a random string of at least 32 characters.');

export const sign = u => jwt.sign({ id: u.id, name: u.name, role: u.role, showroom_id: u.showroom_id }, SECRET, { expiresIn: '12h' });

export function requireAuth(req, res, next) {
  try { req.user = jwt.verify(req.cookies?.token || '', SECRET); next(); }
  catch { res.status(401).json({ error: 'Please sign in.' }); }
}
export const requireOwner = (req, res, next) =>
  req.user.role === 'owner' ? next() : res.status(403).json({ error: 'Only the owner can do this.' });

// Owners can work in every showroom; staff only in their own.
export const canUse = (user, showroomId) => user.role === 'owner' || user.showroom_id === +showroomId;
