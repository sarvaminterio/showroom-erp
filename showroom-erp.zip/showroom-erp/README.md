# Showroom ERP

Open-source billing, GST and inventory software for tile, sanitaryware and CP fittings showrooms in India. One owner, many showrooms, each with its own GSTIN.

Licensed under MIT: you can use, change, host and sell it freely.

## What it does

**Showrooms.** Each showroom has its own GSTIN, state and GST scheme (regular or composition). Each one keeps its own bill number series, reset every financial year:

| Bill type | Example number |
|---|---|
| Tax invoice | `RR/26-27/0001` |
| Bill of supply | `UD/BOS/26-27/0001` |
| Non-GST estimate | `RR/EST/26-27/0001` |

**Billing.** The server calculates every bill, so totals can't be edited in the browser:
- Tiles are entered as room area plus wastage and rounded up to whole boxes.
- CGST + SGST or IGST is chosen automatically by comparing the showroom's state with the customer's.
- Composition showrooms automatically issue a bill of supply.
- You can record full or part payments by cash, UPI, card, bank transfer or cheque.

**Inventory.** Stock is kept per showroom, by batch and shade. You can transfer stock between showrooms, and record goods received and breakage. Every stock change is logged in `stock_moves`, showing who made it and when. Two counters can't sell the same last box at once, because stock rows are locked while a bill is saved.

**Team.** There are two roles. Owners see everything. Staff can only bill and move stock for their own showroom.

**AI assistant** (optional, uses the Claude API). It can:
- answer questions about your live data, like "Who owes us the most?"
- suggest bill items from a job description
- write payment reminders in English, Hindi or Gujarati

The API key stays on your server and is never sent to the browser.

**WhatsApp.** Quotes and reminders open in WhatsApp through click-to-chat links. No API is needed for this.

## Quick start (any computer or cloud server with Docker)

```bash
cp .env.example .env          # then edit .env
openssl rand -hex 32          # paste the result into JWT_SECRET
docker compose up -d --build
docker compose exec app node server/src/seed.js   # creates the owner login (+ sample data if enabled)
```

Then open http://localhost:3000 and sign in with `OWNER_EMAIL` / `OWNER_PASSWORD`. Change that password before real use.

## Putting it on the cloud

Any provider that runs Docker works, for example AWS Lightsail, DigitalOcean, Hetzner, or an Indian provider like E2E Networks if you want data held in India. A 2 GB RAM server is enough to start.

1. **Get a server.** Create an Ubuntu server, install Docker, copy this folder to it, and run the Quick start steps.
2. **Point your domain.** Point a domain such as `erp.yourshop.in` to the server's IP address.
3. **Turn on HTTPS.** Put [Caddy](https://caddyserver.com) in front of the app. It gets free certificates automatically. A `Caddyfile` with these two lines is enough:
   ```
   erp.yourshop.in {
     reverse_proxy localhost:3000
   }
   ```
   Then set `COOKIE_SECURE=true` in `.env` and restart the app.
4. **Back up daily.** Schedule this with cron, and copy the files somewhere off the server, like S3 or Google Drive:
   ```bash
   docker compose exec -T db pg_dump -U showroom showroom | gzip > backup-$(date +%F).sql.gz
   ```

**Using a managed database instead.** You can use a managed PostgreSQL such as AWS RDS, Supabase or Neon. Set `DATABASE_URL` to its connection string, set `DATABASE_SSL=true`, and remove the `db` service from `docker-compose.yml`.

## Running without Docker

You need Node.js 20+ and PostgreSQL 14+.

```bash
cd server && npm install
export DATABASE_URL=postgres://user:pass@localhost:5432/showroom JWT_SECRET=... OWNER_EMAIL=... OWNER_PASSWORD=...
npm run migrate && npm run seed && npm start
```

## Project layout

```
server/db/schema.sql     database tables
server/src/billing.js    GST, box and numbering rules (pure functions, easy to test)
server/src/routes.js     REST API: auth, showrooms, products, stock, bills, payments
server/src/ai.js         Claude API proxy (chat, item suggestions, reminders)
public/                  the web app (plain HTML/CSS/JS, no build step)
```

## Adding more integrations

Integrations go in their own file in `server/src`, mounted in `index.js`, the same way `ai.js` is. Good next ones:

| Integration | Providers | What it adds |
|---|---|---|
| GST e-invoice / e-way bill | a GSP such as ClearTax, Masters India or IRIS | Store the IRN and QR code on `bills` |
| Payment links | Razorpay or Cashfree | A webhook records the payment automatically |
| WhatsApp Business API | Meta Cloud API, Interakt or AiSensy | Send PDFs and automatic reminders |
| Tally export | Tally XML vouchers per GSTIN | Hand your books to your CA |

## Important notes

- **Check the tax setup with your CA before going live.** This includes GST rates per HSN, invoice format rules, and when e-invoicing becomes mandatory at your turnover. This software is not tax or legal advice.
- **Non-GST estimates are not tax invoices.** A GST-registered business generally must issue a tax invoice for a taxable sale. Use estimates only where your CA confirms that's appropriate.
- **Bills are never deleted.** To fix a mistake, issue a credit note (on the roadmap) rather than editing a saved bill.

## Roadmap

- [ ] Credit and debit notes, sales returns
- [ ] Purchase orders and goods received against supplier bills
- [ ] PDF invoice download with amount in words and UPI QR
- [ ] GSTR-1 export per GSTIN
- [ ] e-invoice / e-way bill integration
- [ ] Reports: sales by brand, slow-moving stock, profit per item

Contributions welcome. Open an issue or a pull request.
