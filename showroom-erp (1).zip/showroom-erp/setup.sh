#!/usr/bin/env bash
# One-command installer for Showroom ERP on a fresh Ubuntu server.
# Run:  bash setup.sh
set -euo pipefail
cd "$(dirname "$0")"
APP_DIR="$(pwd)"

say()  { printf '\n\033[1;36m==> %s\033[0m\n' "$1"; }
ok()   { printf '\033[1;32m✔ %s\033[0m\n' "$1"; }
clean(){ printf '%s' "$1" | tr -d "'\"\\\\\$\`"; }   # strip characters that would break the settings file

echo
echo "  Showroom ERP setup"
echo "  Answer a few questions. Press Enter to skip anything marked (optional)."
echo

read -rp "1. Your business name (e.g. Shree Tiles & Sanitaryware): " BIZ
BIZ=$(clean "$BIZ"); BIZ=${BIZ:-My Showroom}

while true; do
  read -rp "2. Your login email: " EMAIL; EMAIL=$(clean "$EMAIL")
  [[ "$EMAIL" == *@*.* ]] && break; echo "   That doesn't look like an email address. Try again."
done

while true; do
  read -rsp "3. Choose a login password (at least 8 characters, typing is hidden): " PASS; echo
  read -rsp "   Type the same password again: " PASS2; echo
  if [ "$PASS" != "$PASS2" ]; then echo "   The two passwords don't match. Try again."; continue; fi
  if [ "${#PASS}" -lt 8 ]; then echo "   Too short. Use at least 8 characters."; continue; fi
  if [ "$PASS" != "$(clean "$PASS")" ]; then echo "   Please don't use quotes, \$, \` or \\ in the password."; continue; fi
  break
done

read -rp "4. Your web address, e.g. erp.shreetiles.in (optional): " DOMAIN
DOMAIN=$(clean "$DOMAIN" | tr 'A-Z' 'a-z' | sed 's#^https\?://##; s#/.*$##')

read -rp "5. Anthropic API key for the AI features (optional): " AIKEY
AIKEY=$(clean "$AIKEY")

say "Adding 2 GB of backup memory (swap)"
if ! swapon --show | grep -q /swapfile; then
  sudo fallocate -l 2G /swapfile && sudo chmod 600 /swapfile && sudo mkswap /swapfile >/dev/null && sudo swapon /swapfile
  grep -q '/swapfile' /etc/fstab || echo '/swapfile none swap sw 0 0' | sudo tee -a /etc/fstab >/dev/null
fi
ok "Swap ready"

say "Installing Docker (takes 1-2 minutes)"
if ! command -v docker >/dev/null; then curl -fsSL https://get.docker.com | sudo sh >/dev/null; fi
ok "Docker ready"

say "Writing your settings"
if [ -f .env ]; then
  ok "Settings file already exists, keeping it"
else
  cat > .env <<ENV
BUSINESS_NAME='$BIZ'
DB_PASSWORD='$(openssl rand -hex 16)'
JWT_SECRET='$(openssl rand -hex 32)'
OWNER_EMAIL='$EMAIL'
OWNER_PASSWORD='$PASS'
SEED_SAMPLE_DATA=false
ANTHROPIC_API_KEY='$AIKEY'
AI_MODEL=claude-sonnet-5-5
COOKIE_SECURE=false
DIGEST_HOUR=9
ENV
  chmod 600 .env
  ok "Settings saved (passwords and secret keys were generated for you)"
fi
# Only reachable through the secure web address, never directly
sed -i 's/"3000:3000"/"127.0.0.1:3000:3000"/' docker-compose.yml

say "Building and starting the app (takes 3-6 minutes the first time)"
sudo docker compose up -d --build
for i in $(seq 1 90); do curl -fs localhost:3000/healthz >/dev/null 2>&1 && break; sleep 2; done
curl -fs localhost:3000/healthz >/dev/null || { echo "The app did not start. Run: sudo docker compose logs app"; exit 1; }
ok "App is running"

say "Creating your owner login"
sudo docker compose exec -T app node server/src/seed.js
sed -i "s/^OWNER_PASSWORD=.*/OWNER_PASSWORD=/" .env   # don't keep the password lying around
ok "Login created for $EMAIL"

if [ -n "$DOMAIN" ]; then
  say "Setting up the secure web address https://$DOMAIN"
  if ! command -v caddy >/dev/null; then
    sudo apt-get update -qq && sudo apt-get install -y -qq debian-keyring debian-archive-keyring apt-transport-https curl gpg >/dev/null
    curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/gpg.key' | sudo gpg --batch --yes --dearmor -o /usr/share/keyrings/caddy-stable-archive-keyring.gpg
    curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/debian.deb.txt' | sudo tee /etc/apt/sources.list.d/caddy-stable.list >/dev/null
    sudo apt-get update -qq && sudo apt-get install -y -qq caddy >/dev/null
  fi
  printf '%s {\n  reverse_proxy localhost:3000\n}\n' "$DOMAIN" | sudo tee /etc/caddy/Caddyfile >/dev/null
  sudo systemctl reload caddy || sudo systemctl restart caddy
  sed -i 's/^COOKIE_SECURE=.*/COOKIE_SECURE=true/' .env
  sudo docker compose up -d >/dev/null
  ok "Secure address configured"
fi

say "Turning on nightly backups (2 am, last 14 days kept)"
mkdir -p "$HOME/backups"
echo "0 2 * * * root cd $APP_DIR && docker compose exec -T db pg_dump -U showroom showroom | gzip > $HOME/backups/erp-\$(date +\%F).sql.gz && find $HOME/backups -name 'erp-*.sql.gz' -mtime +14 -delete" \
  | sudo tee /etc/cron.d/showroom-backup >/dev/null
ok "Backups scheduled in $HOME/backups"

echo
echo "========================================================"
if [ -n "$DOMAIN" ]; then
  echo "  All done! Open:  https://$DOMAIN"
  echo "  (If it doesn't open yet, your domain may still be activating."
  echo "   Wait 15-30 minutes and try again. Nothing else to do.)"
else
  echo "  All done! The app is running on the server."
  echo "  It needs a web address (domain) before you can open it safely."
fi
echo "  Sign in with: $EMAIL"
echo "========================================================"
