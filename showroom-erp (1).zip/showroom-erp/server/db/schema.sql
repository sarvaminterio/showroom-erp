-- Showroom ERP schema (PostgreSQL 14+)
CREATE TABLE IF NOT EXISTS showrooms (
  id SERIAL PRIMARY KEY,
  code TEXT NOT NULL UNIQUE,             -- bill prefix, e.g. RR
  name TEXT NOT NULL,
  gstin CHAR(15) NOT NULL UNIQUE,
  state TEXT NOT NULL,
  addr TEXT NOT NULL DEFAULT '',
  phone TEXT NOT NULL DEFAULT '',
  scheme TEXT NOT NULL DEFAULT 'Regular' CHECK (scheme IN ('Regular','Composition'))
);

CREATE TABLE IF NOT EXISTS users (
  id SERIAL PRIMARY KEY,
  name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('owner','staff')),
  showroom_id INT REFERENCES showrooms(id)  -- required for staff
);

CREATE TABLE IF NOT EXISTS products (
  id SERIAL PRIMARY KEY,
  name TEXT NOT NULL,
  brand TEXT NOT NULL DEFAULT '',
  cat TEXT NOT NULL CHECK (cat IN ('Tile','Sanitaryware','CP Fitting')),
  size TEXT NOT NULL DEFAULT '',
  finish TEXT NOT NULL DEFAULT '',
  sqft_per_box NUMERIC(10,3),             -- tiles only
  rate NUMERIC(12,2) NOT NULL,            -- per sq ft for tiles, per piece otherwise
  gst_rate NUMERIC(5,2) NOT NULL DEFAULT 18,
  hsn TEXT NOT NULL,
  batch TEXT, shade TEXT,
  color TEXT NOT NULL DEFAULT '#cfcac0',
  CHECK (cat <> 'Tile' OR sqft_per_box > 0)
);

CREATE TABLE IF NOT EXISTS stock (
  product_id INT REFERENCES products(id) ON DELETE CASCADE,
  showroom_id INT REFERENCES showrooms(id) ON DELETE CASCADE,
  qty INT NOT NULL DEFAULT 0 CHECK (qty >= 0),
  PRIMARY KEY (product_id, showroom_id)
);

CREATE TABLE IF NOT EXISTS stock_moves (           -- audit trail of every stock change
  id SERIAL PRIMARY KEY,
  product_id INT NOT NULL REFERENCES products(id),
  from_showroom INT REFERENCES showrooms(id),
  to_showroom INT REFERENCES showrooms(id),
  qty INT NOT NULL,
  reason TEXT NOT NULL,                             -- sale, received, damage, transfer
  ref TEXT,
  user_id INT REFERENCES users(id),
  at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS customers (
  id SERIAL PRIMARY KEY,
  name TEXT NOT NULL,
  type TEXT NOT NULL DEFAULT 'Retail',
  phone TEXT NOT NULL DEFAULT '',
  gstin TEXT NOT NULL DEFAULT '',
  state TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS bill_sequences (
  showroom_id INT REFERENCES showrooms(id),
  type TEXT, fy TEXT, next INT NOT NULL,
  PRIMARY KEY (showroom_id, type, fy)
);

CREATE TABLE IF NOT EXISTS bills (
  id SERIAL PRIMARY KEY,
  no TEXT NOT NULL UNIQUE,
  showroom_id INT NOT NULL REFERENCES showrooms(id),
  type TEXT NOT NULL CHECK (type IN ('GST','BOS','EST')),  -- tax invoice, bill of supply, non-GST estimate
  date DATE NOT NULL DEFAULT CURRENT_DATE,
  customer_id INT NOT NULL REFERENCES customers(id),
  discount_pct NUMERIC(5,2) NOT NULL DEFAULT 0,
  subtotal NUMERIC(14,2) NOT NULL, taxable NUMERIC(14,2) NOT NULL,
  cgst NUMERIC(14,2) NOT NULL DEFAULT 0, sgst NUMERIC(14,2) NOT NULL DEFAULT 0, igst NUMERIC(14,2) NOT NULL DEFAULT 0,
  total NUMERIC(14,2) NOT NULL,
  paid NUMERIC(14,2) NOT NULL DEFAULT 0,
  created_by INT REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS bill_items (
  id SERIAL PRIMARY KEY,
  bill_id INT NOT NULL REFERENCES bills(id) ON DELETE CASCADE,
  product_id INT NOT NULL REFERENCES products(id),
  room TEXT NOT NULL DEFAULT '',
  area NUMERIC(10,2), wastage NUMERIC(5,2),
  qty INT NOT NULL, unit TEXT NOT NULL,
  rate NUMERIC(12,2) NOT NULL, gst_rate NUMERIC(5,2) NOT NULL,
  amount NUMERIC(14,2) NOT NULL
);

CREATE TABLE IF NOT EXISTS payments (
  id SERIAL PRIMARY KEY,
  bill_id INT NOT NULL REFERENCES bills(id) ON DELETE CASCADE,
  amount NUMERIC(14,2) NOT NULL CHECK (amount > 0),
  mode TEXT NOT NULL DEFAULT 'Cash',
  at TIMESTAMPTZ NOT NULL DEFAULT now(),
  user_id INT REFERENCES users(id)
);

-- ===== v0.2: payment follow-ups =====
ALTER TABLE customers ADD COLUMN IF NOT EXISTS credit_days INT NOT NULL DEFAULT 0;
ALTER TABLE bills ADD COLUMN IF NOT EXISTS due_date DATE;
UPDATE bills SET due_date = date WHERE due_date IS NULL;

CREATE TABLE IF NOT EXISTS followups (
  id SERIAL PRIMARY KEY,
  customer_id INT NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  note TEXT NOT NULL,
  promised_date DATE,                      -- "will pay on ..."
  promised_amount NUMERIC(14,2),
  user_id INT REFERENCES users(id),
  at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS digests (       -- one AI payment briefing per day
  day DATE PRIMARY KEY,
  text TEXT NOT NULL,
  total_due NUMERIC(14,2) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
