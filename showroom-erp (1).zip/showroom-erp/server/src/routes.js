import { Router } from 'express';
import bcrypt from 'bcryptjs';
import rateLimit from 'express-rate-limit';
import { q, tx } from './db.js';
import { sign, requireAuth, requireOwner, canUse } from './auth.js';
import { duesFor, makeDigest } from './digest.js';
import { lineCalc, billTotals, effectiveType, fy, billNumber, GSTIN_RE } from './billing.js';

const r = Router();
const wrap = fn => (req, res, next) => fn(req, res).catch(next);
class UserError extends Error { constructor(m, s = 400) { super(m); this.status = s; } }
const fail = (m, s) => { throw new UserError(m, s); };
const HSN = { Tile: '6907', Sanitaryware: '6910', 'CP Fitting': '8481' };

// ---------- Auth ----------
r.post('/auth/login', rateLimit({ windowMs: 15 * 60e3, limit: 20 }), wrap(async (req, res) => {
  const { rows: [u] } = await q('SELECT * FROM users WHERE lower(email)=lower($1)', [req.body.email || '']);
  if (!u || !(await bcrypt.compare(req.body.password || '', u.password_hash))) fail('Email or password is incorrect.', 401);
  res.cookie('token', sign(u), { httpOnly: true, sameSite: 'lax', secure: process.env.COOKIE_SECURE === 'true', maxAge: 12 * 3600e3 });
  res.json({ ok: true });
}));
r.post('/auth/logout', (req, res) => { res.clearCookie('token'); res.json({ ok: true }); });

r.use(requireAuth);

// ---------- Everything the app needs on load ----------
r.get('/bootstrap', wrap(async (req, res) => {
  const staffShop = req.user.role === 'staff' ? req.user.showroom_id : null;
  const [showrooms, products, customers, bills] = await Promise.all([
    q('SELECT * FROM showrooms ORDER BY id'),
    q(`SELECT p.id,p.name,p.brand,p.cat,p.size,p.finish,p.sqft_per_box AS "sqftPerBox",p.rate,p.gst_rate AS "gstRate",p.hsn,p.batch,p.shade,p.color,
         COALESCE(json_object_agg(s.showroom_id,s.qty) FILTER (WHERE s.showroom_id IS NOT NULL),'{}') AS stock
       FROM products p LEFT JOIN stock s ON s.product_id=p.id GROUP BY p.id ORDER BY p.id`),
    q(`SELECT c.*, c.credit_days AS "creditDays", COALESCE(SUM(b.total-b.paid),0) AS outstanding FROM customers c
       LEFT JOIN bills b ON b.customer_id=c.id GROUP BY c.id ORDER BY c.name`),
    q(`SELECT id,no,showroom_id AS shop,type,date,due_date AS "dueDate",customer_id AS cust,total,paid FROM bills
       WHERE $1::int IS NULL OR showroom_id=$1 ORDER BY id DESC LIMIT 500`, [staffShop])
  ]);
  res.json({ me: req.user, showrooms: showrooms.rows, products: products.rows, customers: customers.rows,
    bills: bills.rows.reverse(), aiEnabled: !!process.env.ANTHROPIC_API_KEY, business: process.env.BUSINESS_NAME || 'My Showroom' });
}));

// ---------- Showrooms & team ----------
r.post('/showrooms', requireOwner, wrap(async (req, res) => {
  const b = req.body, gstin = String(b.gstin || '').toUpperCase().trim(), code = String(b.code || '').toUpperCase().trim();
  if (!b.name?.trim() || !/^[A-Z]{2,4}$/.test(code)) fail('Enter a name and a 2–4 letter bill prefix.');
  if (!GSTIN_RE.test(gstin)) fail('That GSTIN does not look valid. It should be 15 characters.');
  const id = await tx(async c => {
    const { rows: [s] } = await c.query(`INSERT INTO showrooms(code,name,gstin,state,addr,phone,scheme) VALUES($1,$2,$3,$4,$5,$6,$7) RETURNING id`,
      [code, b.name.trim(), gstin, b.state || '', b.addr || '', b.phone || '', b.scheme === 'Composition' ? 'Composition' : 'Regular']);
    await c.query('INSERT INTO stock(product_id,showroom_id,qty) SELECT id,$1,0 FROM products', [s.id]);
    return s.id;
  });
  res.json({ id });
}));

r.post('/users', requireOwner, wrap(async (req, res) => {
  const { name, email, password, role, showroomId } = req.body;
  if (!name || !email || (password || '').length < 8) fail('Enter name, email and a password of at least 8 characters.');
  if (role === 'staff' && !showroomId) fail('Pick the showroom this person works in.');
  await q('INSERT INTO users(name,email,password_hash,role,showroom_id) VALUES($1,$2,$3,$4,$5)',
    [name, email.toLowerCase(), await bcrypt.hash(password, 10), role === 'owner' ? 'owner' : 'staff', role === 'owner' ? null : showroomId]);
  res.json({ ok: true });
}));
r.get('/users', requireOwner, wrap(async (req, res) => {
  res.json((await q('SELECT id,name,email,role,showroom_id FROM users ORDER BY id')).rows);
}));

// ---------- Products & customers ----------
r.post('/products', requireOwner, wrap(async (req, res) => {
  const b = req.body;
  if (!b.name?.trim() || !(+b.rate > 0) || !HSN[b.cat]) fail('Enter a name, category and rate.');
  if (b.cat === 'Tile' && !(+b.sqftPerBox > 0)) fail('Enter sq ft per box for tiles.');
  const id = await tx(async c => {
    const { rows: [p] } = await c.query(`INSERT INTO products(name,brand,cat,size,finish,sqft_per_box,rate,gst_rate,hsn,batch,shade,color)
      VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12) RETURNING id`,
      [b.name.trim(), b.brand || '', b.cat, b.size || '', b.finish || '', b.cat === 'Tile' ? +b.sqftPerBox : null, +b.rate,
       +b.gstRate || 18, b.hsn || HSN[b.cat], b.batch || null, b.shade || null, b.color || '#cfcac0']);
    await c.query('INSERT INTO stock(product_id,showroom_id,qty) SELECT $1,id,0 FROM showrooms', [p.id]);
    return p.id;
  });
  res.json({ id });
}));

r.post('/customers', wrap(async (req, res) => {
  const b = req.body;
  if (!b.name?.trim() || !b.state) fail('Enter the customer name and state.');
  if (b.gstin && !GSTIN_RE.test(b.gstin.toUpperCase())) fail('That GSTIN does not look valid.');
  const { rows: [c] } = await q('INSERT INTO customers(name,type,phone,gstin,state,credit_days) VALUES($1,$2,$3,$4,$5,$6) RETURNING id',
    [b.name.trim(), b.type || 'Retail', b.phone || '', (b.gstin || '').toUpperCase(), b.state, Math.min(365, Math.max(0, Math.trunc(+b.creditDays || 0)))]);
  res.json({ id: c.id });
}));

// ---------- Stock ----------
r.post('/stock/adjust', wrap(async (req, res) => {
  const { productId, showroomId } = req.body, delta = Math.trunc(+req.body.delta || 0);
  if (!canUse(req.user, showroomId)) fail('You can only change stock in your own showroom.', 403);
  if (!delta) fail('Enter a quantity.');
  await tx(async c => {
    const { rows: [s] } = await c.query('SELECT qty FROM stock WHERE product_id=$1 AND showroom_id=$2 FOR UPDATE', [productId, showroomId]);
    if (!s) fail('Item not found in this showroom.');
    if (s.qty + delta < 0) fail(`Only ${s.qty} in stock, so you can't remove ${-delta}.`);
    await c.query('UPDATE stock SET qty=qty+$3 WHERE product_id=$1 AND showroom_id=$2', [productId, showroomId, delta]);
    await c.query('INSERT INTO stock_moves(product_id,from_showroom,to_showroom,qty,reason,user_id) VALUES($1,$2,$3,$4,$5,$6)',
      [productId, delta < 0 ? showroomId : null, delta > 0 ? showroomId : null, Math.abs(delta), delta > 0 ? 'received' : 'damage', req.user.id]);
  });
  res.json({ ok: true });
}));

r.post('/stock/transfer', wrap(async (req, res) => {
  const { productId, from, to } = req.body, qty = Math.trunc(+req.body.qty || 0);
  if (+from === +to) fail('Pick two different showrooms.');
  if (!canUse(req.user, from)) fail('You can only send stock from your own showroom.', 403);
  if (qty <= 0) fail('Enter a quantity.');
  await tx(async c => {
    const { rows } = await c.query('SELECT showroom_id,qty FROM stock WHERE product_id=$1 AND showroom_id IN ($2,$3) ORDER BY showroom_id FOR UPDATE', [productId, from, to]);
    const src = rows.find(x => x.showroom_id === +from);
    if (!src || src.qty < qty) fail(`Only ${src?.qty || 0} available to move.`);
    await c.query('UPDATE stock SET qty=qty-$3 WHERE product_id=$1 AND showroom_id=$2', [productId, from, qty]);
    await c.query(`INSERT INTO stock(product_id,showroom_id,qty) VALUES($1,$2,$3)
      ON CONFLICT(product_id,showroom_id) DO UPDATE SET qty=stock.qty+$3`, [productId, to, qty]);
    await c.query(`INSERT INTO stock_moves(product_id,from_showroom,to_showroom,qty,reason,user_id) VALUES($1,$2,$3,$4,'transfer',$5)`,
      [productId, from, to, qty, req.user.id]);
  });
  res.json({ ok: true });
}));

// ---------- Bills ----------
r.post('/bills', wrap(async (req, res) => {
  const { showroomId, customerId, lines, discount } = req.body;
  if (!canUse(req.user, showroomId)) fail('You can only bill from your own showroom.', 403);
  if (!Array.isArray(lines) || !lines.length || lines.length > 200) fail('Add at least one item.');
  if (!['GST', 'EST'].includes(req.body.type)) fail('Choose a bill type.');

  const out = await tx(async c => {
    const { rows: [shop] } = await c.query('SELECT * FROM showrooms WHERE id=$1', [showroomId]);
    const { rows: [cust] } = await c.query('SELECT * FROM customers WHERE id=$1', [customerId]);
    if (!shop || !cust) fail('Showroom or customer not found.');
    const type = effectiveType(shop.scheme, req.body.type);

    // Lock stock rows in a fixed order to avoid deadlocks between two counters.
    const ids = [...new Set(lines.map(l => +l.pid))].sort((a, b) => a - b);
    const { rows: prods } = await c.query(`SELECT p.*, s.qty AS on_hand FROM products p JOIN stock s ON s.product_id=p.id AND s.showroom_id=$2
      WHERE p.id = ANY($1::int[]) ORDER BY p.id FOR UPDATE OF s`, [ids, showroomId]);
    const byId = Object.fromEntries(prods.map(p => [p.id, p]));
    const need = {};
    const calc = lines.map(l => {
      const p = byId[+l.pid]; if (!p) fail('One of the items is not stocked in this showroom.');
      const x = lineCalc(p, l); need[p.id] = (need[p.id] || 0) + x.qty;
      return { ...x, p, room: String(l.room || '').slice(0, 80), gst_rate: p.gst_rate };
    });
    for (const [pid, n] of Object.entries(need))
      if (n > byId[pid].on_hand) fail(`${shop.name} has only ${byId[pid].on_hand} of ${byId[pid].name}. Transfer stock first.`);

    const t = billTotals(calc, discount, type, cust.state !== shop.state);
    const f = fy();
    const { rows: [seq] } = await c.query(`INSERT INTO bill_sequences(showroom_id,type,fy,next) VALUES($1,$2,$3,2)
      ON CONFLICT(showroom_id,type,fy) DO UPDATE SET next=bill_sequences.next+1 RETURNING next-1 AS n`, [shop.id, type, f]);
    const no = billNumber(shop.code, type, f, seq.n);
    const { rows: [bill] } = await c.query(`INSERT INTO bills(no,showroom_id,type,customer_id,discount_pct,subtotal,taxable,cgst,sgst,igst,total,created_by,due_date)
      VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,CURRENT_DATE+$13::int) RETURNING id`,
      [no, shop.id, type, cust.id, Math.min(100, Math.max(0, +discount || 0)), t.subtotal, t.taxable, t.cgst, t.sgst, t.igst, t.total, req.user.id, cust.credit_days]);
    for (const x of calc) {
      await c.query(`INSERT INTO bill_items(bill_id,product_id,room,area,wastage,qty,unit,rate,gst_rate,amount) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)`,
        [bill.id, x.p.id, x.room, x.area, x.wastage, x.qty, x.unit, x.p.rate, x.gst_rate, x.amount]);
      await c.query('UPDATE stock SET qty=qty-$3 WHERE product_id=$1 AND showroom_id=$2', [x.p.id, shop.id, x.qty]);
      await c.query(`INSERT INTO stock_moves(product_id,from_showroom,qty,reason,ref,user_id) VALUES($1,$2,$3,'sale',$4,$5)`,
        [x.p.id, shop.id, x.qty, no, req.user.id]);
    }
    return { id: bill.id, no };
  });
  res.json(out);
}));

r.get('/bills/:id', wrap(async (req, res) => {
  const { rows: [b] } = await q(`SELECT b.*, row_to_json(s) AS showroom, row_to_json(c) AS customer FROM bills b
    JOIN showrooms s ON s.id=b.showroom_id JOIN customers c ON c.id=b.customer_id WHERE b.id=$1`, [req.params.id]);
  if (!b || !canUse(req.user, b.showroom_id)) fail('Bill not found.', 404);
  const items = (await q(`SELECT i.*, p.name, p.brand, p.size, p.hsn, p.batch, p.shade FROM bill_items i
    JOIN products p ON p.id=i.product_id WHERE bill_id=$1 ORDER BY i.id`, [b.id])).rows;
  const payments = (await q('SELECT amount,mode,at FROM payments WHERE bill_id=$1 ORDER BY at', [b.id])).rows;
  res.json({ ...b, items, payments });
}));

r.post('/bills/:id/payments', wrap(async (req, res) => {
  const amount = Math.round(+req.body.amount * 100) / 100;
  if (!(amount > 0)) fail('Enter the amount received.');
  await tx(async c => {
    const { rows: [b] } = await c.query('SELECT * FROM bills WHERE id=$1 FOR UPDATE', [req.params.id]);
    if (!b || !canUse(req.user, b.showroom_id)) fail('Bill not found.', 404);
    if (amount > b.total - b.paid + 0.001) fail(`Only ₹${(b.total - b.paid).toLocaleString('en-IN')} is due on this bill.`);
    await c.query('INSERT INTO payments(bill_id,amount,mode,user_id) VALUES($1,$2,$3,$4)', [b.id, amount, req.body.mode || 'Cash', req.user.id]);
    await c.query('UPDATE bills SET paid=paid+$2 WHERE id=$1', [b.id, amount]);
  });
  res.json({ ok: true });
}));

// ---------- Pending payments ----------
r.get('/dues', wrap(async (req, res) => {
  const shopId = req.user.role === 'staff' ? req.user.showroom_id : (req.query.showroom && req.query.showroom !== 'all' ? +req.query.showroom : null);
  res.json(await duesFor(shopId));
}));

r.put('/customers/:id/credit', wrap(async (req, res) => {
  const days = Math.min(365, Math.max(0, Math.trunc(+req.body.creditDays || 0)));
  await q('UPDATE customers SET credit_days=$2 WHERE id=$1', [req.params.id, days]);
  res.json({ ok: true });
}));

r.post('/followups', wrap(async (req, res) => {
  const { customerId, note, promisedDate, promisedAmount } = req.body;
  if (!String(note || '').trim()) fail('Write what happened on the call or visit.');
  if (promisedDate && !/^\d{4}-\d{2}-\d{2}$/.test(promisedDate)) fail('Pick a valid promised date.');
  await q('INSERT INTO followups(customer_id,note,promised_date,promised_amount,user_id) VALUES($1,$2,$3,$4,$5)',
    [customerId, String(note).slice(0, 500), promisedDate || null, +promisedAmount > 0 ? +promisedAmount : null, req.user.id]);
  res.json({ ok: true });
}));

r.get('/digest', wrap(async (req, res) => {
  const { rows: [d] } = await q("SELECT day, text, total_due AS \"totalDue\", created_at FROM digests ORDER BY day DESC LIMIT 1");
  res.json(d || null);
}));
r.post('/digest/run', requireOwner, wrap(async (req, res) => { res.json(await makeDigest({ force: true })); }));

export { UserError };
export default r;
