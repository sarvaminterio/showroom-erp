// Pending-payment tracking and the daily AI payment briefing for the owner.
import nodemailer from 'nodemailer';
import { q } from './db.js';
import { claude } from './ai.js';

const inr = n => '₹' + Math.round(n).toLocaleString('en-IN');

// Every unpaid bill plus a per-customer summary with ageing and follow-up history.
export async function duesFor(showroomId = null) {
  const { rows: bills } = await q(`
    SELECT b.id, b.no, b.type, b.date, b.due_date AS "dueDate", b.total, b.paid, b.total-b.paid AS due,
           CURRENT_DATE - b.due_date AS "daysOverdue", b.customer_id AS cust, s.name AS showroom, s.id AS "showroomId"
    FROM bills b JOIN showrooms s ON s.id=b.showroom_id
    WHERE b.total > b.paid AND ($1::int IS NULL OR b.showroom_id=$1)
    ORDER BY b.due_date`, [showroomId]);
  const ids = [...new Set(bills.map(b => b.cust))];
  const { rows: custs } = ids.length ? await q(`
    SELECT c.id, c.name, c.type, c.phone, c.credit_days AS "creditDays",
      (SELECT row_to_json(f) FROM (SELECT note, promised_date AS "promisedDate", promised_amount AS "promisedAmount", at
         FROM followups WHERE customer_id=c.id ORDER BY at DESC LIMIT 1) f) AS "lastFollowup",
      (SELECT max(p.at) FROM payments p JOIN bills b ON b.id=p.bill_id WHERE b.customer_id=c.id) AS "lastPaymentAt"
    FROM customers c WHERE c.id = ANY($1::int[])`, [ids]) : { rows: [] };
  const { rows: [{ today }] } = await q("SELECT CURRENT_DATE::text AS today");

  const buckets = { notDue: 0, d0_30: 0, d31_60: 0, d61_90: 0, d90: 0 };
  const bucketOf = d => (d <= 0 ? 'notDue' : d <= 30 ? 'd0_30' : d <= 60 ? 'd31_60' : d <= 90 ? 'd61_90' : 'd90');
  for (const b of bills) buckets[bucketOf(b.daysOverdue)] += b.due;

  const customers = custs.map(c => {
    const mine = bills.filter(b => b.cust === c.id);
    const lf = c.lastFollowup;
    return { ...c,
      due: mine.reduce((a, b) => a + b.due, 0),
      overdue: mine.filter(b => b.daysOverdue > 0).reduce((a, b) => a + b.due, 0),
      oldestDays: Math.max(...mine.map(b => b.daysOverdue)),
      bills: mine.length,
      // a promise is broken when its date has passed and money is still owed
      promiseBroken: !!(lf?.promisedDate && lf.promisedDate < today),
      promiseUpcoming: !!(lf?.promisedDate && lf.promisedDate >= today) };
  }).sort((a, b) => (b.promiseBroken - a.promiseBroken) || (b.overdue - a.overdue));

  return { today, total: bills.reduce((a, b) => a + b.due, 0), overdue: bills.filter(b => b.daysOverdue > 0).reduce((a, b) => a + b.due, 0),
    buckets, customers, bills };
}

function plainDigest(d) {
  const top = d.customers.filter(c => c.overdue > 0).slice(0, 8);
  return [`Pending payments: ${inr(d.total)} in total, ${inr(d.overdue)} overdue.`, '',
    ...top.map((c, i) => `${i + 1}. ${c.name}: ${inr(c.overdue)} overdue, oldest ${c.oldestDays} day${c.oldestDays === 1 ? '' : 's'}${c.promiseBroken ? ' (missed promised date)' : ''}`),
    top.length ? '' : 'Nothing is overdue today.'].join('\n');
}

// Builds today's briefing once a day (or on demand), stores it, and emails it if set up.
export async function makeDigest({ force = false } = {}) {
  const { rows: [existing] } = await q("SELECT day, text, total_due AS \"totalDue\", created_at FROM digests WHERE day=CURRENT_DATE");
  if (existing && !force) return existing;
  const d = await duesFor(null);
  let text;
  if (!d.bills.length) text = 'No pending payments today. Every bill is fully paid.';
  else if (process.env.ANTHROPIC_API_KEY) {
    const data = d.customers.slice(0, 40).map(c => ({ name: c.name, type: c.type, totalDue: c.due, overdue: c.overdue, oldestDaysOverdue: c.oldestDays,
      creditDays: c.creditDays, openBills: c.bills, lastFollowup: c.lastFollowup, promiseBroken: c.promiseBroken, lastPaymentAt: c.lastPaymentAt }));
    try {
      text = await claude(`You write a short morning payment-collection briefing for the owner of an Indian tile and sanitaryware business. Today is ${d.today}.
Plain text, no markdown symbols, under 220 words. Start with one line on totals. Then list up to 6 customers to chase today, most urgent first:
missed payment promises first, then largest and oldest overdue amounts. For each, one line: name, amount overdue, how old, and a concrete next step
(call, visit, send reminder, hold further credit). Mention promises due today or soon. Don't invent facts; use only this data. Amounts in ₹ with Indian grouping.`,
        [{ role: 'user', content: JSON.stringify({ totalDue: d.total, totalOverdue: d.overdue, ageing: d.buckets, customers: data }) }], 700);
    } catch (e) { console.error('AI digest failed, using plain summary:', e.message); text = plainDigest(d); }
  } else text = plainDigest(d);

  const { rows: [saved] } = await q(`INSERT INTO digests(day,text,total_due) VALUES(CURRENT_DATE,$1,$2)
    ON CONFLICT(day) DO UPDATE SET text=$1,total_due=$2,created_at=now() RETURNING day, text, total_due AS "totalDue", created_at`, [text, d.total]);
  if (!existing) await emailDigest(text, d).catch(e => console.error('Digest email failed:', e.message));
  return saved;
}

async function emailDigest(text, d) {
  const { SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS, DIGEST_EMAIL } = process.env;
  if (!SMTP_HOST || !DIGEST_EMAIL) return;
  const t = nodemailer.createTransport({ host: SMTP_HOST, port: +SMTP_PORT || 587, secure: +SMTP_PORT === 465, auth: SMTP_USER ? { user: SMTP_USER, pass: SMTP_PASS } : undefined });
  await t.sendMail({ from: process.env.SMTP_FROM || SMTP_USER, to: DIGEST_EMAIL,
    subject: `Pending payments: ${inr(d.overdue)} overdue (${d.today})`, text: text + '\n\nOpen the app for details and follow-up notes.' });
}

// Checks every 10 minutes; makes the briefing once a day after DIGEST_HOUR (Indian time, default 9 am).
export function startScheduler() {
  const hour = +(process.env.DIGEST_HOUR ?? 9);
  const tick = async () => {
    const nowIST = +new Intl.DateTimeFormat('en-IN', { hour: 'numeric', hourCycle: 'h23', timeZone: 'Asia/Kolkata' }).format(new Date());
    if (nowIST >= hour) await makeDigest().catch(e => console.error('Digest failed:', e.message));
  };
  setTimeout(tick, 5000); setInterval(tick, 10 * 60e3);
}
