import { Router } from 'express';
import rateLimit from 'express-rate-limit';
import { q } from './db.js';
import { requireAuth } from './auth.js';

// The API key stays on the server; the browser only talks to these routes.
const r = Router();
r.use(requireAuth, rateLimit({ windowMs: 60e3, limit: 20 }));
const MODEL = process.env.AI_MODEL || 'claude-sonnet-5-5';
const wrap = fn => (req, res, next) => fn(req, res).catch(next);

export async function claude(system, messages, max_tokens = 1000) {
  if (!process.env.ANTHROPIC_API_KEY) { const e = new Error('AI is not set up. Add ANTHROPIC_API_KEY to the server settings.'); e.status = 503; throw e; }
  const resp = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: { 'content-type': 'application/json', 'x-api-key': process.env.ANTHROPIC_API_KEY, 'anthropic-version': '2023-06-01' },
    body: JSON.stringify({ model: MODEL, max_tokens, system, messages })
  });
  const d = await resp.json();
  if (!resp.ok) { const e = new Error(d.error?.message || 'The AI service returned an error.'); e.status = 502; throw e; }
  return d.content.filter(b => b.type === 'text').map(b => b.text).join('\n');
}

async function snapshot(user) {
  const shop = user.role === 'staff' ? user.showroom_id : null;
  const [s, p, c, b] = await Promise.all([
    q('SELECT id,name,state,scheme FROM showrooms ORDER BY id'),
    q(`SELECT p.id,p.name,p.brand,p.cat,p.size,p.finish,p.rate,p.sqft_per_box,
         json_object_agg(st.showroom_id,st.qty) AS stock FROM products p JOIN stock st ON st.product_id=p.id GROUP BY p.id`),
    q(`SELECT c.name,c.type,c.state,COALESCE(SUM(b.total-b.paid),0) AS outstanding FROM customers c
       LEFT JOIN bills b ON b.customer_id=c.id AND ($1::int IS NULL OR b.showroom_id=$1) GROUP BY c.id`, [shop]),
    q(`SELECT b.no,b.type,b.date,b.total,b.paid,s.name AS showroom,c.name AS customer FROM bills b
       JOIN showrooms s ON s.id=b.showroom_id JOIN customers c ON c.id=b.customer_id
       WHERE $1::int IS NULL OR b.showroom_id=$1 ORDER BY b.id DESC LIMIT 150`, [shop])
  ]);
  return JSON.stringify({ showrooms: s.rows, products: p.rows, customers: c.rows, recentBills: b.rows });
}

const clean = msgs => (Array.isArray(msgs) ? msgs : []).slice(-10)
  .filter(m => ['user', 'assistant'].includes(m.role) && typeof m.content === 'string')
  .map(m => ({ role: m.role, content: m.content.slice(0, 4000) }));

r.post('/chat', wrap(async (req, res) => {
  const messages = clean(req.body.messages);
  if (!messages.length || messages.at(-1).role !== 'user') return res.status(400).json({ error: 'Type a question first.' });
  const reply = await claude(`You are the assistant inside the software of an Indian tile, sanitaryware and CP fittings business with several showrooms, each with its own GSTIN.
Answer only from this live data. Amounts in rupees with Indian digit grouping. Be brief and practical; plain text, short lines, no tables. Stock for tiles is in boxes. If the data can't answer, say so.
DATA: ${await snapshot(req.user)}`, messages);
  res.json({ reply });
}));

r.post('/suggest', wrap(async (req, res) => {
  const job = String(req.body.job || '').slice(0, 2000), shop = +req.body.showroomId;
  if (!job.trim()) return res.status(400).json({ error: 'Describe the job first.' });
  const { rows: cat } = await q(`SELECT p.id AS pid,p.name,p.brand,p.cat,p.size,p.finish,p.rate,COALESCE(s.qty,0) AS "stockHere"
    FROM products p LEFT JOIN stock s ON s.product_id=p.id AND s.showroom_id=$1`, [shop]);
  const txt = await claude(`You choose products for a tile showroom quotation, using only this catalogue and preferring items with stock here.
Return ONLY JSON: {"lines":[{"pid":n,"room":"...","area":n,"wastage":n} for tiles | {"pid":n,"room":"...","qty":n} for others],"note":"one sentence"}. Wastage 8-12.
CATALOGUE: ${JSON.stringify(cat)}`, [{ role: 'user', content: job }]);
  try { res.json(JSON.parse(txt.replace(/```json|```/g, '').trim())); }
  catch { res.status(502).json({ error: 'The AI reply could not be read. Try rephrasing the job.' }); }
}));

r.post('/reminder', wrap(async (req, res) => {
  const lang = ['English', 'Hindi', 'Gujarati'].includes(req.body.lang) ? req.body.lang : 'English';
  const shop = req.user.role === 'staff' ? req.user.showroom_id : null;
  const { rows: [c] } = await q('SELECT * FROM customers WHERE id=$1', [req.body.customerId]);
  if (!c) return res.status(404).json({ error: 'Customer not found.' });
  const { rows: bills } = await q(`SELECT no,total-paid AS due FROM bills WHERE customer_id=$1 AND total>paid AND ($2::int IS NULL OR showroom_id=$2)`, [c.id, shop]);
  const due = bills.reduce((a, b) => a + b.due, 0);
  const text = await claude(`Write a short, warm, respectful WhatsApp payment reminder from ${process.env.BUSINESS_NAME || 'the showroom'} to a valued customer. Under 70 words. Output only the message.`,
    [{ role: 'user', content: `Language: ${lang}. Customer: ${c.name} (${c.type}). Total due: ₹${due.toLocaleString('en-IN')}. Bills: ${bills.map(b => `${b.no} ₹${b.due}`).join(', ')}` }], 400);
  res.json({ text, phone: c.phone });
}));

export default r;
